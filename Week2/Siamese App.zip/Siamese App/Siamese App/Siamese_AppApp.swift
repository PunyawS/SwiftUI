//
//  Siamese_AppApp.swift
//  Siamese App
//
//  Created by Train2 on 14/1/2565 BE.
//

import SwiftUI

@main
struct Siamese_AppApp: App {
    var body: some Scene {
        WindowGroup {
//            nameList()
//            NameFeaturedView()
            nameTabview()
        }
    }
}
