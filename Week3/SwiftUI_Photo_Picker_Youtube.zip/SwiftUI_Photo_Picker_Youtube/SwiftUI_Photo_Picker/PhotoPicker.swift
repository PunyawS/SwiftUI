//
//  PhotoPicker.swift
//  SwiftUI_Photo_Picker
//
//  Created by Train2 on 24/1/2565 BE.
//

import SwiftUI

struct PhotoPicker : UIViewControllerRepresentable{
    
    //Protocol to Create UIView
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        return picker
    }
    
    //Protocol to update UIView
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        //
    }
}
