//
//  ContentView.swift
//  SwiftUI_Photo_Picker
//
//  Created by Train2 on 21/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isShowimgPhotoPicker =  false
    
    var body: some View {
        VStack{
            Image(uiImage: UIImage(named: "default-avatar")!)
                .resizable()
                .scaledToFill()
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                .padding()
                .onTapGesture {
                    <#code#>
                }
            
            Spacer()
        }
        .navigationTitle("Profile")
        .sheet(isPresented: $isShowimgPhotoPicker, content: <#T##() -> View#>)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
    NavigationView{
            ContentView()
        }
    .preferredColorScheme(.dark)
    }
}
