//
//  SwiftUI_Photo_PickerApp.swift
//  SwiftUI_Photo_Picker
//
//  Created by Train2 on 21/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_Photo_PickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
