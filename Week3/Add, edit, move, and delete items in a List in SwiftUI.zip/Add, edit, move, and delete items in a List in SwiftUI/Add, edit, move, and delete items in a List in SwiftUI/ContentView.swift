//
//  ContentView.swift
//  Add, edit, move, and delete items in a List in SwiftUI
//
//  Created by Train2 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State var fruits: [String] = [
        "apple", "orange", "banna", "peach"
    ]
    
    @State var veggies: [String] = [
        "tomato", "potato", "carrot"
    ]
    
    var body: some View {
        NavigationView {
            List{
                //fruits
                Section(
                    header:
                        HStack {
                            Text("Fruits Item")
                            Image(systemName: "flame.fill")
                        }
                        .font(.title)
                        .foregroundColor(.blue)
                ) {
                    ForEach(fruits, id: \.self) { fruit in
                        Text(fruit.capitalized)
                            .font(.caption)
                            .foregroundColor(.white)
                            .padding(.vertical)
                    }
                    .onDelete(perform: delete)
//                    .onDelete(perform: {
//                        indexSeet in fruits.remove(atOffsets: indexSeet)
//                    })
                    .onMove(perform: move)
//                    .onMove(perform: {indices, newOffset in
//                        move(indices: indices, newOffset: newOffset)
//                    })
                    .listRowBackground(Color.gray)
                }
                // Veggies
                Section(
                    header:
                        HStack {
                            Text("Veggies Item")
                            Image(systemName: "star.fill")
                        }
                        .font(.title)
                        .foregroundColor(.orange)
                ) {
                    ForEach(veggies, id: \.self) {
                        veggies in
                        Text(veggies.capitalized)
                    }
                }
            }
//            .listStyle(SidebarListStyle())
            .accentColor(.blue)
            .navigationTitle("Grocery List")
            .navigationBarItems(
                leading: EditButton(),
                trailing: addButton)
        }
        .accentColor(.red)
    }
    
    //Add Button
    var addButton : some View{
        Button("Add", action: {
            add()
//                        fruits.append("Coconut")
        })
    }
    
    //Func del
    func delete(indexSet: IndexSet){
        fruits.remove(atOffsets: indexSet)
    }
    
    //func move
    func move(indices: IndexSet, newOffset: Int){
        fruits.move(fromOffsets: indices, toOffset: newOffset)
    }
    //func add
    func add(){
        fruits.append("Coconut")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
