//
//  Add__edit__move__and_delete_items_in_a_List_in_SwiftUIApp.swift
//  Add, edit, move, and delete items in a List in SwiftUI
//
//  Created by Train2 on 19/1/2565 BE.
//

import SwiftUI

@main
struct Add__edit__move__and_delete_items_in_a_List_in_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
