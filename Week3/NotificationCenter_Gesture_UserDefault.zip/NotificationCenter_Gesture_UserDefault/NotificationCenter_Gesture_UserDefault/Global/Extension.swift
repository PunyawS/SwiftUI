//
//  Extension.swift
//  NotificationCenter_Gesture_UserDefault
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import Foundation

extension Notification {
    static let tap_img = Notification.Name.init("tap_img") // กด
    static let long_tap_img = Notification.Name.init("long_tap_img") // กดค้าง
}

struct USDF_Keys {
    static let msg:String = "msg_last"
}


