//
//  NotificationCenter_Gesture_UserDefaultApp.swift
//  NotificationCenter_Gesture_UserDefault
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

@main
struct NotificationCenter_Gesture_UserDefaultApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
