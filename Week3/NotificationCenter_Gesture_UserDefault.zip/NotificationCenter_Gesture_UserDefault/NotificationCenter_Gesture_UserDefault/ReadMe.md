NotificationCenter
- ส่ง NotificationCenter.default.post, บังคับต้องใส่ name, ค่าอื่นไม่บังคับ, userInfo ส่งเป็นอะไรก็ได้ เช่น model แต่ในตัวอย่างส่ง Dictionary
- รับ NotificationCenter.default.publisher, บังคับใส่ name และถ้า userInfo  ไม่เป็นค่าว่าง สามารถดึงค่าจาก userInfo มาใช้งานได้

UserDefaults
ใช้คีย์ในการบันทึก/ลบ/ดึงค่า ข้อมูลมาใช้, ข้อมูลจะหายถ้าลบแอพ
- บันทึก UserDefaults.standard.set
- ลบ UserDefaults.standard.removeObject
- UserDefaults.standard.object ดึงค่ามาใช้ อาจดึงเป็น object อื่นก็ได้ เช่น UserDefaults.standard.bool

onTapGesture
- กดครั้งเดียว ใส่ event
onLongPressGesture
- กดค้าง ใส่ event

Alert 
- สร้าง bool มาเช็คโชว์
- เพิ่มปุ่มที่ต้องการ

onReceive
- จะไม่ทำงาน จนกว่าจะได้รับค่าที่ประกาศไว้
