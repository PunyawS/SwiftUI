//
//  ContentView.swift
//  NotificationCenter_Gesture_UserDefault
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    // รับ NotificationCenter
//    private let noti = NotificationCenter.default.publisher(for: Notification.tap_img) // รับ ตอนกดรูป
//    private let noti_2 = NotificationCenter.default.publisher(for: Notification.long_tap_img) // รับตอนกดรูปค้าง
    
    // https://developer.apple.com/design/resources/
    @State private var image_name:String = "snow"
    @State private var str:String = ContentView.getMsgFromUserdefault()
    
    @State private var showAlert:Bool = false // เช็คโชว์ alert ปุ่มบันทึก
    @State private var showAlert2:Bool = false // เช็คโชว์ alert ปุ่มลบ
    
    var body: some View {
        VStack.init(spacing: 50.0) {

            Image(systemName: image_name)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200,height: 200, alignment: .center)
                .foregroundColor(.black)
                .onTapGesture {
                    // ส่ง NotificationCenter
                    NotificationCenter.default.post(name: Notification.tap_img,
                                                    object: nil, userInfo: ["img": "wifi", "text": "กดรูปสำเร็จ"]) // บังคับต้องใส่ name, ค่าอื่นไม่บังคับ, userInfo ส่งเป็นอะไรก็ได้ เช่น model แต่ในตัวอย่างส่ง Dictionary
//                .onLongPressGesture {
//                   // ส่ง NotificationCenter
//                    NotificationCenter.default.post(name: Notification.long_tap_img,
//                                                    object: nil, userInfo: ["img": "wifi", "text": "กดค้างไว้สำเร็จ"])
            }
            
            Text.init(str).font(.system(size: 20))
            
            HStack {
                Button.init("บันทึก") {
                    showAlert = true
                }.alert("ต้องการบันทึกใช่หรือไม่?", isPresented: $showAlert) {
                    Button.init {
                        self.saveMsgToUserdefault(msg: "ข้อความบันทึกล่าสุด : \(self.str)")
                    } label: {
                        Text.init("ตกลง")
                    }

                    Button.init {
                        
                    } label: {
                        Text.init("ยกเลิก")
                    }
                }
                .frame(width: 100, height: 60)
                .foregroundColor(.white)
                .background(Color.blue)
                
                Button.init("ลบ") {
                    showAlert2 = true
                }.alert("ต้องการลบข้อมูลที่บันทึกไว้\nใช่หรือไม่?", isPresented: $showAlert2) {
                    Button.init {
                        self.removeMsgFromUserdefault()
                        self.str = ContentView.getMsgFromUserdefault()
                    } label: {
                        Text.init("ตกลง")
                    }

                    Button.init {

                    } label: {
                        Text.init("ยกเลิก")
                    }
                }
                .frame(width: 100, height: 60)
                .foregroundColor(.white)
                .background(Color.red)
            }
        }
//        .onReceive(noti) { notification in
        .onReceive(NotificationCenter.default.publisher(for: Notification.tap_img)) { notification in
            if let userInfo = notification.userInfo { // เช็คว่ามีค่ามั้ย
               print(userInfo)
                if let img = userInfo["img"] {
                    self.image_name = "\(img)"
                }
                if let text = userInfo["text"] {
                    self.str = "\(text)"
                }
           }
        }
//        .onReceive(noti_2) { notification in
        .onReceive(NotificationCenter.default.publisher(for: Notification.long_tap_img)) { notification in
            if let userInfo = notification.userInfo { // เช็คว่ามีค่ามั้ย
               print(userInfo)
                if let img = userInfo["img"] {
                    self.image_name = "\(img)"
                }
                if let text = userInfo["text"] {
                    self.str = "\(text)"
                }
           }
        }
    }
    
    static func getMsgFromUserdefault() -> String {
        var str:String = "< กดที่รูปสิ!! >"
        if let str_save = UserDefaults.standard.object(forKey: USDF_Keys.msg) {
            str = "\(str_save)"
        }
//        if UserDefaults.standard.object(forKey: USDF_Keys.msg) != nil {
//            str = "\(UserDefaults.standard.object(forKey: USDF_Keys.msg) ?? "")"
//        }
        return str
    }
    
    func saveMsgToUserdefault(msg:String) {
        UserDefaults.standard.set(msg, forKey: USDF_Keys.msg) // บันทึก ด้วยคีย์
        UserDefaults.standard.synchronize()
    }
    
    func removeMsgFromUserdefault() {
        UserDefaults.standard.removeObject(forKey: USDF_Keys.msg) // ลบ ด้วยคีย์
        UserDefaults.standard.synchronize()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
