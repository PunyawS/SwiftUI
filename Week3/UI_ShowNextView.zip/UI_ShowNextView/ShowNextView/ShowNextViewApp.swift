//
//  ShowNextViewApp.swift
//  ShowNextView
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

@main
struct ShowNextViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
