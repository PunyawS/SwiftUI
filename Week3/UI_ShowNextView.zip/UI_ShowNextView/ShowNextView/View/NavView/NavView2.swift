//
//  NavView2.swift
//  ShowNextView
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct NavView2: View {

    var body: some View {
        ZStack{
            Color.red.ignoresSafeArea()
            Text("NavView2").padding()
        }
    }
}

struct NavView2_Previews: PreviewProvider {
    static var previews: some View {
        NavView2()
    }
}
