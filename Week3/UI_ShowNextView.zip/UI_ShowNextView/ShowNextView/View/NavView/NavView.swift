//
//  NavView.swift
//  ShowNextView
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct NavView: View {

    @Environment(\.presentationMode) private var presentationMode
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.cyan.ignoresSafeArea()
                
                VStack(spacing: 30) {
                    
                    Text("NavView").padding()
                    
                    NavigationLink.init(destination: NavView2()) {
                        Text("ไปหน้าต่อไป")
                    }
                    
                    Button.init("ปิด") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
            .navigationBarHidden(true)
            .navigationTitle("NavView 123")
        }
    }
}

struct NavView_Previews: PreviewProvider {
    static var previews: some View {
        NavView()
    }
}
