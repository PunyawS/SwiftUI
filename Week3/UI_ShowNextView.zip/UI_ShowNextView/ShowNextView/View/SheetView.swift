//
//  SheetView.swift
//  ShowNextView
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct SheetView: View {
    
    @Environment(\.presentationMode) private var presentationMode // ใช้ตอนสั่งปิด

    var body: some View {
        ZStack{
            Color.yellow.ignoresSafeArea()
            
            VStack {
                Text("SheetView").padding()
                Button.init("ปิด") {
                    presentationMode.wrappedValue.dismiss() // สั่ง dismiss() คือปิด
                }
            }
        }
    }
}

struct SheetView_Previews: PreviewProvider {
    static var previews: some View {
        SheetView()
    }
}
