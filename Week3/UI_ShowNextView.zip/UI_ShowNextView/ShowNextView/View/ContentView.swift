//
//  ContentView.swift
//  ShowNextView
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State private var showSheet:Bool = false
    @State private var showFullScreen:Bool = false
    @State private var showNav:Bool = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("การโชว์หน้าถัดไปแต่ละแบบ").font(.system(size: 24))
                .padding()
            
            Button.init("Sheet") {
//                showSheet = true
                showSheet.toggle()
            }.sheet(isPresented: $showSheet, onDismiss: didDismiss) {
//            }.sheet(isPresented: $showSheet) {
                SheetView()
            }
            
            Button.init("Full Screen") {
                showFullScreen.toggle()
//            }.fullScreenCover(isPresented: $showFullScreen, onDismiss: didDismiss) {
            }.fullScreenCover(isPresented: $showFullScreen) {
                FullScreenView()
            }

            Button.init("NavigationView") {
                showNav.toggle()
            }.fullScreenCover(isPresented: $showNav) {
                NavView()
            }

        }
    }
    
    func didDismiss() {
        print("didDismiss....")
        // หลังปิดแล้ว ให้ทำอะไรต่อเพิ่มโค้ดไป
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
