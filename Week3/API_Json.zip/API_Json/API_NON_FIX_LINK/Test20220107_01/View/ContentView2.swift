//
//  ContentView2.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI
struct ContentView2: View {
    
    @ObservedObject var apiILoader = APILoader()
    //รับ path มา จาาการกดหน้าแรก
    var path:String = ""
    
    var body: some View {
        List(apiILoader.next_list){ next_list in
            Text(next_list.title)
        }.onAppear() {
            apiILoader.loadData2(path: path)
        }
    }
}

struct ContentView2_Previews: PreviewProvider {
    static var previews: some View {
        ContentView2()
    }
}
