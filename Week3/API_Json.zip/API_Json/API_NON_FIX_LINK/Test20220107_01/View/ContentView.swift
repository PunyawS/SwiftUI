//
//  ContentView.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI
struct ContentView: View {
    
    @ObservedObject var apiILoader = APILoader()
    
    var body: some View {
        
        NavigationView{
            //Check load data complete or not
            if !apiILoader.loading {
                List(apiILoader.index){ index in
                    //go to link web
                    if index.open_web == true{
                        NavigationLink(destination:{
                            WebView.init(path: index.link)
                        }, label: {
                            Text(index.title).foregroundColor(.red)
                        })
                        //go to list title
                    } else if index.open_list == true {
                        NavigationLink(destination:{
                            //ContentView2 link second page
                            ContentView2.init(path: index.link)
                                .navigationTitle(index.title)
                        }, label: {
                            Text(index.title).foregroundColor(.blue)
                        })
                    }
                }
            }
        }.onAppear() {
            //load path in AppConfig
            apiILoader.loadData(path: API_Index)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
