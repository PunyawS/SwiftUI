//
//  WebView.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {

    private let wkWebview = WKWebView()
    var path: String

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        webView.load(URLRequest.init(url: URL.init(string: path)!))
    }
}
