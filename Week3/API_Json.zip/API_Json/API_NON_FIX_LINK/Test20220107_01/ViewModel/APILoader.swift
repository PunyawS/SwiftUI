//
//  APILoader.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import Foundation

class APILoader: ObservableObject {
    
    @Published var index = [Index]()
    @Published var next_list = [NextList]()
    @Published var loading:Bool = false
    
    init() {
//        loadData()
    }
    
    //input path to func
    func loadData(path:String) {
        guard let url = URL(string: path) else { return }
        
        //check load complete
        loading = true
        URLSession.shared.dataTask(with: URLRequest.init(url: url)) { data, _, err in
            
            if let errResponse = err {
                self.loading = false
                print(errResponse.localizedDescription)
                return
            }
            
            guard let dataReponse = data else { return }
            let indexResponse_default = try? JSONDecoder().decode([Index].self, from: dataReponse)
            DispatchQueue.main.async {
                if let indexResponse = indexResponse_default {
                    self.index = indexResponse
                }
                print("self.index : \(self.index)")
                //check load complete
                self.loading = false
            }
        }.resume()
    }
    
    //second load page 2
    func loadData2(path:String) {
        guard let url = URL(string: path) else { return }
        
        loading = true
        URLSession.shared.dataTask(with: URLRequest.init(url: url)) { data, _, err in
            
            if let errResponse = err {
                self.loading = false
                print(errResponse.localizedDescription)
                return
            }
            
            guard let dataReponse = data else { return }
            let indexResponse_default = try? JSONDecoder().decode([NextList].self, from: dataReponse)
            DispatchQueue.main.async {
                if let indexResponse = indexResponse_default {
                    self.next_list = indexResponse
                }
                print("self.next_list : \(self.next_list)")
                self.loading = false
            }
        }.resume()
    }
}
