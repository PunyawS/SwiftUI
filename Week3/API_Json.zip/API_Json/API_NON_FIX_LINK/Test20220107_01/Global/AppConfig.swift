//
//  AppConfig.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import Foundation

//Link Domain
//Fix link
//ID Application
let API_Index:String = "https://jsonkeeper.com/b/6HZ9"
