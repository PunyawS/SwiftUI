//
//  Test20220107_01App.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

@main
struct Test20220107_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
