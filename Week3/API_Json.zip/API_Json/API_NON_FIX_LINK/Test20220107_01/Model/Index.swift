//
//  Index.swift
//  Test20220107_01
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import Foundation

//Frist Page
struct Index: Decodable, Identifiable {
    enum CodingKeys: CodingKey{
        case menu_id
        case title
        case open_web
        case open_list
        case link
    }
    var id = UUID()
    var menu_id : Int
    var title : String
    var open_web : Bool
    var open_list : Bool
    var link : String
}


//Second Page
struct NextList: Decodable, Identifiable {
    var id: Int
    var title: String
    var open_web: Bool
    var link: String
}
