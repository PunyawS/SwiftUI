//
//  LinktoJson.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import Foundation

struct Menumain: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case menu_id
        case title
        case open_web
        case open_list
        case link
        case list_data
    }
    
    var id = UUID()
    var menu_id: Int
    var title: String
    var open_web: Bool
    var open_list: Bool
    var link: String?
    var list_data: [array_list]?
}
