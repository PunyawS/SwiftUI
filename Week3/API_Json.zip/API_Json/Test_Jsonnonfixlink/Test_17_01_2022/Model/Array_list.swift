//
//  ATK.swift
//  Week2_Test_ATK
//
//  Created by Train2 on 14/1/2565 BE.
//

import Foundation

struct array_list: Codable, Identifiable{
    enum CodingKeys: CodingKey {
        case id
        case title
        case open_web
        case link
    }
    
    var ids = UUID()
    var id: Int
    var title: String
    var open_web: Bool
    var link: String
}

