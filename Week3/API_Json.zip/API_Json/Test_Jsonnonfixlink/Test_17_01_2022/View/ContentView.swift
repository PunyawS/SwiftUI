//
//  ContentView.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    //ReadAPI page 1
    @ObservedObject var readmenu = ConvertMenu()
    
    //showWeb
    @State private var showWeb:Bool = false
    
    var body: some View {
        NavigationView{
            
            if #available(iOS 15.0, *){
                List(readmenu.Pub_mainmenu){ index in
                    
                    //open_web == true, Go to Weblink
                    if index.open_web == true{
                        NavigationLink(destination:{ WebView.init(path: URL(string: index.link ?? "")!)
                        }, label: {
                            Text(index.title).foregroundColor(.red)
                        })
                    }
                    //open_web == false, make this condition
                    else if index.open_list == true{
                        //link is not nil, Go to go to arraylist and open json
                        // if let kkk = index.link ถ้่า kkk มีค่าจึงจะทำในวงเล็บ {openlink}
                        //else if let kkk = index.list_data {showlist}
                        if index.link != nil {
                            NavigationLink(destination: {
                                APIListView(jsonpath: index.link!)
                            }, label: {
                                Text(index.title)
                                    .foregroundColor(.blue)
                            })
                        }
                        //link is nil, Go to
                        // else if index.list_data != nil {}
                        else {
                            NavigationLink(destination: {
                                List(index.list_data!) { item in
                                    Text(item.title)
                                }
                            }, label: {
                                Text(index.title)
                            })
                        }
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
