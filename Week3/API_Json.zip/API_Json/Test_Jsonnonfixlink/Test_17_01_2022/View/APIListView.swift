//
//  APIListView.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import SwiftUI

struct APIListView: View {
    
    //ReadAPI Page 2
    @ObservedObject var arrayData = ConvertArray()
    var jsonpath = ""
    
    var body: some View {
        List(arrayData.Pub_arraylist) { item in
            Text(item.title)
        }
        .onAppear {
            arrayData.loadData(path: jsonpath)
        }
    }
}

struct APIListView_Previews: PreviewProvider {
    static var previews: some View {
        APIListView(/*jsonpath: "https://jsonkeeper.com/b/4ASX"*/)
    }
}
