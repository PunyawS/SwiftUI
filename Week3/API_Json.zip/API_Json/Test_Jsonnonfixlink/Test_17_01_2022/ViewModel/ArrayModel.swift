//
//  ConvertAPI2.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import Foundation

class ConvertArray : ObservableObject{
    
    @Published var Pub_arraylist = [array_list]()
//    @Published var loading = false //checkloading
    
    init(){

    }
    //page 2
    func loadData(path: String){
//        loading = true
        guard let url = URL(string: path) else { return }
        
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            //check error
            if let error_err = error{
                print(error_err.localizedDescription)
                return
            }
            if let ArraylistData = data{
                let decodeData = try? JSONDecoder().decode([array_list].self, from: ArraylistData)
                DispatchQueue.main.async {
                    self.Pub_arraylist = decodeData!
                }
                print(self.Pub_arraylist)
            }
        }.resume()
    }
}


