//
//  ConvertAPI.swift
//  Week2_Test_ATK
//
//  Created by Train2 on 14/1/2565 BE.
//

import Foundation

class ConvertMenu: ObservableObject{
    
    @Published var Pub_mainmenu = [Menumain]()
//    @Published var loading = false //checkloading
    
    init(){
//        loading = true //checkloading
        loadData()
    }
    
    func loadData(){
//        loading = true
        guard let path = URL(string: "https://jsonkeeper.com/b/RBV1") else {return}
        
        URLSession.shared.dataTask(with: URLRequest(url: path)) {(data, response, error) in
            //check error
            if let error_err = error{
                print(error_err.localizedDescription)
                return
            }
            if let MenumainData = data{
                let decodeData = try? JSONDecoder().decode([Menumain].self, from: MenumainData)
                DispatchQueue.main.async {
                    self.Pub_mainmenu = decodeData!
                }
                print(self.Pub_mainmenu)
            }
        }.resume()
    }
}
