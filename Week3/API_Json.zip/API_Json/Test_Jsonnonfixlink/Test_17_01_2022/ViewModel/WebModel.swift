//
//  WebModel.swift
//  Week2_Test_ATK
//
//  Created by Train2 on 14/1/2565 BE.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {

    private let wkWebview = WKWebView()
    var path: URL

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        webView.load(URLRequest.init(url: path))
    }
}
