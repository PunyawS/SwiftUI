//
//  ListModel.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import Foundation

struct Lists: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case id
        case title
        case open_web
        case link
    }
    
    var ids = UUID()
    var id: Int
    var title: String
    var open_web: Bool
    var link: String
}
