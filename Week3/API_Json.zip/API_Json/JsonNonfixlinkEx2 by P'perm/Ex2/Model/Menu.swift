//
//  MenuModel.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import Foundation

struct Menu: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case menu_id
        case title
        case open_web
        case open_list
        case link
        case list_data
    }
    
    var id = UUID()
    var menu_id: Int
    var title: String
    var open_web: Bool
    var open_list: Bool
    var link: String?
    var list_data: [Lists]?
}

