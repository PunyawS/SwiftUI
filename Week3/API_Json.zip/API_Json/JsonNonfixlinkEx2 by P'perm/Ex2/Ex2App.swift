//
//  Ex2App.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import SwiftUI

@main
struct Ex2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
