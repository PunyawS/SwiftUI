//
//  ListModel.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import Foundation

class ListModel: ObservableObject {
    @Published var ListList = [Lists]()
    
    init() {
        
    }
    
    func loadData(path: String) {
        guard let url = URL(string: path) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
            if let err_check = error {
                print(err_check.localizedDescription)
                return
            }
            
            guard let ListData = data else { return }
            
            let DecodedData_Default = try? JSONDecoder().decode([Lists].self, from: ListData)
            
            if let DecodedData = DecodedData_Default {
                self.ListList = DecodedData
            }
            print(self.ListList)
        }.resume()
    }
}
