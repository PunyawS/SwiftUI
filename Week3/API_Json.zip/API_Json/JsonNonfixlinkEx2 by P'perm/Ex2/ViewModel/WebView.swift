//
//  WebView.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import Foundation
import WebKit
import SwiftUI

struct WebView: UIViewRepresentable {
    private let wkWebView = WKWebView()
    var url: URL
    
    
    func makeUIView(context: Context) -> WKWebView {
        return wkWebView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.load(URLRequest(url: url))
    }
}
