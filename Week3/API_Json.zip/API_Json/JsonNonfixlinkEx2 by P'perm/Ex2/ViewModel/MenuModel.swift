//
//  MenuModel.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import Foundation
import SwiftUI

class MenuModel: ObservableObject {
    @Published var Menus = [Menu]()
    
    init() {
        loadData()
    }
    
    func loadData() {
        guard let path = URL(string: "https://jsonkeeper.com/b/RBV1") else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: path)) { data, response, error in
            if let err_check = error {
                print(err_check.localizedDescription)
                return
            }
            
            guard let MenuData = data else { return }
            
            let decodedMenuData_Default = try? JSONDecoder().decode([Menu].self, from: MenuData)
          
            if let decodedMenuData = decodedMenuData_Default {
                self.Menus = decodedMenuData
            }

            print(self.Menus)
        }.resume()
    }
}
