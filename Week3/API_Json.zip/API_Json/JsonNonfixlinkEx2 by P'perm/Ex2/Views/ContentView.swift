//
//  ContentView.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var MenuData = MenuModel()
    
    
    var body: some View {
        NavigationView {
            List(MenuData.Menus) { item in
                //Text(item.title)
                
                if item.open_web == true {
                    NavigationLink(destination: {
                        WebView.init(url: URL(string: item.link ?? "")!)
                    }, label: {
                        Text(item.title)
                            .foregroundColor(.red)
                    })
                } else {
                    if item.link != nil {
                        NavigationLink(destination: {
                            APIListView(jsonpath: item.link!)
                        }, label: {
                            Text(item.title)
                                .foregroundColor(.blue)
                        })
                    } else {
                        NavigationLink(destination: {
                            List(item.list_data!) { item2 in
                                Text(item2.title)
                            }
                        }, label: {
                            Text(item.title)
                        })
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
