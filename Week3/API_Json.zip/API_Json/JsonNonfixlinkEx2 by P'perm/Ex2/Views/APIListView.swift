//
//  APIListView.swift
//  Ex2
//
//  Created by Train3 on 17/1/2565 BE.
//

import SwiftUI

struct APIListView: View {
    
    @ObservedObject var ListData = ListModel()
    var jsonpath = ""
    
    var body: some View {
        List(ListData.ListList) { item in
            Text(item.title)
        }
        .onAppear {
            ListData.loadData(path: jsonpath)
        }
    }
}

struct APIListView_Previews: PreviewProvider {
    static var previews: some View {
        APIListView(jsonpath: "https://jsonkeeper.com/b/4ASX")
    }
}
