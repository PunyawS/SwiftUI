//
//  Test_17_01_2022App.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import SwiftUI

@main
struct Test_17_01_2022App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
