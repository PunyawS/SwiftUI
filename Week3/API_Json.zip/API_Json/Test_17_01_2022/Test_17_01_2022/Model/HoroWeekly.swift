//
//  ATK.swift
//  Week2_Test_ATK
//
//  Created by Train2 on 14/1/2565 BE.
//

import Foundation

struct WeeklyHoro: Decodable, Identifiable{
    enum CodingKeys: CodingKey{
        case menu_id
        case title
        case open_web
        case open_list
        case link
    }
    
    var id = UUID()
    var menu_id : Int
    var title : String
    var open_web : Bool
    var open_list : Bool
    var link : String
}

