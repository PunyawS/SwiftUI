//
//  LinktoJson.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import Foundation

struct linkToJson: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case id
        case title
        case open_web
        case link
    }
    
    var idn = UUID()
    var id: Int
    var title: String
    var open_web: Bool
    var link: String
}
