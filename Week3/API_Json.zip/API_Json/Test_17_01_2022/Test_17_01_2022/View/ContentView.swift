//
//  ContentView.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    //ReadAPI
    @ObservedObject var ReadData = ConvertAPI()
    
    //ReadAPI2
    @ObservedObject var ReadData2 = ConvertAPI2()
    
    //showWeb
    @State private var showWeb:Bool = false
    
    var body: some View {
        
        NavigationView{
            if #available(iOS 15.0, *){
                List(ReadData.Pub_API){ index in
                    if index.open_web == true{
                        NavigationLink(destination:{ webModel.init(HoroWeblink: index)
                        }, label: {
                            Text(index.title).foregroundColor(.red)
                        })
                    }
                    else if index.open_list == true{
                        NavigationLink(destination:{ List(ReadData2.Pub_API2){ index2 in
                            Text(index2.title)
                        }
                        }, label: {
                            Text(index.title).foregroundColor(.blue)
                        })
                    }
                }
            }
        }

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
