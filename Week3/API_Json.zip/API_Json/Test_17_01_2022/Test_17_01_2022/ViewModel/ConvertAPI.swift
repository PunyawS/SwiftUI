//
//  ConvertAPI.swift
//  Week2_Test_ATK
//
//  Created by Train2 on 14/1/2565 BE.
//

import Foundation

class ConvertAPI: ObservableObject{
    
    @Published var Pub_API = [WeeklyHoro]()
//    @Published var loading = false //checkloading
    
    init(){
//        loading = true //checkloading
        loadData()
    }
    
    func loadData(){
//        loading = true
        let url = URL(string: "https://jsonkeeper.com/b/6HZ9")!
        
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            //check error
            if let error_err = error{
                print(error_err.localizedDescription)
                return
            }
            if let WeeklyHoroData = data{
                let decodeData = try? JSONDecoder().decode([WeeklyHoro].self, from: WeeklyHoroData)
                DispatchQueue.main.async {
                    self.Pub_API = decodeData!
                }
                print(self.Pub_API)
            }
        }.resume()
    }
}
