//
//  ConvertAPI2.swift
//  Test_17_01_2022
//
//  Created by Train2 on 17/1/2565 BE.
//

import Foundation

class ConvertAPI2: ObservableObject{
    
    @Published var Pub_API2 = [linkToJson]()
//    @Published var loading = false //checkloading
    
    init(){
//        loading = true //checkloading
        loadData()
    }
    
    func loadData(){
//        loading = true
        let url = URL(string: "https://jsonkeeper.com/b/4ASX")!
        
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            //check error
            if let error_err = error{
                print(error_err.localizedDescription)
                return
            }
            if let linkToJsonData = data{
                let decodeData = try? JSONDecoder().decode([linkToJson].self, from: linkToJsonData)
                DispatchQueue.main.async {
                    self.Pub_API2 = decodeData!
                }
                print(self.Pub_API2)
            }
        }.resume()
    }
}


