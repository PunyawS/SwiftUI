//
//  ContentView.swift
//  URLSchemes
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Link.init(destination: URL.init(string: "testSetSchemes01://")!) {
            Text.init("Open other app").foregroundColor(.red)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
