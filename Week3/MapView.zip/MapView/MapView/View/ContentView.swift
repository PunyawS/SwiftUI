//
//  ContentView.swift
//  MapView
//
//  Created by Macbook16 on 20/1/2565 BE.
//

import SwiftUI
import MapKit

struct ContentView: View {
    var body: some View {
        MapView().clipped()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

