//
//  MapViewApp.swift
//  MapView
//
//  Created by Macbook16 on 20/1/2565 BE.
//

import SwiftUI

@main
struct MapViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
