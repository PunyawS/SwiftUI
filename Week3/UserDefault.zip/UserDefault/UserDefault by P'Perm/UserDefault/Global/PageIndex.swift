//
//  PageIndex.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import Foundation

class PageIndex: ObservableObject {
    @Published var page = 0
}
