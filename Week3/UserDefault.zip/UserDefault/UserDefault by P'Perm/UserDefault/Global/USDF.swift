//
//  USDF_keys.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import Foundation

struct USDF_Keys {
    static let addData: String = "add_data"
    
    static let listData: String = "list_data"
    static let listData2: String = "list_data2"
}
