//
//  UserDefaultApp.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import SwiftUI

@main
struct UserDefaultApp: App {
    var body: some Scene {
        
        WindowGroup {
          
            ContentView()
        }
    }
}
