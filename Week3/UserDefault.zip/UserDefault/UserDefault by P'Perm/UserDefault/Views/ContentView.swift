//
//  ContentView.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var pageindex = PageIndex()
    @State private var Presserd: Bool = false
    
    var body: some View {
        ZStack {
            //bg
            Color.cyan
                .scaledToFill()
                .ignoresSafeArea(.all)
            
            VStack(spacing: 30) {
                
                //pic
                Image(systemName: "snow")
                    .resizable()
                    .frame(width: 150 , height: 150, alignment: .center)
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(.white)
                    .onTapGesture(count: 2) {
                        Presserd = true
                        pageindex.page = 1
                    }
                    .onLongPressGesture(minimumDuration: 1) {
                        Presserd = true
                        pageindex.page = 2
                    }
                    .sheet(isPresented: $Presserd) {
                        if pageindex.page == 1 {
                            AddDataView()
                        }
                        if pageindex.page == 2 {
                            ListView()
                        }
                    }
                
                //text
                Text("กดที่รูป 2 ครั้งเพื่อเริ่มใช้งาน")
                    .foregroundColor(.white)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
