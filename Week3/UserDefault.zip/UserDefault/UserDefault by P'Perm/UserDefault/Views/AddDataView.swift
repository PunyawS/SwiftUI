//
//  AddData.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import Foundation
import SwiftUI

struct AddDataView: View {
    
    @State var inputData = ""
    @State var strData = AddDataView.getDataFromUSDF()
    
    @State var dataList = AddDataView.getListDataFromUSDF()
    
    @State var toListView: Bool = false
    
    //for close sheet
    //@Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            ZStack {
                //bg
                Color.cyan
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                
                VStack(spacing: 30) {
                    //input
                    TextField("inputData", text: $inputData)
                        .frame(width: 250, height: 50, alignment: .center
                        )
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .font(.title2)
                        .multilineTextAlignment(.center)
                    
                    NavigationLink(destination:
                        ListView()
                    , isActive: $toListView , label: {

                    })
                    
                    //button
                    Button(action: {
                        
                        //set str data to user default
                        UserDefaults.standard.set(inputData, forKey: USDF_Keys.addData)
                        
                        //set array to user default
                        addData(data: inputData)
                        UserDefaults.standard.set(dataList, forKey: USDF_Keys.listData2)
                        UserDefaults.standard.synchronize()
                        
                        toListView = true
                        
                        //close sheet
                        //self.presentationMode.wrappedValue.dismiss()
                        
                    }, label: {
                        Text("เพิ่มข้อมูล")
                            .frame(width: 110, height: 40, alignment: .center)
                            .background(.black)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    })
                }
            }
        }
        .onAppear {
            dataList = AddDataView.getListDataFromUSDF()
        }
    }
    
    static func getDataFromUSDF() -> String {
        var str: String = "show data"
        if let strData = UserDefaults.standard.object(forKey: USDF_Keys.addData) {
            str = "\(strData)"
        }
        return str
    }
    
    static func getListDataFromUSDF() -> [String] {
        var lists = [String]()
        if let listData = UserDefaults.standard.array(forKey: USDF_Keys.listData2) {
            //print("1: \(listData)")
            lists = listData as! [String]
        }
        //print(lists)
        return lists
    }
    
    func addData(data: String) {
        //dataList.append(data)
        dataList.insert(data, at: 0)
    }
}

struct AddDataView_Previews: PreviewProvider {
    static var previews: some View {
        AddDataView()
    }
}
