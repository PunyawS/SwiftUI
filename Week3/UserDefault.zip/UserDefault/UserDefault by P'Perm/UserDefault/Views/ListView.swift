//
//  ListView.swift
//  UserDefault
//
//  Created by Train3 on 18/1/2565 BE.
//

import Foundation
import SwiftUI

struct ListView: View {
    
    @State var dataList = [String]()
    
    var body: some View {
        VStack {
            Text("รายชื่อผู้ใช้งาน")
            
            List {
                ForEach(dataList, id: \.self) { item in
                    Text(item)
                }
                .onDelete(perform: removeRows)
            }
            .onAppear {
                dataList = ListView.getListDataFromUSDF()
            }
        }
    }
    
    static func getListDataFromUSDF() -> [String] {
        var lists: [String] = []
        if let listData = UserDefaults.standard.array(forKey: USDF_Keys.listData2) {
            lists = listData as! [String]
        }
        print("list view\(lists)")
        return lists
    }

    func removeRows(at offsets: IndexSet) {
        dataList.remove(atOffsets: offsets)
        print("after remove: \(dataList)")
        UserDefaults.standard.set(dataList, forKey: USDF_Keys.listData2)
        UserDefaults.standard.synchronize()
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
