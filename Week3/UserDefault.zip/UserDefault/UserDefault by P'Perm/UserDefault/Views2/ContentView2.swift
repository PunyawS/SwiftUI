//
//  ContentView2.swift
//  UserDefault
//
//  Created by Train3 on 19/1/2565 BE.
//



import SwiftUI

struct ContentView2: View {
    
    @State var gotoAddData: Bool = false
    
    var body: some View {
        
        NavigationView {
            ZStack {
                //bg
                Color.cyan
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                
                VStack(spacing: 30) {
                    
                    //pic
                    Image(systemName: "snow")
                        .resizable()
                        .frame(width: 150 , height: 150, alignment: .center)
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .onTapGesture(count: 2) {
                            gotoAddData = true
                        }
                        
                    
                    //text
                    Text("กดที่รูป 2 ครั้งเพื่อเริ่มใช้งาน")
                        .foregroundColor(.white)
                }
                
                //NavigationLink
            }
        }
    }
}

struct ContentView2_Previews: PreviewProvider {
    static var previews: some View {
        ContentView2()
    }
}
