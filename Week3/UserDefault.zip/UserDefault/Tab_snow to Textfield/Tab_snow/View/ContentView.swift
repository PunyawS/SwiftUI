//
//  ContentView.swift
//  Tab_snow
//
//  Created by Train2 on 18/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    //Show imagesnow
    @State private var image_name:String = "snow"
    
    @State private var str:String = ContentView.getMsgFromUserdefault()
    
//    @State private var showAlert:Bool = false // เช็คโชว์ alert ปุ่มบันทึก
//    @State private var showAlert2:Bool = false // เช็คโชว์ alert ปุ่มลบ
    
    //Color
    static let skyBlue = Color(red: 0.4627, green: 0.8392, blue: 1.0)
    
    //go to text fieal
    @State private var can_next = false
    
    var body: some View {
        
        NavigationView{
            //UI
            ZStack {
                ContentView.skyBlue
                
                    .ignoresSafeArea(.all)
                VStack(spacing: 50.0){
                    
                    //go to TextFieldView
                    NavigationLink(destination: TextFieldView.init(), isActive: $can_next) {
                        EmptyView()
                    }
                    
                    //Show imagesnow
                    Image(systemName: image_name)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200,height: 200, alignment: .center)
                        .foregroundColor(.white)
                    //tab snow 2 time
                        .onTapGesture(count: 2) {
                            self.can_next = true
                        }
                    
                    //return string func
                    Text.init(str).font(.system(size: 20)).foregroundColor(.white)
                }
            }
            .navigationBarHidden(true)
        }
    }

    
    //Create func return String
    static func getMsgFromUserdefault() -> String {
        var str:String = "กดที่รูป 2 ครั้งเพื่อใช้งาน"
        if let str_save = UserDefaults.standard.object(forKey: USDF_Keys.Showmsg) {
            str = "\(str_save)"
        }
        return str
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
