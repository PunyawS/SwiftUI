//
//  TextFieldView.swift
//  Tab_snow
//
//  Created by Train2 on 18/1/2565 BE.
//

import SwiftUI

struct TextFieldView: View {
    
    
    var body: some View {
        
        ZStack {
            ContentView.skyBlue
                .ignoresSafeArea()
            
            VStack{

                TextField("Type something....", text: $textInput)
                    .padding()
                    .background(Color.gray.opacity(0.3).cornerRadius(10))
                    .foregroundColor(.red)

                Button(action: {
                    
                    saveText()
                    
                }, label: {
                    Text("Save")
                        .padding()
                        .frame(maxWidth:.infinity)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(20)
                    
                }).padding(.top)
                //List text
                List{
                    ForEach(dataArray, id: \.self) { data in
                        Text(data)
                    }
                    .onDelete {
                        offsets in
                        dataArray.remove(atOffsets: offsets)
                        //Code delete userdefual remove
                        removeTextFromUserdefault()
                    }
                }
                .onAppear(perform: saveText)
                .cornerRadius(20)
                .toolbar {EditButton()}
            }.padding()
        }
    }
    
    //datainput
    @State var textInput = ""
    @State var dataArray : [String] = []
    
    func saveText(){
        //connect aaa to Userdefaults -> username_list and then save value of aaa in dataArray
        if let aaa = UserDefaults.standard.object(forKey: USDF_Keys.username_list){
            //now dataArray connect with USDF_Keys.username_list
            dataArray = aaa as! [String]
        }
        
        //add array to list -> When add new text show first
        dataArray.insert(textInput, at: 0)
        
        //check add Text in dataArray
        print(dataArray)
       
        //check dataArray > 0, save text to dataArray to userdefault then addArray
        if dataArray.count > 0{
            UserDefaults.standard.set(dataArray, forKey: USDF_Keys.username_list)
            UserDefaults.standard.synchronize()
        }
        textInput = ""
    }
    
    //remove dataArray
    func removeTextFromUserdefault() {
        UserDefaults.standard.removeObject(forKey: USDF_Keys.username_list) // ลบ ด้วยคีย์
        UserDefaults.standard.synchronize()
        
        //Check remove Text of dataArray
        print(dataArray)
    }
}


struct TextFieldView_Previews: PreviewProvider {
    static var previews: some View {
        TextFieldView()
    }
}
