//
//  Tab_snowApp.swift
//  Tab_snow
//
//  Created by Train2 on 18/1/2565 BE.
//

import SwiftUI

@main
struct Tab_snowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
