//
//  ContentView.swift
//  Test20220118_01
//
//  Created by Macbook16 on 18/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State var selectedImg:Bool = false
    @State var isLogin:Bool = false
    @State var username:String = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.cyan.ignoresSafeArea()
                VStack (spacing : 30) {
                    if selectedImg {
                        TextField("ใส่ชื่อผู้ใช้งาน", text: $username)
                            .frame(width: 300, height: 60)
                            .background(.white)
                            .cornerRadius(10)
                            .font(.system(size: 30))
                            .multilineTextAlignment(.center)
                        
                        /*
                         // แบบ 1
                        NavigationLink(destination: IndexContentView.init(), isActive: $isLogin) {
                            Button(action: {
                                UserDefaultManager.save(username: username)
                                isLogin = true
                            }, label: {
                                Text("เพิ่มข้อมูล")
                                    .fontWeight(.bold)
                                    .frame(width: 100, height: 60)
                                    .foregroundColor(.white)
                                    .background(.black)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            })
                        }
                        */
                        
                        // แบบ 2
                        NavigationLink(destination: IndexContentView.init(), isActive: $isLogin) {
                            EmptyView ()
                        }
                        Button(action: {
                            UserDefaultManager.save(username: username)
                            isLogin = true
                        }, label: {
                            Text("เพิ่มข้อมูล")
                                .fontWeight(.bold)
                                .frame(width: 100, height: 60)
                                .foregroundColor(.white)
                                .background(.black)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        })
                        
                    }else{
                        Image(systemName: "snow")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 200,height: 200, alignment: .center)
                            .foregroundColor(.white)
                            .onTapGesture(count: 2) {
                                selectedImg = true
                            }
                        Text("กดที่รูป 2 ครั้งเพื่อเริ่มใช้งาน")
                            .foregroundColor(.white).font(.system(size: 20))
                            .padding()
                    }
                }
            }
        }.navigationBarHidden(true)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
