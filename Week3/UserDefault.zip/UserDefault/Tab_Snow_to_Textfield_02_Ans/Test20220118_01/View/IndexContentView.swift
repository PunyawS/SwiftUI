//
//  IndexContentView.swift
//  Test20220118_01
//
//  Created by Macbook16 on 18/1/2565 BE.
//

import SwiftUI

struct IndexContentView: View {
    
    @State private var username_list:[String] = []
    
    var body: some View {
        VStack {
            List{
                ForEach(username_list, id: \.self) { username in
                    Text(username)
                }
                
                // แบบ 1
                .onDelete(perform: delete)
                
                // แบบ 2
//                .onDelete { offsets in
//                    delete(at: offsets)
//                }
            }
            
            // จะทำงานเมื่อโชว์หน้านี้เท่านั้น
            .onAppear {
                username_list = UserDefaultManager.getList()
            }
            
        }.navigationTitle("รายชื่อผู้ใช้งาน")
    }
    
    func delete(at offsets: IndexSet) {
        username_list.remove(atOffsets: offsets)
        UserDefaultManager.remove(idx: offsets)
    }
}

struct IndexContentView_Previews: PreviewProvider {
    static var previews: some View {
        IndexContentView()
    }
}
