//
//  UserDefaultManager.swift
//  Test20220118_01
//
//  Created by Macbook16 on 18/1/2565 BE.
//

import Foundation

class UserDefaultManager: ObservableObject{
    
    static func getList() -> [String] {
        var arr:[String] = []
        if let arr_old = UserDefaults.standard.object(forKey: USDF_Keys.username_list) {
            arr = arr_old as! [String]
        }
//        if UserDefaults.standard.object(forKey: USDF_Keys.username_list) != nil {
//            arr = (UserDefaults.standard.object(forKey: USDF_Keys.username_list) as! [String])
//        }
        print("getLogin arr :: \(arr)")
        return arr

        /*
        if let arr_old = UserDefaults.standard.object(forKey: USDF_Keys.username_list) {
            return arr_old as! [String]
        }else{
            return []
        }
        */
    }
    
    static func save(username:String) {
        /*
        var arr:[String] = []
        if let arr_old = UserDefaults.standard.object(forKey: USDF_Keys.username_list) {
            arr = arr_old as! [String]
        }
        */
        var arr:[String] = UserDefaultManager.getList()
        arr.insert(username, at: 0)
        UserDefaults.standard.set(arr, forKey: USDF_Keys.username_list)
        UserDefaults.standard.synchronize()
    }
    
    static func remove(idx:IndexSet) {
        var arr:[String] = []
        if let arr_old = UserDefaults.standard.object(forKey: USDF_Keys.username_list) {
            arr = arr_old as! [String]
            arr.remove(atOffsets: idx)
        }
        if arr.count > 0 {
            UserDefaults.standard.set(arr, forKey: USDF_Keys.username_list)
            UserDefaults.standard.synchronize()
        }else{
            UserDefaults.standard.removeObject(forKey: USDF_Keys.username_list)
            UserDefaults.standard.synchronize()
        }
    }
}
