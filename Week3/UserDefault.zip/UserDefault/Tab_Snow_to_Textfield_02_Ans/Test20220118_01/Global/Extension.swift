//
//  Extension.swift
//  Test20220118_01
//
//  Created by Macbook16 on 18/1/2565 BE.
//

import Foundation

struct USDF_Keys {
    static let username_list:String = "username_list"
}
