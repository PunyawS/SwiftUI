//
//  Test20220118_01App.swift
//  Test20220118_01
//
//  Created by Macbook16 on 18/1/2565 BE.
//

import SwiftUI

@main
struct Test20220118_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
