//
//  NotificationCenter_ExApp.swift
//  NotificationCenter_Ex
//
//  Created by Train2 on 19/1/2565 BE.
//

import SwiftUI

@main
struct NotificationCenter_ExApp: App {
    var body: some Scene {
        WindowGroup {
            showTabView()
        }
    }
}
