//
//  aaaa.swift
//  Tab_snow
//
//  Created by Train2 on 19/1/2565 BE.
//

import Foundation

struct USDF_Keys {
    static let Showmsg = "hello"
}
