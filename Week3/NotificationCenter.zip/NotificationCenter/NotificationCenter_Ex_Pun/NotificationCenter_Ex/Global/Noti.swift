//
//  Extension.swift
//  Tab_snow
//
//  Created by Train2 on 18/1/2565 BE.
//

import Foundation

extension Notification {
    
    //use change image
    static let tap_img = Notification.Name.init("tap_img") // กด
    
    //use change background
    static let chang = Notification.Name.init("chan_g")
}

