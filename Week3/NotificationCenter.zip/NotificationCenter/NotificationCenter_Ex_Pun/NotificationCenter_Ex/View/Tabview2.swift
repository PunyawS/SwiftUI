//
//  Tabview2.swift
//  NotificationCenter_Ex
//
//  Created by Train2 on 19/1/2565 BE.
//

import SwiftUI

struct tabView2: View {
    
    private let arr_color:[Color] = [Color.red, Color.yellow, Color.green, Color.cyan]
    @State var bg_color = Color.white
    
    var body: some View {
        NavigationView{
            ZStack {
                bg_color
                    .edgesIgnoringSafeArea(.all)
                
                Button(action: {
                    //random color
                    bg_color = arr_color[Int.random(in: 0..<arr_color.count)]
                    
                    //NotificationCenter send
                    //name notification อันไหนที่ต้องการเปลี่ยน
                    //object คือ สิ่งที่ต้องการส่งไปเปลี่ยนใน Noification
                    NotificationCenter.default.post(name: Notification.chang, object: bg_color)
                }, label: {
                    Text("Button")
                        .foregroundColor(.white)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(25)
                })
            }
        }
    }
}

struct tabView2_Previews: PreviewProvider {
    static var previews: some View {
        tabView2()
    }
}
