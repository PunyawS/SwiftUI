//
//  ContentView.swift
//  NotificationCenter_Ex
//
//  Created by Train2 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State private var image_name:String = "snow"
    
    //use func getMsgFromUserdefault()
    @State private var str:String = ContentView.getMsgFromUserdefault()
    
    //Color
//    static var skyBlue = Color(red: 0.4627, green: 0.8392, blue: 1.0)
    @State var bg_color = Color(red: 0.4627, green: 0.8392, blue: 1.0)
    
    var body: some View {
        NavigationView{
            //UI
            ZStack {
                bg_color
                    .edgesIgnoringSafeArea(.all)
                VStack(spacing: 50.0){
                    
                    //Show imagesnow
                    Image(systemName: image_name)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200,height: 200, alignment: .center)
                        .foregroundColor(.white)
                    // ส่ง NotificationCenter
                        .onTapGesture {
                            NotificationCenter.default.post(name: Notification.tap_img,object: nil, userInfo: ["img": "wifi", "text": "กดรูปสำเร็จ"])
                        }
                    
                    //return string func
                    Text.init(str).font(.system(size: 20)).foregroundColor(.white)
                }
            }
//            .navigationBarHidden(true)
        }
    
        //change image and text
        .onReceive(NotificationCenter.default.publisher(for: Notification.tap_img)) { notification in
                if let userInfo = notification.userInfo { // เช็คว่ามีค่ามั้ย
                   print(userInfo)
                    if let img = userInfo["img"] {
                        self.image_name = "\(img)"
                    }
                    if let text = userInfo["text"] {
                        self.str = "\(text)"
                    }
               }
            }
        
        //change background
        
    }
   
    
    //Create func return String
    static func getMsgFromUserdefault() -> String {
        var str:String = "กดรูปเพื่อใช้งาน"
        if let str_save = UserDefaults.standard.object(forKey: USDF_Keys.Showmsg) {
            str = "\(str_save)"
        }
        return str
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
