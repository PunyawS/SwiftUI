//
//  Tabview.swift
//  NotificationCenter_Ex
//
//  Created by Train2 on 19/1/2565 BE.
//

import Foundation
import SwiftUI

struct showTabView: View {
    init() {
      UITabBar.appearance().backgroundColor = UIColor.white
    }
    
    var body: some View {
        
        TabView {
            //tab1
            ContentView().tabItem{
                Label("Menu", systemImage: "moon")
            }
            //tab2
            tabView2().tabItem{
                Label("Menu", systemImage: "list.dash")
            }
        }
        //Color TabView when you select
        .accentColor(.yellow)
    }
}


struct nameTabview_Previews: PreviewProvider {
    static var previews: some View {
        showTabView()
    }
}

