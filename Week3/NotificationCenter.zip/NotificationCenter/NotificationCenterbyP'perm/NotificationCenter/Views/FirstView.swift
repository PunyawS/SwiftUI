//
//  firstView.swift
//  NotificationCenter
//
//  Created by Train3 on 19/1/2565 BE.
//

import Foundation
import SwiftUI

struct FirstView: View {
    
    @State var bg_color = Color.white
    
    var body: some View {
        ZStack {
            bg_color
                .edgesIgnoringSafeArea(.top)
            
            Text("1st tab")
            
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.change_bg)) { noti in
            if let color = noti.object {
                self.bg_color = color as! Color
            }
        }
    }
}

struct FirstView_Previews: PreviewProvider {
    static var previews: some View {
        FirstView()
    }
}
