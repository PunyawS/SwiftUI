//
//  ContentView.swift
//  NotificationCenter
//
//  Created by Train3 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            
            FirstView()
                .tabItem {
                    Image(systemName: "globe")
                }
            
            RandomBGView()
                .tabItem {
                    Image(systemName: "play")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
