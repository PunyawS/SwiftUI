//
//  RandomBGView.swift
//  NotificationCenter
//
//  Created by Train3 on 19/1/2565 BE.
//

import Foundation
import SwiftUI

struct RandomBGView: View {
    
    private let arr_color:[Color] = [Color.red, Color.yellow, Color.green, Color.cyan]
    
    @State var bg_color = Color.white
    
    var body: some View {
        ZStack {
            bg_color
                .edgesIgnoringSafeArea(.top)
                //.ignoresSafeArea()
            
            Button(action: {
                bg_color = arr_color[Int.random(in: 0..<arr_color.count)]
                
                NotificationCenter.default.post(name: Notification.change_bg, object: bg_color)
            }, label: {
                Text("สุ่มสีพื้นหลัง")
            })
        }
    }
}

struct RandomBGView_Previews: PreviewProvider {
    static var previews: some View {
        RandomBGView()
    }
}
