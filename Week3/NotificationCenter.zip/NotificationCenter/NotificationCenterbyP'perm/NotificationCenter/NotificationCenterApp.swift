//
//  NotificationCenterApp.swift
//  NotificationCenter
//
//  Created by Train3 on 19/1/2565 BE.
//

import SwiftUI

@main
struct NotificationCenterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
