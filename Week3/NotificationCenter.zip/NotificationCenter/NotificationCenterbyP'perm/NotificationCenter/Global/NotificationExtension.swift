//
//  NotificationExtension.swift
//  NotificationCenter
//
//  Created by Train3 on 19/1/2565 BE.
//

import Foundation

extension Notification {
    static let change_bg = Notification.Name.init("change_bg")
}
