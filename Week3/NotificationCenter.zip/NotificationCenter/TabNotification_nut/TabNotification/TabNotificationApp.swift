//
//  TabNotificationApp.swift
//  TabNotification
//
//  Created by Train1 on 19/1/2565 BE.
//

import SwiftUI

@main
struct TabNotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
