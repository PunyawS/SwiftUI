//
//  ContentView.swift
//  TabNotification
//
//  Created by Train1 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    @State var randomClor = Color.white
    
  var body: some View {
      ZStack {
          randomClor
              .edgesIgnoringSafeArea(.all)
          VStack{
              
              Text("hi")
          
          
          }.onReceive(NotificationCenter.default.publisher(for: Notification.changColor)){ noti in
              if let notiColor = noti.object{
                  randomClor = notiColor as! Color
                  //Color old = new color
               }
             }
          }
          
        }
     }
  



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
