//
//  ShowBg.swift
//  TabNotification
//
//  Created by Train1 on 19/1/2565 BE.
//

import SwiftUI

struct ShowBg: View {
    @State private var image_name:String = "snow"
    @State private var str:String = ShowBg.getMsgFromUserdefault()
    @State private var can_next:Bool = false
    private let arr_color:[Color] = [Color.red, Color.yellow, Color.green, Color.cyan]
    @State var randomClor = Color.white
    
    
    var body: some View {
        NavigationView{
        ZStack{
            randomClor
                .edgesIgnoringSafeArea(.all)
            VStack.init(spacing: 50.0) {
                
                NavigationLink(destination: ContentView.init(), isActive: $can_next){
                    EmptyView()
                }
                Image(systemName: image_name)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200,height: 200, alignment: .center)
                    .foregroundColor(.red)
                    .onTapGesture{
                        self.can_next = true
                    }
//                Text.init("กดที่รูป 2 ครั้งเพื่อเริ่มใช้งาน").font(.system(size: 20))
//                    .foregroundColor(.white)
                
                Button(action: {
                      //code button
                    randomBg()
                    
                    NotificationCenter.default.post(name: Notification.changColor , object: randomClor)
               
                    }, label: {
                        Text("สุ่มสีพื้นหลัง")
                            .frame(width: 100, height: 50)
                            .foregroundColor(.black)
                            .background(.yellow)
                })
             }
            
           }
        .navigationBarHidden(true)
        }

        
        
        
    }


static func getMsgFromUserdefault() -> String {
    var str:String = "กดที่รูป 2 ครั้งเพื่อเริ่มใช้งาน"
    if let str_save = UserDefaults.standard.object(forKey: USDF_Keys.msg) {
        str = "\(str_save)"
    }
        return str
}

func saveMsgToUserdefault(msg:String) {
    UserDefaults.standard.set(msg, forKey: USDF_Keys.msg) // บันทึก ด้วยคีย์
    UserDefaults.standard.synchronize()
}

    func randomBg(){
      randomClor =  arr_color[Int.random(in: 0..<arr_color.count)]
    }

}
 

struct ShowBg_Previews: PreviewProvider {
    static var previews: some View {
        ShowBg()
    }
}
