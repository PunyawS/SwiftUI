//
//  TabView.swift
//  TabNotification
//
//  Created by Train1 on 19/1/2565 BE.
//

import SwiftUI

struct ShowTabView: View {
    var body: some View {
        
        TabView{
            ContentView()
                .tabItem{
                    Image(systemName: "star.fill")
                    
                }
               
            ShowBg()
                .tabItem{
                    Image(systemName: "list.bullet")
           }
                

    }
  }
}

struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        ShowTabView()
    }
}
