//
//  Extension.swift
//  TabNotification
//
//  Created by Train1 on 19/1/2565 BE.
//

import Foundation
extension Notification {
    static let tap_img = Notification.Name.init("tap_img") // กด
    static let changColor = Notification.Name.init("changColor")  // chang color bg
}

struct USDF_Keys {
    static let msg:String = "msg_last"
    
}
