//
//  ContentViewTab2.swift
//  Test20220119_01
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct ContentViewTab4: View {
    
    @State private var clBg:Color = Color.white
    private let arr_color:[Color] = [Color.red, Color.yellow, Color.green, Color.cyan]
    
    var body: some View {
        ZStack {
            clBg.ignoresSafeArea()
            
            Button.init("สุ่มสีพื้นหลัง") {
                // แบบที่ 1
                NotificationCenter.default.post(name: Notification.update_background_color_1,
                                                object: arr_color[Int(arc4random_uniform(UInt32(arr_color.count)))])
                
                /*
                // แบบที่ 2
                NotificationCenter.default.post(name: Notification.update_background_color_2,
                                                object: nil,
//                                                userInfo: ["color" : arr_color[Int(arc4random_uniform(UInt32(arr_color.count)))]])
                                                userInfo: ["color" : random()])
                */
            }
            
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.update_background_color_1)) { notification in
            if let obj = notification.object {
                self.clBg = obj as! Color
           }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.update_background_color_2)) { notification in
            if let userInfo = notification.userInfo {
                self.clBg = userInfo["color"] as! Color
           }
        }
    }
    
    func random() -> Color {
        return arr_color[Int(arc4random_uniform(UInt32(arr_color.count)))]
    }
}

struct ContentViewTab4_Previews: PreviewProvider {
    static var previews: some View {
        ContentViewTab4()
    }
}

