//
//  ContentViewTab1.swift
//  Test20220119_01
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct ContentViewTab1: View {
    
    @State private var clBg:Color = Color.white
    
    var body: some View {
        ZStack {
            clBg.ignoresSafeArea()
            Text("Hello 1")
                .padding()
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.update_background_color_1)) { notification in
            if let obj = notification.object {
                clBg = obj as! Color
           }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.update_background_color_2)) { notification in
            if let userInfo = notification.userInfo {
                clBg = userInfo["color"] as! Color
           }
        }
    }
}

struct ContentViewTab1_Previews: PreviewProvider {
    static var previews: some View {
        ContentViewTab1()
    }
}

