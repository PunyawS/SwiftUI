//
//  ContentView.swift
//  Test20220119_01
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ContentViewTab1()
                .tabItem {
                    Label("1", systemImage: "list.dash")
                }
            ContentViewTab4()
                .tabItem {
                    Label("2", systemImage: "square.and.pencil")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
