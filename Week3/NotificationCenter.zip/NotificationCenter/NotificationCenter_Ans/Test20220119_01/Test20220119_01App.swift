//
//  Test20220119_01App.swift
//  Test20220119_01
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import SwiftUI

@main
struct Test20220119_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
