//
//  Extension.swift
//  Test20220119_01
//
//  Created by Macbook16 on 19/1/2565 BE.
//

import Foundation

extension Notification {
    static let update_background_color_1 = Notification.Name.init("update_background_color_1")
    static let update_background_color_2 = Notification.Name.init("update_background_color_2")
}
