//
//  ImagePickerView.swift
//  AccessCameraRoll
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import UIKit
import SwiftUI

struct ImagePickerView: UIViewControllerRepresentable {
    
    @Binding var selectedImage: UIImage?
    @Environment(\.presentationMode) var isPresented
    var sourceType: UIImagePickerController.SourceType
        
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = self.sourceType
        imagePicker.allowsEditing = true // อนุญาตให้ crop รูป
        imagePicker.delegate = context.coordinator // context.coordinator คือระบุตำแหน่งปลายทางที่จะรับ delegate
        return imagePicker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {

    }
    
    func makeCoordinator() -> ImagePickerManager { // สร้าง coordinator
        return ImagePickerManager(picker: self)
        
//        let imgPicker = ImagePickerManager()
//        imgPicker.picker = self
//        return imgPicker
    }
}
