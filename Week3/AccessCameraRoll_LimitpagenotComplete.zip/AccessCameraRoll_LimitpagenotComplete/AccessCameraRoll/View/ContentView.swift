//
//  ContentView.swift
//  AccessCameraRoll
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var selectedImage: UIImage?
    @State private var isImagePickerDisplay = false
    
    @State private var isImagePickerLimitedDisplay = false
    @State private var isImagePickerLimitedDisplay_disable = false
    @State private var photoPermission: PhotoPermission = PhotoPermission.init()

    var body: some View {
        NavigationView {
            VStack {
                
                if selectedImage != nil {
                    Image(uiImage: selectedImage!)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .clipShape(Circle())
                        .frame(width: 300, height: 300)
                } else {
                    Image(systemName: "snow")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .clipShape(Circle())
                        .frame(width: 300, height: 300)
                }
                
                Button("Photo") {
                    if photoPermission.authorized {
                        self.sourceType = .photoLibrary
//                        self.isImagePickerDisplay.toggle()
                        
                        if photoPermission.limited {
                            if !isImagePickerLimitedDisplay_disable {
                                isImagePickerLimitedDisplay_disable = true
                                isImagePickerLimitedDisplay.toggle()
                            }else{
                                // เปิดหน้า limit รูปที่เคยเลือกไว้ ต้อง custom code เองต่อ
                            }
                        }else{
                            isImagePickerDisplay.toggle()
                        }
                    }else{
                        if photoPermission.denied {
                            // ต้องโชว์ alert แจ้งเตือนให้ไปเปิดตั้งค่าเข้าถึงอัลบั้ม
                        }else{
                            showPermission()
                        }
                    }
                }.padding()
                
                
                /*
                Button("Camera") {
                    self.sourceType = .camera
                    self.isImagePickerDisplay.toggle()
                }.padding()
                */
            }
            .navigationBarTitle("Permission")
            .sheet(isPresented: self.$isImagePickerDisplay) {
                ImagePickerView(selectedImage: self.$selectedImage, sourceType: self.sourceType)
            }
            .sheet(isPresented: self.$isImagePickerLimitedDisplay) {
                LimitedPicker.init(isPresented: self.$isImagePickerLimitedDisplay)
            }
            
        }
    }
    
    func showPermission() {
        photoPermission.showPermission()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
