//
//  AccessCameraRollApp.swift
//  AccessCameraRoll
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import SwiftUI

@main
struct AccessCameraRollApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView_Basic()
            ContentView()
        }
    }
}
