//
//  ImagePickerManager.swift
//  AccessCameraRoll
//
//  Created by Macbook16 on 17/1/2565 BE.
//

import UIKit
import Foundation
import Photos // framework default ของ iOS เพื่อเข้าถึงรูป

class ImagePickerManager: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    var picker: ImagePickerView
    
    init(picker: ImagePickerView) {
        self.picker = picker
    }

    // เป็นฟังก์ชันของ UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        guard let selectedImage = info[.originalImage] as? UIImage else { return } // originalImage ใช้รูปต้นฉบับ
        guard let selectedImage = info[.editedImage] as? UIImage else { return } // editedImage ใช้รูปที่ crop
        self.picker.selectedImage = selectedImage 
        self.picker.isPresented.wrappedValue.dismiss()
    }
}
