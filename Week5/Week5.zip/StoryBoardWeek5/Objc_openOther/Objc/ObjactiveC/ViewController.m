//
//  ViewController.m
//  Objc
//
//  Created by Train2 on 31/1/2565 BE.
//

#import "ViewController.h"
#import "Objc-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)OpenSB:(id)sender {
    SBViewController *sb = [[SBViewController alloc] init];
    
    [self presentViewController:sb animated:true completion:nil];
}
- (IBAction)OpenSwUI:(id)sender {
    [SwManage presentSwiftUIWithObjcController:self];
}


@end
