//
//  SBViewController.swift
//  Objc
//
//  Created by Train2 on 31/1/2565 BE.
//

import UIKit

class SBViewController: UIViewController {

    @IBOutlet weak var mySBLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mySBLabel.text = "This StoryBoard Bruhhhh"
    }



}
