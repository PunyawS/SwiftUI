//
//  SceneDelegate.h
//  Objc
//
//  Created by Train2 on 31/1/2565 BE.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

