//
//  AppDelegate.h
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

//MARK: import <FrameworkName/Class>
#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

//MARK: Create Variable and Method in this spec

@end

