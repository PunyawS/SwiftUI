//
//  ViewController.h
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@end

