//
//  ViewController.m
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

#import "ViewController.h"

//  ObjC show ObjC
#import "Page2ViewController.h"

//  ObjC show Swift_Sb
#import "CTObjC-Swift.h"

@interface ViewController (){
//    let btn1:UIButton = UIButton.init()
    UIButton *btn1;
    
}

@property (weak, nonatomic) IBOutlet UIButton *btn;

@property (nonatomic, retain) UIButton *btn2;
@property (nonatomic, strong) UIButton *btn3;

@property (nonatomic, strong) UIButton *btn4;
@property (nonatomic, strong) UIButton *btn5;

@end

@implementation ViewController
@synthesize  btn4, btn5;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    btn1 = [[UIButton alloc] init];
    
    _btn2 = [[UIButton alloc] init];
    
    
    self.btn3 = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 50)];
    self.btn3.backgroundColor = [UIColor blueColor];
    [self.btn3 setTitle:@"Hello 3" forState: UIControlStateNormal];
    [self.btn3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.view addSubview:self.btn3];

//    btn4 = [[UIButton alloc] init];
    [self.view addSubview:btn4];

}
//  ObjC show ObjC
- (IBAction)actionNext:(id)sender {
    Page2ViewController *page2 = [[Page2ViewController alloc] init];
    page2.str_1 =@"12345";
    
    NSLog(@"%@", [page2 strTest1]);
//    @Static
    NSLog(@"%@", [Page2ViewController strTest2]);
    
    [self presentViewController:page2 animated:true completion:nil];
}

//  ObjC show Swift_Sb
- (IBAction)actionNextPage3:(id)sender{
    Page3_Sw_ViewController *page3_SW = [[Page3_Sw_ViewController alloc] init];
    page3_SW.str_1 = @"6789";
    NSLog(@"%@", [page3_SW strTest1WithI1:55 i2:100]);
    NSLog(@"%@", [Page3_Sw_ViewController strTest2]);
    [self presentViewController:page3_SW animated:true completion:nil];
}

// Objc show SwiftUI
- (IBAction)actionShowSwiftUI:(id)sender {
    [SwManage presentSwiftUIWithObjcController:self];
}

@end
