//
//  Page2ViewController.m
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

#import "Page2ViewController.h"

@interface Page2ViewController ()

//can't see
@property (nonatomic, retain) NSString *str_4;

@end

@implementation Page2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //Can see
    NSLog(@"str_1 : %@", self.str_1);
    //can't see
    NSLog(@"str_2 : %@", str_2);
    //can't see
    NSLog(@"str_4 : %@", _str_4);
}

//Can see
- (NSString *)strTest1{
    return @"Test1";
}

//Can see
//@Static
+ (NSString *)strTest2{
    return @"Test2";
}

@end
