//
//  Page3_Sw_ViewController.swift
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//


import UIKit

//import SwiftUI
import SwiftUI

class Page3_Sw_ViewController: UIViewController {

    @objc var str_1:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("str_1 : \(str_1)")
    }
    
    @objc func strTest1(i1:Int, i2:Int)-> String{
        return "strTest1 \(i1) and \(i2)"
    }
    
    @objc static func strTest2()-> String{
        return "strTest2"
    }
    
    //Swift_Sb show ObjC
    @IBAction func showPage2ObjC(_ sender: Any) {
        let page2:Page2ViewController = Page2ViewController.init()
        
        page2.str_1 = "1235679999"
        print("\(page2.strTest1())")
        Page2ViewController.strTest2()
        
        self.present(page2, animated: true, completion: nil)
    }
    
    //Swift_Sb show SwiftUI
    @IBAction func actionShowSwiftUI(_ sender: Any) {
        
        //MARK: Add subview หน้าใหม่ โดยสร้าง UIViewController มาใหม่
//        //Create Controller newPage
//        let controller: UIViewController = UIViewController.init()
//        let swUI = UIHostingController.init(rootView: SwUIContentView())
//
//        // Add NewViewController and set Frame SwiftUI
//        controller.addChild(swUI)
//        swUI.view.frame = controller.view.frame
//
//        // add Subview
//        controller.view.addSubview(swUI.view)
//
//        //present NewViewController
//        swUI.didMove(toParent: controller)
//        self.present(controller, animated: true, completion: nil)
        
        //Create Contact
        let controller: ContactViewController = ContactViewController.init()
        let contact = UIHostingController.init(rootView: SwUIContentView())
        
        // Add NewViewController and set Frame SwiftUI
        controller.addChild(contact)
        contact.view.frame = CGRect.init(x: 10, y: 50, width: 100, height: 150)
        
        // add Subview
        controller.view.addSubview(contact.view)
        
        //present NewViewController
        contact.didMove(toParent: controller)
        self.present(controller, animated: true, completion: nil)
        

    }
}
