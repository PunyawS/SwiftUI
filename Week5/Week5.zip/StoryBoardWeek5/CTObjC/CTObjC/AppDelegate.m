//
//  AppDelegate.m
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

#import "AppDelegate.h"

@interface AppDelegate ()

//MARK: Create Variable and Method in this spec

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSLog(@"Hello");
    
    // let arr = ["1", "2", "3"]
    NSArray *arr = @[@"1", @"2", @"3"];
    
    // let str:String = "Hello"
    NSString *str = @"Hello";
    int i1 = 1;
    float f1 = 1.0;
    double d1 = 1.0;
    
    // print("str : \(str)" : \(i1) : \(f1) : \(d1))
    NSLog(@"str : %@ : %i : %f : %f",str, i1, f1, d1);
    
    // print(arr)
    // print("\(arr)")
    NSLog(@"arr : %@", arr);
    
    // use func
    // self.aboutArray()
    [self aboutArray];
    
    // Dictionary
    [self aboutDic];
    
    return YES;
}

- (NSString*)getStr{
    return  @"Hello";
}

- (NSArray*)test1{
    
    //Create Variable Array
    // let arr = Array.init()
    NSArray *arr = [[NSArray alloc] init];
    
    //Array init
//    return [[NSArray alloc] init];
    return arr;
}

- (void)aboutArray{
    //Create Variable Array
    // let arr = Array.init()
    NSArray *arr = [[NSArray alloc] init];
    NSArray *arr2 = [[NSArray alloc] init];
    arr = arr2;
    
    // Can Add value into Array
    // normal array can't remove add edit
    // if you want to edit array, use NSMutableArray
    NSMutableArray *muArr = [[NSMutableArray alloc] init];
    [muArr addObject:@"111"];
    [muArr removeObject:@"1"];
    
}

- (void)aboutDic{
    NSDictionary *dic = [[NSDictionary alloc] init];
    // obj:key
    dic = [NSDictionary dictionaryWithObjectsAndKeys:@"hello",@"title",
           @"1",@"no", nil ];
    
    NSLog(@"dic : %@", dic);
    
    NSMutableDictionary *muDic = [[NSMutableDictionary alloc] init];
    [muDic setObject:@"hello" forKey:@"title"];
    [muDic setObject:@"1" forKey:@"no"];
    [muDic removeObjectForKey:@"title"];
    [muDic removeObjectForKey:@"no"];
}

#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}

//MARK: Void like Func don't return value (ฟังก์ชั่นไม่ Return ค่าอะไร)
- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
