//
//  SwUIContentView.swift
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI
import UIKit

struct SwUIContentView : View{
    
    @State var showObjc:Bool = false
    
    var body: some View{
        VStack {
            Text("Hello SwiftUI")
            
            Button {
                showObjc.toggle()
            } label: {
                Text("Show Objc ContactViewController")
            }
        }.sheet(isPresented: $showObjc) {
            ContactViewObjc.init()
        }
    }
}

struct SwUIContentView_Preview : PreviewProvider{
    static var previews: some View{
        SwUIContentView()
    }
}


