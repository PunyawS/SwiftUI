//
//  ContactView.swift
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI
import UIKit

//SwiftUI show Swift_Sb
struct ContactViewObjc: UIViewControllerRepresentable {
    
    private let contact = ContactViewController.init()
    
    func makeUIViewController(context: Context) -> ContactViewController {
        return contact
    }

    func updateUIViewController(_ uiView: ContactViewController, context: Context) {
       
    }
}
