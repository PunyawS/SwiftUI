//
//  SwiftUIView.swift
//  Objc
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        ZStack {
            Color.blue
                .ignoresSafeArea()
            VStack {
                Text("This SwiftUI Bruhhh")
                    .bold()
                    .foregroundColor(.white)
                    .padding()
                    .background(.red)
                    .cornerRadius(15)
            }
        }
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
