//
//  ViewController.swift
//  swiftStoryBoard
//
//  Created by Train2 on 31/1/2565 BE.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func openObjc(_ sender: Any) {
        
        let opObjc:ObjcViewController = ObjcViewController.init()
        self.present(opObjc, animated: true, completion: nil)
    }
    
    @IBAction func OpenSwiftUI(_ sender: Any) {
        //MARK: Add subview หน้าใหม่ โดยสร้าง UIViewController มาใหม่
        //Create Controller newPage
        let controller: UIViewController = UIViewController.init()
        let swUI = UIHostingController.init(rootView: SwiftUIView())

        // Add NewViewController and set Frame SwiftUI
        controller.addChild(swUI)
        swUI.view.frame = controller.view.frame

        // add Subview
        controller.view.addSubview(swUI.view)

        //present NewViewController
        swUI.didMove(toParent: controller)
        self.present(controller, animated: true, completion: nil)
    }
}

