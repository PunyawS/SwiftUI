//
//  ObjCViewController.h
//  swiftStoryBoard
//
//  Created by Train2 on 31/1/2565 BE.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ObjcViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
