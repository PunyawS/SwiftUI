//
//  ObjCViewController.m
//  swiftStoryBoard
//
//  Created by Train2 on 31/1/2565 BE.
//

#import "ObjcViewController.h"

@interface ObjcViewController ()

@end

@implementation ObjcViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}


@end
