//
//  ContentView.swift
//  SwiftUIToStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 100) {
                NavigationLink(destination: {
                    ObjcView()
                }, label: {
                    Text("Objective C")
                })
                
                NavigationLink(destination: {
                    SWStoryboardView()
                }, label: {
                    Text("Swift Storyboard")
                })
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ObjcView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> ObjCViewController {
        return ObjCViewController()
    }
    
    func updateUIViewController(_ uiViewController: ObjCViewController, context: Context) {
        
    }
}

struct SWStoryboardView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> SwiftStoryboardViewController {
        return SwiftStoryboardViewController()
    }
    
    func updateUIViewController(_ uiViewController: SwiftStoryboardViewController, context: Context) {
        
    }
}
