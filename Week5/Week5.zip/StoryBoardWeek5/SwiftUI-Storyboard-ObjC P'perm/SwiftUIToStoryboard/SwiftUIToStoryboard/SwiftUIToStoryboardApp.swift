//
//  SwiftUIToStoryboardApp.swift
//  SwiftUIToStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUIToStoryboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
