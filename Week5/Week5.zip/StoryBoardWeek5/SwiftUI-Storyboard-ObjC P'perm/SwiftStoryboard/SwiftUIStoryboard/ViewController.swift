//
//  ViewController.swift
//  SwiftUIStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func toObjC(_ sender: Any) {
        let ObjCPage = ObjCViewController.init()
        self.present(ObjCPage, animated: true, completion: nil)
    }
    
    @IBAction func toSwiftUI(_ sender: Any) {
        let controller: UIViewController = UIViewController.init()
        
        let swUI = UIHostingController.init(rootView: SwiftUIView())
        controller.addChild(swUI)
        swUI.view.frame = controller.view.frame
        controller.view.addSubview(swUI.view)
        swUI.didMove(toParent: controller)
        
        self.present(controller, animated: true, completion: nil)
    }
}

