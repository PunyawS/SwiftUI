//
//  AppDelegate.h
//  ObjectiveCStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

