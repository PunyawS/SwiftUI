//
//  SwiftUIViewController.swift
//  ObjectiveCStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

import Foundation
import UIKit
import SwiftUI

class SWManage: NSObject {
    @objc static func presentSwiftUI(objcController: UIViewController) {
        let controller: UIViewController = UIViewController.init()
        
        let swUI = UIHostingController.init(rootView: SwiftUIView())
        controller.addChild(swUI)
        swUI.view.frame = controller.view.frame
        controller.view.addSubview(swUI.view)
        swUI.didMove(toParent: controller)
        
        objcController.present(controller, animated: true, completion: nil)
    }
}
