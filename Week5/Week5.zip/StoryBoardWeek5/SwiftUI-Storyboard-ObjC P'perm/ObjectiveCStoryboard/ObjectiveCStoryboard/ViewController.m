//
//  ViewController.m
//  ObjectiveCStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

#import "ViewController.h"
#import "ObjectiveCStoryboard-Swift.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)toSwiftStoryboard:(id)sender {
    SwiftViewController *SWViewController = [[SwiftViewController alloc] init];
    [self presentViewController:SWViewController animated:true completion:nil];
}

- (IBAction)toSwiftUi:(id)sender {
    [SWManage presentSwiftUIWithObjcController:self];
}


@end
