//
//  SwiftUIView.swift
//  ObjectiveCStoryboard
//
//  Created by Train3 on 31/1/2565 BE.
//

import Foundation
import SwiftUI

struct SwiftUIView: View {
    
    var body: some View {
        
        Text("SwiftUI")
    }
}
