//
//  ContentView.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isShowSetting = false
    @State private var isShowAdd = false
    @State private var isShowInfo = false
    

    @State var goalData = ContentView.getGoalFromUSDF()
    @State var sumdrink = sumDrink()
    
    var body: some View {
        NavigationView{
            ZStack{
                //background
                VStack{
                    ZStack{
                        Image(systemName: "circle")
                            .resizable()
                            .frame(width: 250, height: 250, alignment: .center)
                            .scaledToFit()
                            .foregroundColor(circle_Drop())
                            .padding(.top,150)
                        
                        VStack {
                            HStack {
                                Text("\(percentCalculation(goal: goalData), specifier: "%.2f") %")
                                    .font(.title)
                                
                                Image(systemName: "drop.fill")
                                    .resizable()
                                    .frame(width: 20, height: 30)
                                    .foregroundColor(circle_Drop())
                            }
                            Text("of daily goal")
                        }.padding(.top,150)
                    }
                    Spacer()
                    
                    //MARK: Func drink %
                    Text("\(sumdrink) mL / \(goalData) mL")
                        .onAppear {
                            sumdrink = sumDrink()
                            goalData = ContentView.getGoalFromUSDF()
                        }
                        .onReceive(NotificationCenter.default.publisher(for: Notification.Add_inTake_Drink)) { Noti in
                            if let obj_Drink = Noti.object {
                                print(obj_Drink)
                                sumdrink = obj_Drink as! Int
                            }
                        }
                        .onReceive(NotificationCenter.default.publisher(for: Notification.setting_Goal)) { Noti in
                            if let obj_goal = Noti.object {
                                print(obj_goal)
                                self.goalData = obj_goal as! String
                            }
                        }
                    
                    //List
                    ListAddintakeRecord()
                 
                    
                    HStack{
                        //MARK: info
                        Button {
                            self.isShowInfo.toggle()
                        } label: {
                            ZStack {
                                Image(systemName: "circle")
                                    .font(.system(size: 35))
                                    .foregroundColor(.black)
                                Image(systemName: "info")
                                    .font(.system(size: 25))
                                    .foregroundColor(.black)
                            }
                        } .sheet(isPresented: $isShowInfo, content: {
                            infoPage()
                        })
                        .padding(.leading, 25)
                        
                        Spacer()
                        //MARK: Add
                        Button {
                            self.isShowAdd.toggle()
                        } label: {
                            Text("Add Intake")
                                .frame(width: 150, height: 50)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                        } .sheet(isPresented: $isShowAdd, content: {
                            Add_Intake()
                        })
                                
                        Spacer()
                        //MARK: Setting
                        Button {
                            self.isShowSetting.toggle()
                        } label: {
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.black)
                        }.sheet(isPresented: $isShowSetting) {
                            SettingPage()
                        }
                        .padding(.trailing, 25)
                    }
                }
                
            }
   
            
            //MARK: Title Bar
            .navigationBarTitleDisplayMode(.inline)

            .toolbar {
                    ToolbarItem(placement: .principal) {
                        VStack{
                            Spacer()
                            Text("\(getCurrentTime())")
                            
                            Text("\(getCurrentDate())")
                                .font(.system(size: 32.0, weight: .bold, design: .rounded))

                            Text("Here is your fluid intake")
                                .font(.system(size: 18, weight: .light, design: .rounded))
                    }
                }
            }
        }
    }
    
    static func getGoalFromUSDF() -> String {
        var str: String = "2000"
        if let strGoal = UserDefaults.standard.object(forKey: USDF_Keys.goal) {
            str = "\(strGoal)"
        }
        return str
    }
    
    func circle_Drop() -> Color {
        var circle_Drop = Color.blue.opacity(0.6)
        if sumDrink() >= Int(goalData)! {
            circle_Drop = Color.green
        }
        return circle_Drop
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
