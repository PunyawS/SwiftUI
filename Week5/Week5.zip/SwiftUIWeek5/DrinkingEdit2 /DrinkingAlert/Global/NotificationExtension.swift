//
//  NotificationExtension.swift
//  DrinkingAlert
//
//  Created by Train3 on 2/2/2565 BE.
//

import Foundation

extension Notification {
    static let sum_drank = Notification.Name.init("sum_drank")
    static let setgoal = Notification.Name.init("setgoal")
    static let scrollview = Notification.Name.init("scrollview")
}
