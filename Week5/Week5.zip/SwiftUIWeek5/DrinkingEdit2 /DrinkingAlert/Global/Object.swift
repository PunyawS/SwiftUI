//
//  Object.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

struct dropPic: View {
    
    var drink: String
    
    var body: some View {
        Image(systemName: "drop.fill")
            .resizable()
            .frame(width: 20, height: 30)
            .foregroundColor(getColor())
    }
    
    func getColor() -> Color {
        var Color1 = Color.gray
        if drink == "Water" {
            Color1 = Color.blue
        }
        if drink == "Coffee" {
            Color1 = Color.brown
        }
        if drink == "Juice" {
            Color1 = Color.orange
        }
        return Color1
    }
}

struct dropPic_Previews: PreviewProvider {
    static var previews: some View {
        dropPic(drink: "Juice")
    }
}
