//
//  Calculation.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation

func sumDrank() -> Int {
    var sum = 0
    var lists = [[String]]()
    
    if let listData = UserDefaults.standard.array(forKey: USDF_Keys.intake2) {
        lists = listData as! [[String]]
    }
    
    for item in lists {
        sum = sum + Int(item[1])!
    }
    
    return sum
}

func percentCalculation(goal: String) -> Float {
    var percent: Float = 0.00
    
    let floatGoal = Float(goal)
    let Sum = sumDrank()
    let floatSum = Float(Sum)
    
    percent = (floatSum/floatGoal!)*100
    
    return percent
}
