//
//  UserDefault.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation

struct USDF_Keys {
    static let goal: String = "goal"
    //static let intake: String = "intake"
    static let intake2: String = "intake2"
    
//    static let drink_intake = "drink_intake"
//    static let amount_intake = "amount_intake"
//    static let date_intake = "amount_intake"
}
