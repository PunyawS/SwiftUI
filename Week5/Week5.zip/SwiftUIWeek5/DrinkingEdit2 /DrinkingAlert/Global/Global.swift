//
//  Global.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

let apiPath = "https://jsonkeeper.com/b/D4LI"

func getDate() -> String {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "th")
    formatter.dateFormat = "dd MMM YYYY"

    let dateString = formatter.string(from: Date())
    return dateString
}

func getTime() -> String {
    let formatter = DateFormatter()
    formatter.timeStyle = .short

    let dateString = formatter.string(from: Date())
    return dateString
}
