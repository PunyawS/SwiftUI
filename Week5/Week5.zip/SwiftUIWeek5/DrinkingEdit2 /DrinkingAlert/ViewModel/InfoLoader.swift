//
//  InfoLoader.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation

class InfoLoader: ObservableObject {
    @Published var Info = ""
    
    init() {
        loadData()
    }
    
    func loadData() {
        guard let url = URL(string: apiPath) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
            if let err_check = error {
                print(err_check.localizedDescription)
                return
            }
            
            guard let DrinkData = data  else { return }
            
            let DecodedDrinkData1 = try? JSONDecoder().decode(Model.self, from: DrinkData)
            
            DispatchQueue.main.async {
                if let DecodedDrinkData = DecodedDrinkData1 {
                    self.Info = DecodedDrinkData.info
                }
            }
            
            
        }.resume()
    }
}
