//
//  Model.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation

struct Model: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case intakeincrement
        case goalincrement
        case basegoal
        case info
        case Drink
    }
    
    var id = UUID()
    var intakeincrement: Int
    var goalincrement: Int
    var basegoal: Int
    var info: String
    var Drink: [Drinks]
}

struct Drinks: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case id
        case drinktype
    }
    
    var id: Int
    var drinktype: String
}
