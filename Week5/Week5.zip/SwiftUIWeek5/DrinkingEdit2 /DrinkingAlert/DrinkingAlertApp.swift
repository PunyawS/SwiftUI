//
//  DrinkingAlertApp.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import SwiftUI

@main
struct DrinkingAlertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
