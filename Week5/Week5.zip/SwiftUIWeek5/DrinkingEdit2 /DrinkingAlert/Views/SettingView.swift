//
//  SettingView.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

struct SettingView: View {
    
    @ObservedObject var DrinkData = DrinkLoader()
    
    @State var GoalAmount = ContentView.getGoalFromUSDF()
    
    //@State var goBack: Bool = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            Spacer()
            Text("Setting")
                .font(.title)
                .bold()
            Spacer()
            Text("Set your goal:")
            Spacer()
            Picker("Goal", selection: $GoalAmount) {
                
                ForEach(2000..<6101) { i in
                    if i%100 == 0 {
                        Text("\(i) mL").tag("\(i)")
                    }
                }
            }
            .pickerStyle(WheelPickerStyle())
            
            Spacer()
            
            Button(action: {
                UserDefaults.standard.set(GoalAmount, forKey: USDF_Keys.goal)
                UserDefaults.standard.synchronize()

                NotificationCenter.default.post(name: Notification.setgoal, object: GoalAmount)
                
                presentationMode.wrappedValue.dismiss()
                
            }, label: {
                HStack {
                    Text("Save Goal")
                    Image(systemName: "square.and.arrow.down")
                }
                .frame(width: 250, height: 40)
            })
                .buttonStyle(.borderedProminent)
            Spacer()
        }
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}
