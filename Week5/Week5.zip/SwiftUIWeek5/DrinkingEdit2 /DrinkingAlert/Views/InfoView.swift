//
//  InfoView.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

struct InfoView: View {
    
    @ObservedObject var InfoData = InfoLoader()
    
    var body: some View {
        VStack {
            Text("Info")
                .bold()
                .font(.title)
                .padding()
            dropPic(drink: "Water")
                .padding()
            Text(InfoData.Info)
                .padding()
            Spacer()
        }
    }
}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
