//
//  RecordScrollView.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//


import SwiftUI

struct RecordScrollView: View {
    
    @State var intakeRecord = [[String]]()
    @State var sum = sumDrank()
    
    var body: some View {
        VStack {
            List {
                ForEach(intakeRecord, id: \.self) { item in
                    RoundedRectangle(cornerRadius: 8)
                        .frame(width: 320, height: 70)
                        .foregroundColor(.white)
                        .shadow(radius: 3)
                        .overlay {
                            HStack {
                                Text(item[0])
                                    .frame(width: 75, alignment: .leading)
                                dropPic(drink: item[0])
                                Text("\(item[1]) mL")
                                    .frame(width: 75, alignment: .trailing)
                                Text(item[2])
                                    .frame(width: 75, alignment: .trailing)
                            }
                        }
                }
                .onDelete(perform: removeRows)
                .listRowSeparator(.hidden)
            }
            .listStyle(.plain)
        }
        .onAppear {
            intakeRecord = RecordScrollView.getIntakeRecordFromUSDF()
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.scrollview)) { Noti in
            if let obj = Noti.object {
                print(obj)
                self.intakeRecord = obj as! [[String]]
            }
        }
        .frame(width: 350)
    }
    
    static func getIntakeRecordFromUSDF() -> [[String]] {
        var lists = [[String]]()
        if let listData = UserDefaults.standard.array(forKey: USDF_Keys.intake2) {
            lists = listData as! [[String]]
            print(lists)
            print(lists[0][0])
        }
        return lists
    }
    
    
    func removeRows(at offsets: IndexSet) {
        intakeRecord.remove(atOffsets: offsets)
        UserDefaults.standard.set(intakeRecord, forKey: USDF_Keys.intake2)
        UserDefaults.standard.synchronize()
        
        sum = sumDrank()
        print("sum: \(sum)")
        NotificationCenter.default.post(name: Notification.sum_drank, object: sum)
    }
}

struct RecordScrollView_Previews: PreviewProvider {
    static var previews: some View {
        RecordScrollView()
    }
}
