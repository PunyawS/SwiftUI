//
//  ContentView.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    //@ObservedObject var DrinkData = DrinkLoader()
    
    @State var goalData = ContentView.getGoalFromUSDF()
    @State var showsum = sumDrank()
    
    @State var toSettingView: Bool = false
    @State var toAddIntake: Bool = false
    @State var toInfoView: Bool = false
    
    var body: some View {
        VStack {
            //date
            Text(getDate())
                .bold()
                .font(.title)
                .padding()
            
            //text
            Text("Here is your fluid intake")
                .font(.caption)
                .padding()
            
            //graphic show percent
            ZStack {
                Image(systemName: "circle")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .scaledToFit()
                    .foregroundColor(circleColor())
                    .shadow(color: circleColor(), radius: 8)
                
                VStack {
                    HStack {
                        Text("\(percentCalculation(goal: goalData), specifier: "%.2f") %")
                            .font(.title2)
                        dropPic(drink: "Water")
                    }
                    Text("of daily goal")
                        .font(.caption)
                }
            }
            .padding()
            
            //amount
            Text("\(showsum) mL / \(goalData) mL")
                .padding()
                .onAppear {
                    showsum = sumDrank()
                    goalData = ContentView.getGoalFromUSDF()
                }
                .onReceive(NotificationCenter.default.publisher(for: Notification.sum_drank)) { Noti in
                    if let obj = Noti.object {
                        print(obj)
                        self.showsum = obj as! Int
                    }
                }
                .onReceive(NotificationCenter.default.publisher(for: Notification.setgoal)) { Noti in
                    if let obj = Noti.object {
                        print(obj)
                        self.goalData = obj as! String
                    }
                }
            
            //record
            RecordScrollView()
            
            HStack {
                Spacer()
                //info
                Image(systemName: "info.circle")
                    .resizable()
                    .frame(width: 30, height: 30)
                    .scaledToFit()
                    .onTapGesture {
                        toInfoView = true
                    }
                    .sheet(isPresented: $toInfoView) {
                        InfoView()
                    }
                
                Spacer()
                //add intake buttin(sheet)
                Button(action: {
                    toAddIntake = true
                }, label: {
                    HStack {
                        Text("Add Intake")
                        Image(systemName: "plus.circle")
                    }
                    .frame(width: 200, height: 35)
                })
                    .buttonStyle(.borderedProminent)
                    .sheet(isPresented: $toAddIntake) {
                        AddIntakeView()
                    }
                
                Spacer()
                //setting (sheet)
                Image(systemName: "gearshape")
                    .resizable()
                    .frame(width: 30, height: 30)
                    .scaledToFit()
                    .onTapGesture {
                        toSettingView = true
                    }
                    .sheet(isPresented: $toSettingView) {
                        SettingView()
                    }
                Spacer()
            }
            
        }
        
    }
    static func getGoalFromUSDF() -> String {
        var str: String = "2000"
        if let strGoal = UserDefaults.standard.object(forKey: USDF_Keys.goal) {
            str = "\(strGoal)"
        }
        return str
    }
    
    func circleColor() -> Color {
        var circle = Color.blue.opacity(0.6)
        if sumDrank() >= Int(goalData)! {
            circle = Color.green
        }
        return circle
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
