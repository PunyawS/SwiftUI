//
//  AddIntakeView.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

struct AddIntakeView: View {
    
    @ObservedObject var DrinkData = DrinkLoader()
    
    @State var selectedDrink: String = ""
    @State var selectedAmount: String = "50"
    @State var intakeRecord = AddIntakeView.getIntakeRecordFromUSDF()
    
    @State var updateRecord = [[String]]()
    
    @State var selectError: Bool = false
    @State var goBack: Bool = false
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack(spacing: 30) {
            
            Text("New Intake")
                .bold()
                .font(.title)
                .padding()
            
            Picker("Selecting Drink", selection: $selectedDrink) {
                ForEach(DrinkData.DrinkList) { item in
                    Text("\(item.drinktype)").tag("\(item.drinktype)")
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            
            dropPic(drink: selectedDrink)
                .frame(width: 100, height: 100)
            
            Picker("Selecting Amount", selection: $selectedAmount) {
                ForEach(50..<2501) { i in
                    if i%50 == 0 {
                        Text("\(i) mL").tag("\(i)")
                    }
                }
            }
            .pickerStyle(WheelPickerStyle())
            
            Button(action: {
                if selectedDrink == "" {
                    selectError = true
                } else {
                    addRecord(record: getIntakeArray())
                    UserDefaults.standard.set(intakeRecord, forKey: USDF_Keys.intake2)
                    UserDefaults.standard.synchronize()
                    
                    NotificationCenter.default.post(name: Notification.sum_drank, object: sumDrank())
                    
                    updateRecord = AddIntakeView.getIntakeRecordFromUSDF()
                    print(updateRecord)
                    NotificationCenter.default.post(name: Notification.scrollview, object: updateRecord)
                    
                    presentationMode.wrappedValue.dismiss()
                }
                
            }, label: {
                HStack {
                    Text("Save Goal")
                    Image(systemName: "square.and.arrow.down")
                }
                .frame(width: 250, height: 40)
            })
                .buttonStyle(.borderedProminent)
                .alert("Please select your drink", isPresented: $selectError) {
                            Button("OK", role: .cancel) { }
                        }
            Spacer()
        }
        .padding(.horizontal)
    }
    
    func getIntakeArray() -> [String] {
        let intake = [selectedDrink, selectedAmount, getTime()]
        return intake
    }
    
    static func getIntakeRecordFromUSDF() -> [[String]] {
        var lists = [[String]]()
        if let listData = UserDefaults.standard.array(forKey: USDF_Keys.intake2) {
            lists = listData as! [[String]]
        }
        return lists
    }
    
    func addRecord(record: [String]) {
        intakeRecord.insert(record, at: 0)
    }
}

struct AddIntakeView_Previews: PreviewProvider {
    static var previews: some View {
        AddIntakeView()
    }
}
