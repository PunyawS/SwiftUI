//
//  ContentView.swift
//  Circle Fill Animation
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @State private var progress: Double = 0.0
    
    var body: some View {
        ZStack{
            Circle()
                .stroke(lineWidth: 20)
                .opacity(0.2)
                .foregroundColor(Color.purple)
                .frame(width: 250, height: 250)
            
            Text(String(format: "%0.f%%", min(self.progress,1) * 100))
            
            Circle()
                .trim(from: 0.0, to: CGFloat(self.progress))
                .stroke(style: StrokeStyle(lineWidth: 20.0, lineCap: .round, lineJoin: .round))
                .foregroundColor(.purple)
                .animation(Animation.linear(duration: 2.0))
                .frame(width: 250, height: 250)
            
            Button {
                Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
                    
                    self.progress += 0.1
                    if self.progress >= 1 {
                        timer.invalidate()
                    }
                }
            } label: {
                Text("Get Data")
                    .foregroundColor(.blue)
        }
        }.padding()
 
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
