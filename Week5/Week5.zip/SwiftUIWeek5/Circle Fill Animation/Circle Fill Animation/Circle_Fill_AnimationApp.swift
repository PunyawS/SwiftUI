//
//  Circle_Fill_AnimationApp.swift
//  Circle Fill Animation
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

@main
struct Circle_Fill_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
