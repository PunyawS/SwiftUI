//
//  ObservedObject_propertyApp.swift
//  ObservedObject property
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

@main
struct ObservedObject_propertyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
