//
//  PersonViewModel.swift
//  ObservedObject property
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

class PersonViewModel: ObservableObject {
    
    @Published var people: [Person] = []
    
    
    init(){
        addPeople()
    }
    
    func addPeople(){
        people = peopleData
    }
    
    func shuffleOrder(){
        people.shuffle()
    }
    
    func reverseOrder(){
        people.reverse()
    }
    
    func removeLastPerson(){
        people.removeLast()
    }
    
    func removeFirstPerson() {
        people.removeFirst()
    }
}

let peopleData = [
    Person(name: "Jon Snow", email: "jon@email.com", phoneNumber: "555-5555"),
    Person(name: "Robert", email: "Robert@email.com", phoneNumber: "666-6556"),
    Person(name: "Cersei", email: "Cersei@email.com", phoneNumber: "576-3432"),
    Person(name: "Daenarys", email: "Daenarys@email.com", phoneNumber: "324-5555"),
    Person(name: "Prise", email: "Prise@email.com", phoneNumber: "555-5654")
]
