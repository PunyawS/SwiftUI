//
//  Customer.swift
//  ObservedObject property
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

struct Person: Identifiable {
    var id = UUID()
    var name : String
    var email : String
    var phoneNumber : String
}
