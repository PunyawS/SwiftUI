//
//  ContentView.swift
//  ObservedObject property
//
//  Created by Train2 on 2/2/2565 BE.
//

import SwiftUI

struct ContentView: View {

    @ObservedObject var viewModel = PersonViewModel()
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ScrollView {
                ForEach(viewModel.people) { person in
                    HStack{
                        Text(person.name)
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Spacer()
                        
                        VStack(alignment: .trailing){
                            Text(person.phoneNumber)
                            Text(person.email)
                        }
                    }
                    .frame(height: 80)
                    .padding(12)
                }
            }
            Menu("Menu".uppercased()){
                Button("Reverse") {
                    viewModel.reverseOrder()
                }
                Button("Shuffle") {
                    viewModel.shuffleOrder()
                }
                Button("Remove Last") {
                    viewModel.removeLastPerson()
                }
                Button("Remove First") {
                    viewModel.removeFirstPerson()
                }
            }
            .padding()
        }
    }
}
    


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
