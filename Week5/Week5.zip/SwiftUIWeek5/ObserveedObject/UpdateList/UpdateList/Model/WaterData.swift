//
//  WaterData.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation


struct WaterData : Identifiable, Codable{
    var id = UUID()
    var amount:Int
    var drinkID:Int
    
    init(amount:Int, drink:Int) {
        self.amount = amount
        self.drinkID = drink
        self.id = UUID()
    }
}
