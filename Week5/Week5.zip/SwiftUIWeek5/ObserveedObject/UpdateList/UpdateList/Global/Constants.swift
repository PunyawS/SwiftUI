//
//  Constants.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation


struct Constants{
    
    static var sampleModel = WaterModel(amount: [100])
    
    static let drinks = ["Water","Coffee","Juice","Other"]
    
}
