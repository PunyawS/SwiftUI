//
//  WaterModel.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation

class WaterModel: ObservableObject{
    
    @Published var intake : [WaterData]
    
    init(intake: WaterData) {
        self.intake = [WaterData]()
    }
    
    //Dummy Data to use
    
    init(amount:[Int]){
        self.intake = [WaterData]()
    }
    
    func addIntake(amount:Int, drink: Int) {
        self.intake.append(WaterData(amount: amount, drink: drink))
    }
    
    func removeIntake(offset: IndexSet){
        self.intake.remove(atOffsets: offset)
    }
}
