//
//  ContentView.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var water : WaterModel
    
    @State var addIntakeSheets = false
    
    var body: some View {
        VStack{
            List {
                ForEach(water.intake) { data in
                    Text("amount = \(data.amount)    drink = \(Constants.drinks[data.drinkID])")
                }
                .onDelete(perform: delete)
            }
            //Add intake
            Button {
                addIntakeSheets.toggle()
            } label: {
                    Text("Add Intake")
                    Image(systemName: "drop.fill")
            }
//            .buttonStyle(DefaultButtonStyle())
            .sheet(isPresented: $addIntakeSheets) {
                AddintakeView(water : water)
            }
        }
    }
    func delete(at offsets:IndexSet){
        water.removeIntake(offset: offsets)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(water: Constants.sampleModel)
    }
}
