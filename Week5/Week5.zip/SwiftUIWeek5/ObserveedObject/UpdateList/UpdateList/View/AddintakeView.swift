//
//  AddintakeView.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

struct AddintakeView: View {
    
    @ObservedObject var water: WaterModel
    @State var drinkIndex = 0
    @State var amountIndex = 0
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        //Drink Type picker
        Picker(selection: $drinkIndex) {
            ForEach(0..<Constants.drinks.count) {
                data in
                Text(Constants.drinks[data]).tag(data)
            }
        } label: {
            Text("Picker")
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding(.vertical)
        
        //Amount Picker
        Picker(selection: $amountIndex) {
            ForEach(1..<6){
                number in
                Text("\(number*50) mL")
            }
        } label: {
            Text("Picker")
        }
        .pickerStyle(WheelPickerStyle())

        //Save Button
        Button {
            water.addIntake(amount: (amountIndex+1)*50, drink: drinkIndex)
            self.presentationMode.wrappedValue.dismiss()
        } label: {
            HStack{
                Text("Save")
                Image(systemName: "square.and.arrow.down")
            }
            .frame(width: 200, height: 20, alignment: .center)
            .buttonStyle(DefaultButtonStyle())
        }
    }
}

struct AddintakeView_Previews: PreviewProvider {
    static var previews: some View {
        AddintakeView(water: Constants.sampleModel)
    }
}
