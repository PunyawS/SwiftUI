//
//  AddintakeView.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

struct AddintakeView: View {
    
    @ObservedObject var Shopping: ShoppingModel
    @State var ShoppingIndex = 0
    @State var amountIndex = 0
//    @State var priceX = 0
    
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        VStack {
            //Item Type picker
            Picker(selection: $ShoppingIndex) {
                ForEach(0..<Constants.shopping_List.count) {
                    data in
                    VStack {
                        Text(Constants.shopping_List[data]).tag(data)
                    }
                }
            } label: {
                Text("Picker")
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.vertical)
            
            Picker(selection: $ShoppingIndex) {
                ForEach(0..<Constants.shopping_List.count) {
                    data in
                    VStack {
                        Text("\(Constants.Price_List[data])")
                    }
                }
            } label: {
                Text("Picker")
            }
            .pickerStyle(SegmentedPickerStyle())
            
        //Amount Picker
        Picker(selection: $amountIndex) {
            ForEach(1..<100){
                number in
                Text("\(number*1) ชิ้น ")
            }
        } label: {
            Text("Picker")
        }
        .pickerStyle(WheelPickerStyle())

        //Save Button
        Button {
            Shopping.addIntake(amount: (amountIndex+1), shoppingList: ShoppingIndex, PriceX: ShoppingIndex)
            self.presentationMode.wrappedValue.dismiss()
        } label: {
            HStack{
                Text("Save")
                Image(systemName: "square.and.arrow.down")
            }
            .frame(width: 200, height: 20, alignment: .center)
            .buttonStyle(DefaultButtonStyle())
            }
        }
    }
}

struct AddintakeView_Previews: PreviewProvider {
    static var previews: some View {
        AddintakeView(Shopping: Constants.sampleModel)
    }
}
