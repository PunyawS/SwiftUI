//
//  ContentView.swift
//  Shopping_UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var shopping : ShoppingModel
    
    @State var addIntakeSheets = false
    
    
    var body: some View {
        VStack{
            Text("My Cart")
                .bold()
            Text("ยอดชำระเงิน")
            Text("Total : \(caltotal())")
                
            HStack{
                Spacer()
                Text("สินค้า")
                Spacer()
                Text("จำนวน")
                Spacer()
                Text("ราคา")
                Spacer()
            }
            
            
            List {
                ForEach(shopping.intake) { data in
                    HStack {
                        //สินค้า
                        Spacer()
                        Text("\(Constants.shopping_List[data.shoppingListID])")
                        //จำนวน
                        Spacer()
                        Text("\(data.amount)")
                        Spacer()
                        //ราคา
                        Text("\(Constants.Price_List[data.price]*(data.amount))")
                        Spacer()
                    }
                }
                .onDelete(perform: delete)
            }
            
            
            //Add intake
            Button {
                addIntakeSheets.toggle()
            } label: {
                    Text("Add Intake")
                    Image(systemName: "drop.fill")
            }
//            .buttonStyle(DefaultButtonStyle())
            .sheet(isPresented: $addIntakeSheets) {
                AddintakeView(Shopping: shopping)
            }
            
        }
    }
        func delete(at offsets:IndexSet){
            shopping.removeIntake(offset: offsets)
    }
    func caltotal() -> Int{
        var total = 0
        shopping.intake.forEach { i in
            total = total + (Constants.Price_List[i.price] * i.amount)
        }
        return total
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(shopping: Constants.sampleModel)
    }
}
