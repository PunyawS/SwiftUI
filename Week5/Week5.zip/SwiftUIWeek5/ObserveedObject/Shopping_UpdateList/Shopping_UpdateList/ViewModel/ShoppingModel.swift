//
//  WaterModel.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation

class ShoppingModel: ObservableObject{
    
    @Published var intake : [ShoppingData]
    
    init(intake: ShoppingData) {
        self.intake = [ShoppingData]()
    }
    
    //Dummy Data to use
    init(amount:[Int]){
        self.intake = [ShoppingData]()
    }
    
    
    func addIntake(amount:Int, shoppingList: Int, PriceX: Int) {
        self.intake.append(ShoppingData(amount: amount, shoppingList: shoppingList, PriceX: PriceX))
    }
    
    func removeIntake(offset: IndexSet){
        self.intake.remove(atOffsets: offset)
    }


}

