//
//  Constants.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation


struct Constants{
    
    static var sampleModel = ShoppingModel(amount: [100])
    
    static let shopping_List = ["เสื้อผ้า","กระเป๋า","อาหาร","เครื่องดื่ม","เครื่องใช้ไฟฟ้า"]
    
    static let Price_List = [100,200,100,40,2000]

}
