//
//  WaterData.swift
//  UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation


struct ShoppingData : Identifiable, Codable{
    var id = UUID()
    var amount: Int
    var price: Int
    var shoppingListID: Int
    
    init(amount:Int, shoppingList:Int, PriceX:Int) {
        self.amount = amount
        self.price = PriceX
        self.shoppingListID = shoppingList
        self.id = UUID()
    }
}
