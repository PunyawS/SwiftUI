//
//  Shopping_UpdateListApp.swift
//  Shopping_UpdateList
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

@main
struct Shopping_UpdateListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(shopping: Constants.sampleModel)
        }
    }
}
