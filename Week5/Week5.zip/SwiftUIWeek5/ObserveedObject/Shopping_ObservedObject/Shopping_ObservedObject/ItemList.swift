//
//  ItemList.swift
//  Shopping_ObservedObject
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation

class ItemList {
    //MARK: Add item to itemDataModel
    static var Items = [itemDataModel(name: "เสื้อผ้า", amount: 1, price: 100),
                        itemDataModel(name: "กระเป่า", amount: 1, price: 200),
                        itemDataModel(name: "อาหาร", amount: 1, price: 100),
                        itemDataModel(name: "เครื่องดื่ม", amount: 1, price: 40),
                        itemDataModel(name: "เครื่องใช้ไฟฟ้า", amount: 1, price: 2000)]
}
