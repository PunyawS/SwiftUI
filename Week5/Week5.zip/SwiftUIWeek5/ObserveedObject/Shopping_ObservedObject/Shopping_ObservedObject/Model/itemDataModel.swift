//
//  itemDataModel.swift
//  Shopping_ObservedObject
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation

struct itemDataModel: Codable, Identifiable {
    var name: String
    var amount: Int
    var price: Int
    var id = UUID()
    
    init(name: String, amount: Int, price: Int) {
        self.name = name
        self.amount = amount
        self.price = price
    }
}
