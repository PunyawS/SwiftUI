//
//  Shopping_ObservedObjectApp.swift
//  Shopping_ObservedObject
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

@main
struct Shopping_ObservedObjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
