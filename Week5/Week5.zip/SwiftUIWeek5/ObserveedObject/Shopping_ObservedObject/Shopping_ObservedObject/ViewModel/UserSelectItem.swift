//
//  userSelectItem.swift
//  Shopping_ObservedObject
//
//  Created by Train2 on 3/2/2565 BE.
//

import Foundation

class UserSelectItem: ObservableObject {
    
    @Published var Items = [itemDataModel]()
    
    //MARK: AddItem when user select
    func addItem(name: String, amount: Int, price: Int) {
        self.Items.append(itemDataModel(name: name, amount: amount, price: price))
    }
    
    func deleteItem(offset: IndexSet) {
        self.Items.remove(atOffsets: offset)
    }
}
