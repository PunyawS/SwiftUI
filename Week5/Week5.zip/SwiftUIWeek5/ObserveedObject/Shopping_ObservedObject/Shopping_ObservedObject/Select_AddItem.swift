//
//  Select_AddItem.swift
//  Shopping_ObservedObject
//
//  Created by Train2 on 3/2/2565 BE.
//

import SwiftUI

struct Select_AddItem: View {
    
    @ObservedObject var selectedItem = UserSelectItem()
    
    @State var itemAmount = 1
    @State var itemSelect = [Int](repeating: 0, count: ItemList.Items.count)
    @State var showalert = false
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {Spacer()
            Text("List รายการสินค้า: ")
            
            List {
                ForEach(0..<ItemList.Items.count) { item in
                    HStack {
                        //Item for Shopping
                        Text(ItemList.Items[item].name)
                            .frame(width: 70, alignment: .center)
                        
                        //จำนวนที่ต้องการ
                        TextField("Amount", value: $itemSelect[item], formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 30, alignment: .center)
                        
                        //Price product
                        Text("\(ItemList.Items[item].price)")
                            .frame(width: 70, alignment: .center)
                        
                        //Button Add Item
                        Button(action: {
                            selectedItem.addItem(name: ItemList.Items[item].name, amount: itemSelect[item], price: sumPrice(price: ItemList.Items[item].price, amount: itemSelect[item]))
                            showalert = true
                            
                        }, label: {
                            Text("Add")
                        })
                            .buttonStyle(.borderedProminent)
                            .alert("Item Added!", isPresented: $showalert) {
                                Button("Continue shopping") { }
                                Button("To First Page") { presentationMode.wrappedValue.dismiss() }
                            }
                    }
                }
            }
            
            //Button OK
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }, label: {
                Text("OK")
            })
            Spacer()
        }
    }
    
    func sumPrice(price: Int, amount: Int) -> Int {
        var sum = 0
        sum = price * amount
        return sum
    }
    
    
}


//struct Select_AddItem_Previews: PreviewProvider {
//    static var previews: some View {
//        Select_AddItem()
//    }
//}
