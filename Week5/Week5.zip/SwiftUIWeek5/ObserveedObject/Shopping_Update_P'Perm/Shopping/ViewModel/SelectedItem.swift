//
//  SelectItem.swift
//  Shopping
//
//  Created by Train3 on 3/2/2565 BE.
//

import Foundation

class SelectedItem: ObservableObject {
    @Published var Items = [ItemDetail]()
    
    func addItem(name: String, amount: Int, price: Int) {
        self.Items.append(ItemDetail(name: name, amount: amount, price: price))
    }
    
    func deleteItem(offset: IndexSet) {
        self.Items.remove(atOffsets: offset)
    }
}
