//
//  ShoppingApp.swift
//  Shopping
//
//  Created by Train3 on 3/2/2565 BE.
//

import SwiftUI

@main
struct ShoppingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
