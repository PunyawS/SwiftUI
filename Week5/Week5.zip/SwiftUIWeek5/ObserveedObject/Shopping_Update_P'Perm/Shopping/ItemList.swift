//
//  Dummy.swift
//  Shopping
//
//  Created by Train3 on 3/2/2565 BE.
//

import Foundation

class ItemList {
    static var Items = [ItemDetail(name: "เสื้อผ้า", amount: 1, price: 100),
                        ItemDetail(name: "กระเป่า", amount: 1, price: 200),
                        ItemDetail(name: "อาหาร", amount: 1, price: 100),
                        ItemDetail(name: "เครื่องดื่ม", amount: 1, price: 40),
                        ItemDetail(name: "เครื่องใช้ไฟฟ้า", amount: 1, price: 2000)]
}

