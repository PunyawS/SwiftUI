//
//  ContentView.swift
//  Shopping
//
//  Created by Train3 on 3/2/2565 BE.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var selectedItem = SelectedItem()
    
    //@State var sum = 0
    
    @State var chooseItem = false
    
    var body: some View {
        VStack {
            Spacer()
            Text("My Cart")
            Text("ยอดชำระเงิน")
            Text("\(calSum())")
            
            //list
            HStack {
                Text("สินค้า")
                Spacer()
                Text("จำนวน")
                Spacer()
                Text("ราคา")
            }
            .padding()
            
            List {
                ForEach(selectedItem.Items) { item in
                    HStack {
                        Text(item.name)
                        Spacer()
                        Text("\(item.amount)")
                        Spacer()
                        Text("\(item.price)")
                    }
                }
                .onDelete(perform: delete)
            }
            
            Button(action: {
                chooseItem = true
            }, label: {
                Text("สินค้า")
            })
                .sheet(isPresented: $chooseItem) {
                    ItemListView(selectedItem: selectedItem)
                }
        }
    }
    
    func delete(at offsets: IndexSet) {
        selectedItem.deleteItem(offset: offsets)
    }
    
    func calSum() -> Int {
        var sum = 0
            for item in selectedItem.Items {
                sum = sum + item.price
            }
        return sum
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
