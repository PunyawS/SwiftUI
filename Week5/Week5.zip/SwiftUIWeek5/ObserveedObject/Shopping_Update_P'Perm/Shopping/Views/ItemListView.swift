//
//  ItemListView.swift
//  Shopping
//
//  Created by Train3 on 3/2/2565 BE.
//

import Foundation
import SwiftUI

struct ItemListView: View {
    
    @ObservedObject var selectedItem: SelectedItem
    
    @State var itemAmount = 1
    @State var itemAmount2 = [Int](repeating: 1, count: ItemList.Items.count)
    @State var showalert = false
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {Spacer()
            Text("List รายการสินค้า: ")
            
            List {
                ForEach(0..<ItemList.Items.count) { item in
                    HStack {
                        Text(ItemList.Items[item].name)
                            .frame(width: 70, alignment: .center)
                        
                        TextField("Amount", value: $itemAmount2[item], formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 30, alignment: .center)
                        
                        Text("\(ItemList.Items[item].price)")
                            .frame(width: 70, alignment: .center)
                        
                        Button(action: {
                            selectedItem.addItem(name: ItemList.Items[item].name, amount: itemAmount2[item], price: sumPrice(price: ItemList.Items[item].price, amount: itemAmount2[item]))
                            showalert = true
                            
                            //print("aaa: \(sumPrice(item: ItemList.Items[item]))")
                        }, label: {
                            Text("Add")
                        })
                            .buttonStyle(.borderedProminent)
                            .alert("Item Added!", isPresented: $showalert) {
                                Button("Continue shopping") { }
                                Button("To First Page") { presentationMode.wrappedValue.dismiss() }
                            }
                    }
                }
            }
            
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }, label: {
                Text("OK")
            })
            Spacer()
        }
    }
    
    func sumPrice(price: Int, amount: Int) -> Int {
        var sum = 0
        sum = price * amount
        return sum
    }
}
