//
//  record_drinking_waterApp.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

@main
struct record_drinking_waterApp: App {
    
    init(){
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor : UIColor.black]
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
