//
//  Add.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

struct Add_Intake: View {
    
    
    @ObservedObject var data_Api = WaterManager.init()
    @State private var selectedDrink: String = ""
    @State private var selectedML: String = "50"

    
    static var addIntakeRecord = getArrayIntakeRecordFromUSDF()
    @Environment(\.presentationMode) private var presentationMode
    
    @State private var showingAlert = false
    
    
    
    var body: some View {
        VStack{
            Spacer()
            Text("New Intake")
                .font(.system(size: 45, weight: .bold, design: .rounded))
                .padding()
            VStack {
                if selectedDrink == "" {
                    Text("Please select your Drink")
                }
                else{
                    Text("You're selected : \(selectedDrink)")
                }
                //MARK: Drinktype
                Picker("Select", selection: $selectedDrink) {
                    ForEach(data_Api.water) {
                        data in
                        Text("\(data.drinktype)").tag("\(data.drinktype)")
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                Spacer()
               
                //MARK: img color water drop
                    Image(systemName: "drop.fill")
                        .resizable()
                        .frame(width: 50, height: 75)
                        .foregroundColor(changeColor(water_Drink: selectedDrink))
                
                
                //MARK: Select mL
                Picker("Select mL", selection: $selectedML) {
                    ForEach(50..<2501) {
                        range in
                        if range%50 == 0 {
                            Text("\(range) mL").tag("\(range)")
                        }
                    }
                }
                .pickerStyle(WheelPickerStyle())
                
                Spacer()
                
                //MARK: Button
                Button {
                    if selectedDrink != ""{
                        addRecord(record: getArrayIntake_UserSelect(selectedDrink: selectedDrink, selectedML: selectedML))
                        //send value to USDFKeys
                        UserDefaults.standard.set(Add_Intake.addIntakeRecord, forKey: USDF_Keys.addIntake)
                        UserDefaults.standard.synchronize()

                        
                        
                        
                        
//                        print(getArrayIntakeRecordFromUSDF())
                        NotificationCenter.default.post(name: Notification.Add_inTake_array, object: getArrayIntakeRecordFromUSDF())
                        
                        NotificationCenter.default.post(name: Notification.Add_inTake_Drink, object: sumDrink())
                        
                        presentationMode.wrappedValue.dismiss()
                    }
                    else{
                        showingAlert = true
                    }
                } label: {
                    HStack {
                        Text("Save Goal")
                        Image(systemName: "square.and.arrow.down")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                    }.frame(width: 150, height: 50)
                }
                
                .buttonStyle(.borderedProminent)
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Alert !!!"), message: Text("Please select your Drink"))
                }
               
                Spacer()
            }
        }
    }
}

struct Add_Previews: PreviewProvider {
    static var previews: some View {
        Add_Intake()
    }
}
