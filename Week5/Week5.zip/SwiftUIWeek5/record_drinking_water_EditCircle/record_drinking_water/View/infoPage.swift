//
//  infoPage.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

struct infoPage: View {
    
    @ObservedObject var data_Api = WaterManager.init()
    
    var body: some View {
        VStack{
            Spacer()
            Text("Info")
                .font(.system(size: 45, weight: .bold, design: .rounded))
                .padding()
            Text("\(data_Api.Infos)")
                .frame(alignment: .center)
                .font(.system(size: 26,weight: .light, design: .rounded))
                .padding()
            Spacer()  
        }
    }
}

struct infoPage_Previews: PreviewProvider {
    static var previews: some View {
        infoPage()
    }
}
