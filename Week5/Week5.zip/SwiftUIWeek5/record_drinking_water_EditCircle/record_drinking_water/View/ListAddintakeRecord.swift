//
//  ListAddintake.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

struct ListAddintakeRecord: View {
    
    @State var addintakeRecord = [[String]]()
    @State var refresh: Bool = false
    @State var sum = sumDrink()
    
    var body: some View {
        //MARK: List selection
        List{
            ForEach(addintakeRecord, id: \.self) { data in
                HStack {
                    Text(data[0])
                        .frame(width: 75, alignment: .leading)
                    Image(systemName: "drop.fill")
                        .resizable()
                        .frame(width: 20, height: 30)
                        .foregroundColor(changeColor(water_Drink: data[0]))
                    Text("\(data[1]) mL")
                        .frame(width: 75, alignment: .trailing)
                    Text(data[2])
                        .frame(width: 75, alignment: .trailing)
                }
            }
            .onDelete(perform: removeRowbyUSDF)
            .listRowSeparator(.hidden)
        }
        
        .onAppear {
            addintakeRecord = getArrayIntakeRecordFromUSDF()
        }
        .padding()
          
        .onReceive(NotificationCenter.default.publisher(for: Notification.Add_inTake_array)) { Noti in
            self.addintakeRecord = getArrayIntakeRecordFromUSDF()
        }
    }
    
    
    //MARK: Remove Row in List
    //remove dataArray
    func removeRowbyUSDF(at Offsets_index: IndexSet) {
        addintakeRecord.remove(atOffsets: Offsets_index)
        UserDefaults.standard.set(addintakeRecord,forKey: USDF_Keys.addIntake)
        UserDefaults.standard.synchronize()
        print(addintakeRecord)
        
        if addintakeRecord == [] {
            UserDefaults.standard.removeObject(forKey: USDF_Keys.addIntake)
            UserDefaults.standard.synchronize()
            print(addintakeRecord)
        }
        
        sum = sumDrink()
        NotificationCenter.default.post(name: Notification.Add_inTake_Drink, object: sum)
        
        //Check remove Text of dataArray
        
        print("sum: \(sum)")
    }
}

struct ListAddintake_Previews: PreviewProvider {
    static var previews: some View {
        ListAddintakeRecord()
    }
}
