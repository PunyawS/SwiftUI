//
//  SettingPage.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import SwiftUI

struct SettingPage: View {
    
    @State private var goalML = ContentView.getGoalFromUSDF()
    
    @Environment(\.presentationMode) private var presentationMode
    
    var body: some View {
        VStack{
            Text("Settings")
                .font(.system(size: 45, weight: .bold, design: .rounded))
            
            Spacer()
            Text("Set you Goal : \(goalML) mL")
            
            //MARK: Select mL
            Picker("Select mL", selection: $goalML) {
                ForEach(50..<2501) {
                    range in
                    if range%50 == 0 {
                        Text("\(range) mL").tag("\(range)")
                    }
                }
            }
            .pickerStyle(WheelPickerStyle())
            
            //MARK: Button setGoal
            Button {
                //send value to USDFKeys
                UserDefaults.standard.set(goalML, forKey: USDF_Keys.goal)
                UserDefaults.standard.synchronize()
                
                NotificationCenter.default.post(name: Notification.setting_Goal, object: goalML)
                
                presentationMode.wrappedValue.dismiss()
                
            } label: {
                HStack {
                    Text("Save Goal")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                    Image(systemName: "square.and.arrow.down")
                }.frame(width: 180, height: 40)
            }
            .buttonStyle(.borderedProminent)
            Spacer()
        }
    }
}

struct SettingPage_Previews: PreviewProvider {
    static var previews: some View {
        SettingPage()
    }
}
