//
//  ZodiacManager.swift
//  LoadAPI1
//
//  Created by Macbook16 on 12/1/2565 BE.
//

import Foundation

class WaterManager: ObservableObject {
    
    @Published var water = [Water_Drinks]()
    @Published var Infos = ""
    
    
    init() {
        loadData()
    }
    func loadData() {
        
        let path = "https://jsonkeeper.com/b/D4LI"
        guard let url = URL.init(string: path) else {return}
        
        URLSession.shared.dataTask(with: URLRequest.init(url: url)) { data, _, err in
            
            if let err_tmp = err {
                print(err_tmp.localizedDescription)
                return
            }
           
            guard let dataResoponse = data else {return}
            
            let WaterResponse_default = try? JSONDecoder().decode(WaterResponse.self, from: dataResoponse)
            
            DispatchQueue.main.async {
    
                if let WaterResponsedata = WaterResponse_default {
                    self.water = WaterResponsedata.Drink
                    self.Infos = WaterResponsedata.info
                
                    print("self.water : \(self.water)")
                    print("self.water : \(self.Infos)")
                }
            }
        }.resume()
    }
}
