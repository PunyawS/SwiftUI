//
//  Zodiac.swift
//  LoadAPI Json
//
//  Created by Train2 on 12/1/2565 BE.
//

import Foundation

struct WaterResponse: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case intakeincrement
        case goalincrement
        case basegoal
        case info
        case Drink
    }
    
    var id = UUID()
    var intakeincrement: Int
    var goalincrement: Int
    var basegoal: Int
    var info: String
    var Drink: [Water_Drinks]
}

struct Water_Drinks: Identifiable, Codable {
    enum CodingKeys: CodingKey {
        case id
        case drinktype
    }
    
    var id: Int
    var drinktype: String
}
