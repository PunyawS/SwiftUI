//
//  UserDefault.swift
//  DrinkingAlert
//
//  Created by Train3 on 1/2/2565 BE.
//

import Foundation

struct USDF_Keys {
    static let goal: String = "goal"
    
    static let addIntake: String = "addIntake"
}
