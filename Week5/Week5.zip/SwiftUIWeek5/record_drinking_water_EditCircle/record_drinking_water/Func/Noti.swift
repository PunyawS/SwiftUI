//
//  Extension.swift
//  Tab_snow
//
//  Created by Train2 on 18/1/2565 BE.
//

import Foundation

extension Notification {
    

    static let Add_inTake_Drink = Notification.Name.init("Add_inTake_Drink")
    
    static let Add_inTake_array = Notification.Name.init("Add_inTake_array")
    
    static let setting_Goal = Notification.Name.init("setting_Goal")
    
}

