//
//  getDate.swift
//  record_drinking_water
//
//  Created by Train2 on 1/2/2565 BE.
//

import Foundation
import SwiftUI

//MARK: Current Date // Time
func getCurrentDate()->String{
    let today = Date()
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    formatter.locale = Locale.init(identifier: "th_TH")
    let TextDate = formatter.string(from: today)
    return TextDate
}

func getCurrentTime() -> String {
    let formatter = DateFormatter()
    formatter.timeStyle = .short

    let dateString = formatter.string(from: Date())
    return dateString
}


//MARK: Get Array drink, mL, Date when User select Drink
func getArrayIntake_UserSelect(selectedDrink:String, selectedML:String) -> [String] {
    let intake = [selectedDrink, selectedML, getCurrentTime()]
    return intake
}

//MARK: get Record from USDF Keys
func getArrayIntakeRecordFromUSDF() -> [[String]] {
    var arrayList = [[String]]()
    if let listData = UserDefaults.standard.array(forKey: USDF_Keys.addIntake) {
        arrayList = listData as! [[String]]
        print(arrayList)
    }
    return arrayList
}


//MARK: Add Record to List
// Addnew to top listarray
func addRecord(record: [String]) {
    Add_Intake.addIntakeRecord.insert(record, at: 0)
}


//MARK: Change Color Water
func changeColor(water_Drink:String)->Color{
    var Color_water = Color.white
    
    if water_Drink == "Water" {
        Color_water = Color.blue
    }
    else if water_Drink == "Coffee" {
        Color_water = Color.brown
    }
    else if water_Drink == "Juice" {
        Color_water = Color.orange
    }
    else if water_Drink == "Other" {
        Color_water = Color.purple
    }
    
    return Color_water
}

//MARK: Total Drink
func sumDrink() -> Int {
    var sum = 0
    var listArray = [[String]]()
    
    if let listArrayData = UserDefaults.standard.array(forKey: USDF_Keys.addIntake) {
        listArray = listArrayData as! [[String]]
    }
    
    for item in listArray {
        sum = sum + Int(item[1])!
    }
    
    return sum
}

//MARK: Cal %
func percentCalculation(goal: String) -> Float {
    var percent: Float = 0.00
    
    let floatGoal = Float(goal)
    let Sum = sumDrink()
    let floatSum = Float(Sum)
    
    percent = (floatSum/floatGoal!)*100
    
    return percent
}

