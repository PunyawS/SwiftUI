//
//  CircleNumberView.swift
//  SwiftUI_Navigation
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

struct CircleNumberView: View {
    
    var color: Color
    var number: Int
    
    var body: some View {
        ZStack{
            Circle()
                .frame(width: 200, height: 200)
                .foregroundColor(color)
            Text("\(number)")
                .foregroundColor(.white)
                .font(.system(size: 70, weight: .bold))
            
        }
    }
}

struct CircleNumberView_Previews: PreviewProvider {
    static var previews: some View {
        CircleNumberView(color: .blue, number: 1)
    }
}
