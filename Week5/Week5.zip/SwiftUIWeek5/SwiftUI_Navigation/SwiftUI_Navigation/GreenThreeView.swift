//
//  GreenThreeView.swift
//  SwiftUI_Navigation
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

struct GreenThreeView: View {
    
    
    var body: some View {
        VStack {
            CircleNumberView(color: .green, number: 3)
                .navigationTitle("Green Three")
            .offset(y: -60)
        }
    }
}

struct GreenThreeView_Previews: PreviewProvider {
    static var previews: some View {
        GreenThreeView()
    }
}
