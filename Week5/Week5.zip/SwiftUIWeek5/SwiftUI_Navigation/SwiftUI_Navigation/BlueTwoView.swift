//
//  BlueTwoView.swift
//  SwiftUI_Navigation
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

struct BlueTwoView: View {
    
    var color : Color
    
    var body: some View {
        VStack {
            CircleNumberView(color: color, number: 2)
                .navigationTitle("Blue Two")
            .offset(y: -60)
            
            NavigationLink {
                GreenThreeView()
            } label: {
                Text("Next Screen")
                    .bold()
                    .frame(width: 280, height: 50)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
    }
}


struct BlueTwoView_Previews: PreviewProvider {
    static var previews: some View {
        BlueTwoView(color: .blue)
    }
}
