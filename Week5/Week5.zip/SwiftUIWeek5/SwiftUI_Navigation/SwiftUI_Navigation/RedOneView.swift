//
//  ContentView.swift
//  SwiftUI_Navigation
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

struct RedOneView: View {
    var body: some View {
        NavigationView{
            VStack {
                CircleNumberView(color: .red, number: 1)
                    .navigationBarTitle("Red One", displayMode: .inline)
                .offset(y: -60)
                
                NavigationLink {
                    BlueTwoView(color: .blue)
                } label: {
                    Text("Next Screen")
                        .bold()
                        .frame(width: 280, height: 50)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
        }
        .accentColor(Color(.label))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        RedOneView()
    }
}
