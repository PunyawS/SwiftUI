//
//  SwiftUI_NavigationApp.swift
//  SwiftUI_Navigation
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_NavigationApp: App {
    
    init(){
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor : UIColor.black]
    }
    
    var body: some Scene {
        WindowGroup {
            RedOneView()
        }
    }
}
