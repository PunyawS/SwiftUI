//
//  ContactView.swift
//  CTObjC
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI
import UIKit

//SwiftUI show Swift_Sb
struct ContactViewSB: UIViewControllerRepresentable {
    
    private let contentSB = SBViewController.init()
    
    func makeUIViewController(context: Context) -> SBViewController {
        return contentSB
    }
    func updateUIViewController(_ uiView: SBViewController, context: Context) {
       
    }
}

struct ContactViewObjc: UIViewControllerRepresentable {
    
    private let contentObjc = ObjcViewController.init()
    
    func makeUIViewController(context: Context) -> ObjcViewController {
        return contentObjc
    }
    func updateUIViewController(_ uiView: ObjcViewController, context: Context) {
       
    }
}
