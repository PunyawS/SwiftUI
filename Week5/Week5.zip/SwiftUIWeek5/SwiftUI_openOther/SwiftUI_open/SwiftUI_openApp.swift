//
//  SwiftUI_openApp.swift
//  SwiftUI_open
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_openApp: App {
    var body: some Scene {
        WindowGroup {
            SwUIContentView()
        }
    }
}
