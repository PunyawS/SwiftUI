//
//  ContentView.swift
//  SwiftUI_open
//
//  Created by Train2 on 31/1/2565 BE.
//

import SwiftUI
import UIKit

struct SwUIContentView: View {
    
    @State var showSB:Bool = false
    @State var showObjc:Bool = false
    
    var body: some View {
        VStack(spacing:50) {
                Button {
                    showSB.toggle()
                } label: {
                    Text("Show StoryBoard")
                }
                Button {
                    showObjc.toggle()
                } label: {
                    Text("Show StoryBoard")
                }
            }
        .sheet(isPresented: $showSB) {
            ContactViewSB.init()
        }
        .sheet(isPresented: $showObjc) {
            ContactViewObjc.init()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        SwUIContentView()
    }
}
