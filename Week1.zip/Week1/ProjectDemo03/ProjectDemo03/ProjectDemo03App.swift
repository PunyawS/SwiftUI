//
//  ProjectDemo03App.swift
//  ProjectDemo03
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct ProjectDemo03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
