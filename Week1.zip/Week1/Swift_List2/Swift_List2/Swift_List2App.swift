//
//  Swift_List2App.swift
//  Swift_List2
//
//  Created by Train2 on 6/1/2565 BE.
//

import SwiftUI

@main
struct Swift_List2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
