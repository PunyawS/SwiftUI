//
//  JSON_pizzaApp.swift
//  JSON pizza
//
//  Created by Train3 on 6/1/2565 BE.
//

import SwiftUI

@main
struct JSON_pizzaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
