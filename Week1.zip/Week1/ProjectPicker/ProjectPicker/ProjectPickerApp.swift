//
//  ProjectPickerApp.swift
//  ProjectPicker
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct ProjectPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
