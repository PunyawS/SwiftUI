//
//  Slots_ChallengeApp.swift
//  Slots-Challenge
//
//  Created by Train2 on 6/1/2565 BE.
//

import SwiftUI

@main
struct Slots_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
