//
//  Cancer.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Cancer: View {
    var body: some View{
        Text("Hello Cancer")
    }
}

struct F_Cancer_Previews : PreviewProvider {
    static var previews: some View{
        F_Cancer()
    }
}
