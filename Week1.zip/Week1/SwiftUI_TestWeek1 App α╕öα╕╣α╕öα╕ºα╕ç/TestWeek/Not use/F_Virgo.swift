//
//  Virgo.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Virgo: View {
    var body: some View{
        Text("Hello Virgo")
    }
}

struct F_Virgo_Previews : PreviewProvider {
    static var previews: some View{
        F_Virgo()
    }
}
