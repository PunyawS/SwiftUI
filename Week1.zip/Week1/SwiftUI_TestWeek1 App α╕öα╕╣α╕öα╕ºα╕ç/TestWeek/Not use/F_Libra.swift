//
//  Libra.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Libra: View {
    var body: some View{
        Text("Hello Libra")
    }
}

struct F_Libra_Previews : PreviewProvider {
    static var previews: some View{
        F_Libra()
    }
}
