//
//  Pisces.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Pisces: View {
    var body: some View{
        Text("Hello Leo")
    }
}

struct F_Piaces_Previews : PreviewProvider {
    static var previews: some View{
        F_Pisces()
    }
}
