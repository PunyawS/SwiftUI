//
//  Taurus.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Taurus: View {
    var body: some View{
        Text("Hello Taurus")
    }
}

struct F_Taurus_Previews : PreviewProvider {
    static var previews: some View{
        F_Taurus()
    }
}
