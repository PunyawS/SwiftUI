//
//  Capricorn.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Capricorn: View {
    var body: some View{
        Text("Hello Capricorn")
    }
}

struct F_Capricorn_Previews : PreviewProvider {
    static var previews: some View{
        F_Capricorn()
    }
}
