//
//  Aries.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Aries: View {
    var body: some View{
        Text("Hello Aries")
    }
}

struct F_Aries_Previews : PreviewProvider {
    static var previews: some View{
        F_Aries()
    }
}
