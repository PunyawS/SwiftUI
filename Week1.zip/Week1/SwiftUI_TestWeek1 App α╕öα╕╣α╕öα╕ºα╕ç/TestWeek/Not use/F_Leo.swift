//
//  Leo.swift
//  2022
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

struct F_Leo: View {
    var body: some View{
        Text("Hello Leo")
    }
}

struct F_Leo_Previews : PreviewProvider {
    static var previews: some View{
        F_Leo()
    }
}
