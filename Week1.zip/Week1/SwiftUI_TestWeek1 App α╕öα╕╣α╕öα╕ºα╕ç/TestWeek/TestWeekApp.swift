//
//  TestWeekApp.swift
//  TestWeek
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

@main
struct TestWeekApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
