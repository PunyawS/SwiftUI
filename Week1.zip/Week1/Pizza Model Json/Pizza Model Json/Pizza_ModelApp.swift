//
//  Pizza_ModelApp.swift
//  Pizza Model
//
//  Created by Train2 on 6/1/2565 BE.
//

import SwiftUI

@main
struct Pizza_ModelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
