//
//  PickerContralChellengeApp.swift
//  PickerContralChellenge
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

@main
struct PickerContralChellengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
