//
//  HorsscopeApp.swift
//  Horsscope
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

@main
struct HorsscopeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
