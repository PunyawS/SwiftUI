//
//  SwiftUI_CollectionViewApp.swift
//  SwiftUI CollectionView
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_CollectionViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
