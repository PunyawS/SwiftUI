//
//  test1App.swift
//  test1
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct test1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
