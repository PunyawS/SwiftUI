//
//  SwiftUI_IgnoreSafeAreaApp.swift
//  SwiftUI IgnoreSafeArea
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_IgnoreSafeAreaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
