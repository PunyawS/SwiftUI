//
//  Challenge_TabViewApp.swift
//  Challenge TabView
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct Challenge_TabViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
