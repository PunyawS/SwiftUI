//
//  SwiftUI_RecipeApp.swift
//  SwiftUI Recipe
//
//  Created by Train2 on 6/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_RecipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
