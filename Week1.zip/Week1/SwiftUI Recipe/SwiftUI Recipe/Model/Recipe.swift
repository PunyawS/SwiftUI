//
//  Recipe.swift
//  SwiftUI Recipe
//
//  Created by Train2 on 6/1/2565 BE.
//

import Foundation

struct Recipe: Identifiable{
    var id = UUID()
    var name = ""
    var cuisine = ""
}
