//
//  War_ChallengeApp.swift
//  War-Challenge
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct War_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
