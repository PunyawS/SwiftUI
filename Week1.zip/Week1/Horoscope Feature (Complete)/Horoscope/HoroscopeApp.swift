//
//  HoroscopeApp.swift
//  Horoscope
//
//  Created by Train3 on 7/1/2565 BE.
//

import SwiftUI

@main
struct HoroscopeApp: App {
    var body: some Scene {
        WindowGroup {
            ZodiacTabView()
        }
    }
}
