//
//  ProjectDemo02App.swift
//  ProjectDemo02
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct ProjectDemo02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
