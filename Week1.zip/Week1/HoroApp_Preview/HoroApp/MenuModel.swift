//
//  MyModel.swift
//  HoroApp
//
//  Created by Chonlada on 5/1/2565 BE.
//

import SwiftUI

class MenuModel: ObservableObject {
    @Published var menu_no = 0
}
