//
//  HoroAppApp.swift
//  HoroApp
//
//  Created by Chonlada on 5/1/2565 BE.
//

import SwiftUI

@main
struct HoroAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
