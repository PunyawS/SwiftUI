//
//  HoroView3.swift
//  HoroApp
//
//  Created by Chonlada on 5/1/2565 BE.
//

import SwiftUI

struct HoroView3: View {
    @EnvironmentObject var menu: MenuModel

    var body: some View {
        Text("ดูดวงแนะนำ")
    }
}

struct HoroView3_Previews: PreviewProvider {
    static var previews: some View {
        HoroView3()
    }
}
