//
//  ProjectBuymeacoffeeApp.swift
//  ProjectBuymeacoffee
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct ProjectBuymeacoffeeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
