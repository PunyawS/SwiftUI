//
//  ContentViewApp.swift
//  ContentView
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct ContentViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
