//
//  SwiftUI_ScrollViewApp.swift
//  SwiftUI ScrollView
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_ScrollViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
