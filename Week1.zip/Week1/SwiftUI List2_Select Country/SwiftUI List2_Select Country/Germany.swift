//
//  Germany.swift
//  SwiftUI List2_Select Country
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

struct Germany: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Germany_Previews: PreviewProvider {
    static var previews: some View {
        Germany()
    }
}
