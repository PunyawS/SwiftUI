//
//  SwiftUI_List2_Select_CountryApp.swift
//  SwiftUI List2_Select Country
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_List2_Select_CountryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
