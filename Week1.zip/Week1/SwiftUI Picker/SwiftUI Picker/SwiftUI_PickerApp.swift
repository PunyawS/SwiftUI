//
//  SwiftUI_PickerApp.swift
//  SwiftUI Picker
//
//  Created by Train2 on 4/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_PickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
