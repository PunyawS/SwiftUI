//
//  HoreAppApp.swift
//  HoreApp
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct HoreAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
