//
//  Picker_DemoApp.swift
//  Picker Demo
//
//  Created by Train2 on 7/1/2565 BE.
//

import SwiftUI

@main
struct Picker_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
