//
//  SwiftUI_JsonApp.swift
//  SwiftUI Json
//
//  Created by Train2 on 6/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_JsonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
