import UIKit

var symbols = ["fruit1","fruit2","fruit3"]
print(symbols.count)
