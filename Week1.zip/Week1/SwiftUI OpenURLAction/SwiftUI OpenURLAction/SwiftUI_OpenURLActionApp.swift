//
//  SwiftUI_OpenURLActionApp.swift
//  SwiftUI OpenURLAction
//
//  Created by Train2 on 5/1/2565 BE.
//

import SwiftUI

@main
struct SwiftUI_OpenURLActionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
