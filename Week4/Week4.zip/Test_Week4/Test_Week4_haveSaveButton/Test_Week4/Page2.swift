//
//  Page2.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class Page2: UIViewController {

    //MARK: Create Variable for check condition Delegate
//    var setting = Page3.init()
    var imageStyle: String = "1"

    @IBOutlet weak var tbv: UITableView!
    
    //MARK: OpenSheet
    @IBAction func buttonOpenSheet(_ sender: Any) {
        let openSheet = Page3.init()
        openSheet.modalPresentationStyle = .formSheet
        //Connect Delegate between Page2 and Page3
        //self = Page2
        openSheet.selectionDelegate = self
        //
        self.present(openSheet, animated: true, completion: nil)
    }
    
    //MARK: User API load Block
    private var arr_cat:[Mymodel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Page 2"
        
        
        //MARK: Register TableView
        tbv.register(UINib.init(nibName: "TbvCell", bundle: nil), forCellReuseIdentifier: "TbvCell")
        
        
        //MARK: Block
        //API Load Block
        ClassLoaderBlock.loadData_Block { success, cat in
            if success{
                DispatchQueue.main.async {
                    self.arr_cat = cat ?? []
                    self.tbv.reloadData()
                }
            }
        }
    }
}

//MARK: Create TableView
extension Page2 : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //เรียกใช้ Row ตามข้อมูลใน API
        return arr_cat.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //สร้างแบบใช้ xib TableView
        let cell:TbvCell =  tableView.dequeueReusableCell(withIdentifier: "TbvCell") as! TbvCell
        
        let model:Mymodel = arr_cat[indexPath.row]
        
        //send mutivariable to tbvcell
        cell.setUICell(model: model, imageStyle1: self.imageStyle)
        
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = .blue
            cell.nameLabel.textColor = .white
        } else {
            cell.backgroundColor = .white
            cell.nameLabel.textColor = .blue
        }
        
        return cell
    }
}

//MARK: Call func didtop Delegate from Page3
extension Page2 : Page3Delegate {
    func didTap(imgSquare: String) {
        self.imageStyle = imgSquare
        self.tbv.reloadData()
        
        
//        if imgSquare == "1" {
//            self.imageStyle = "1"
//            self.tbv.reloadData()
//        }else{
//            self.imageStyle = "2"
//            self.tbv.reloadData()
//        }
    }
}
