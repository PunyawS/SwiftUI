//
//  LoaderBlock.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation


class ClassLoaderBlock : ObservableObject {
    
    static func loadData_Block(completeionHandler: @escaping (Bool, [Mymodel]?) -> Void){
        guard let url = URL(string: path_Global) else {return}
        
        URLSession.shared.dataTask(with: url) { data, response, err in
            //check error
            if err != nil {
                return
            }
            //check data is nil if nil return it
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse{
                completeionHandler(true, decodeResponse_tmp.cat)
                print("self.Cat : \(decodeResponse_tmp.cat)")
            }
        }.resume()
    }
}


