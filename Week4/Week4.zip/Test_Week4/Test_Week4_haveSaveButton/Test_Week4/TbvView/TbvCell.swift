//
//  TbvCell.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit
import SDWebImage


class TbvCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    //MARK: Create UICell
    //get multivariable from page2 cell.setUICell(model: model, imageStyle1: self.imageStyle)
    func setUICell(model:Mymodel, imageStyle1: String){
        
        idLabel.text = "\(model.id)"
        nameLabel.text = "\(model.name)"
        
        
        //MARK: Check condition imgaeStyle
        if imageStyle1 == "1" {
            img.setNeedsLayout()
            img.layer.masksToBounds = true
            img.layer.cornerRadius = 0
        }
        
        else if imageStyle1 == "2" {
            img.setNeedsLayout()
            img.layer.masksToBounds = true
            img.layer.cornerRadius = img.bounds.width / 2
        }
        
        let imageURL = NSURL(string: "\(model.image)")
        
        if let url = imageURL {
            img.sd_setImage(with: url as URL, placeholderImage: UIImage(named: "apple"))
            self.img.contentMode = UIImageView.ContentMode.scaleAspectFill
        }
    }
}

