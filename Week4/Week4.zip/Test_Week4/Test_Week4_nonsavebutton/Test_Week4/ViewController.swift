//
//  ViewController.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "HomePage"
    }

    @IBAction func buttonNextPage(_ sender: Any) {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let pushPage2 = storyBoard.instantiateViewController(withIdentifier: "IDPage2")
        self.navigationController?.pushViewController(pushPage2, animated: true)
    }
}

