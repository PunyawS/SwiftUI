//
//  Page3.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

protocol SideSlectionDelegate {
    func didTap(imgSquare: String)
}


class Page3: UIViewController {
    
    var selectionDelegate : SideSlectionDelegate?
    
    @IBOutlet weak var SettingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        SettingLabel.text = "Setting bruhhh"
    }

    
    @IBAction func imgSquare(_ sender: Any) {
        showAlertSquare()
    }
    

    @IBAction func imgCircle(_ sender: Any) {
        showAlertCircle()
    }
    
    
    
    //MARK: Function ShowAlert
    func showAlertSquare() {
        let alert = UIAlertController(title: "Do you want to save ?", message: "Deissmiss or Agree", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Agree", style: .default, handler: { action in
           
            self.selectionDelegate?.didTap(imgSquare: "1")
            self.dismiss(animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "Dissmiss", style: .cancel, handler: { action in
            print("Cancel")
            self.dismiss(animated: true, completion: nil)
        }))
        
        present(alert, animated: true)
    }
    
    func showAlertCircle() {
        let alert = UIAlertController(title: "Do you want to save ?", message: "Deissmiss or Agree", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Agree", style: .default, handler: { action in
            
            self.selectionDelegate?.didTap(imgSquare: "2")
            self.dismiss(animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "Dissmiss", style: .cancel, handler: { action in
            print("Cancel")
            self.dismiss(animated: true, completion: nil)
        }))
        
        present(alert, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
