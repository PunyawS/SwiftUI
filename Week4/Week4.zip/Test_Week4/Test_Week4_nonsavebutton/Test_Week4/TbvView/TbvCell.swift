//
//  TbvCell.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit
import SDWebImage


class TbvCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    //MARK: Create UICell
    func setUICell(model: Mymodel){
        
        idLabel.text = "\(model.id)"
        nameLabel.text = "\(model.name)"
        
        let imageURL = NSURL(string: "\(model.image)")
        
        if let url = imageURL {
            img.sd_setImage(with: url as URL, placeholderImage: UIImage(named: "apple"))
            self.img.contentMode = UIImageView.ContentMode.scaleAspectFill
        }
    }
}

