//
//  Page2.swift
//  Test_Week4
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class Page2: UIViewController {

    //MARK: Create Variable for check condition Delegate
    var imageStyle: String = "1"

    @IBOutlet weak var tbv: UITableView!
    
    //MARK: OpenSheet
    @IBAction func buttonOpenSheet(_ sender: Any) {
        let openSheet = Page3.init()
        openSheet.modalPresentationStyle = .formSheet
        //Connect Delegate between Page2 and Page3
        openSheet.selectionDelegate = self
        //
        self.present(openSheet, animated: true, completion: nil)
    }
    
    //MARK: User API load Block
    private var arr_cat:[Mymodel] = []
    private var loader_Bloack: ClassLoaderBlock = ClassLoaderBlock.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Page 2"
        
        
        //MARK: Register TableView
        tbv.register(UINib.init(nibName: "TbvCell", bundle: nil), forCellReuseIdentifier: "TbvCell")
        
        
        //MARK: Block
        //API Load Block
        loader_Bloack.loadData_Block { success, cat in
            if success{
                DispatchQueue.main.async {
                    self.arr_cat = cat ?? []
                    self.tbv.reloadData()
                }
            }
        }
    }
}

//MARK: Create TableView
extension Page2 : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //เรียกใช้ Row ตามข้อมูลใน API
        return arr_cat.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //สร้างแบบใช้ xib TableView
        let cell:TbvCell =  tableView.dequeueReusableCell(withIdentifier: "TbvCell") as! TbvCell
        
        let model:Mymodel = arr_cat[indexPath.row]
        
        cell.setUICell(model: model)
        
        //MARK: Check condition imgaeStyle
        
        if self.imageStyle == "1" {
            cell.img.layer.masksToBounds = true
            cell.img.layer.cornerRadius = 0
        }
        
        if self.imageStyle == "2" {
            cell.img.layer.masksToBounds = true
            cell.img.layer.cornerRadius = cell.img.bounds.width / 2
        }
        
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = .blue
            cell.nameLabel.textColor = .white
        } else {
            cell.backgroundColor = .white
            cell.nameLabel.textColor = .blue
        }
        
        return cell
    }
}

//MARK: Call func didtop Delegate from Page3
extension Page2 : SideSlectionDelegate {
    func didTap(imgSquare: String) {
        if imgSquare == "1" {
            self.imageStyle = "1"
            self.tbv.reloadData()
        }else{
            self.imageStyle = "2"
            self.tbv.reloadData()
        }
    }
}
