//
//  MyModel.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

//Codable
struct ResponseModel: Codable {
    var cat : [Mymodel]
}

struct Mymodel: Codable{
    var id : Int
    var name : String
    var image : String
}
