//
//  SettingViewController.swift
//  Week4
//
//  Created by Train3 on 28/1/2565 BE.
//

import Foundation
import UIKit

class SettingViewController: UIViewController {
    
    var PicStyle: Int = 1
    var StyleDelegate: PicStyleDelegate?

    @IBOutlet weak var rectBtn: UIButton!
    @IBOutlet weak var CirBtn: UIButton!
    @IBOutlet weak var SaveBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

    }
    
    @IBAction func toRect(_ sender: Any) {
        rectBtn.setTitleColor(.red, for: .normal)
        self.PicStyle = 1
    }
    
    @IBAction func toCir(_ sender: Any) {
        CirBtn.setTitleColor(.red, for: .normal)
        self.PicStyle = 2
    }
    
    @IBAction func Save(_ sender: Any) {
        let alert = UIAlertController.init(title: "ต้องการบันทึกหรือไม่", message: "", preferredStyle: .alert)
        
        let action1 = UIAlertAction.init(title: "ตกลง", style: .default, handler: { action in
            print("q")
            self.sendStyle()
            self.dismiss(animated: true, completion: nil)
        })
        alert.addAction(action1)
        
        let action2 = UIAlertAction.init(title: "ยกเลิก", style: .default, handler: { action in
            print("2")
            self.dismiss(animated: true, completion: nil)
        })
        alert.addAction(action2)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func sendStyle() {
        self.StyleDelegate?.chooseStyle(style: PicStyle)
    }
    
}


protocol PicStyleDelegate {
    func chooseStyle(style: Int)
}
