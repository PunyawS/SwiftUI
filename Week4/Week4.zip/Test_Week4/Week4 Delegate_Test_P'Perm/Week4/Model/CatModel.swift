//
//  File.swift
//  Week4
//
//  Created by Train3 on 28/1/2565 BE.
//

import Foundation

struct Cat: Codable {
    var cat: [EachCat]
}

struct EachCat: Codable {
    var id: Int
    var name: String
    var image: String
}
