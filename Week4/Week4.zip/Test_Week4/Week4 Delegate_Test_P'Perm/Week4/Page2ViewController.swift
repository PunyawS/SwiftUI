//
//  Page2ViewController.swift
//  Week4
//
//  Created by Train3 on 28/1/2565 BE.
//

import Foundation
import UIKit

class Page2ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, PicStyleDelegate {
    
        
    @IBOutlet weak var SettingBtn: UIButton!
    @IBOutlet weak var CatTbv: UITableView!
    
    private var cats = [EachCat]()
    
    var setting = SettingViewController.init()
    var picstyle: Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        CatTbv.register(UINib(nibName: "CatTableViewCell", bundle: nil), forCellReuseIdentifier: "catcell1")
        
        CatBlockLoader().loadData { success, cat in
            DispatchQueue.main.async {
                if success == true {
                    self.cats = cat ?? []
                    self.CatTbv.reloadData()
                }
            }
        }
        
//        setting.StyleDelegate = self
//        setting.sendStyle()
        
    }
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell: UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "cell")
        let cell: CatTableViewCell = tableView.dequeueReusableCell(withIdentifier: "catcell1") as! CatTableViewCell
        
        if indexPath.row % 2 != 0 {
            cell.CatName.textColor = .blue
        }
        
        if self.picstyle == 1 {
            cell.CatImg.layer.masksToBounds = true
            cell.CatImg.layer.cornerRadius = 0
        }
        
        if self.picstyle == 2 {
            cell.CatImg.layer.masksToBounds = true
            cell.CatImg.layer.cornerRadius = cell.CatImg.bounds.width / 2
        }
        
        
        cell.loadData(catData: cats[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    @IBAction func toSettingPage(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let SettingPage: SettingViewController = storyboard.instantiateViewController(withIdentifier: "settingpage") as! SettingViewController
        SettingPage.modalPresentationStyle = .formSheet
        SettingPage.StyleDelegate = self
        self.present(SettingPage, animated: true, completion: nil)
    }
    
    func chooseStyle(style: Int) {
        if style == 1 {
            print("1")
            self.picstyle = 1
            self.CatTbv.reloadData()
        }
        if style == 2 {
            print("2")
            self.picstyle = 2
            self.CatTbv.reloadData()
        }
    }
}
