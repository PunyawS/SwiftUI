//
//  CatBlockLoader.swift
//  Week4
//
//  Created by Train3 on 28/1/2565 BE.
//

import Foundation

class CatBlockLoader: ObservableObject {
    //var cats = [EachCat]()
    
    func loadData(completionHandler: @escaping (Bool, [EachCat]?) -> Void) {
        guard let url = URL(string: "https://jsonkeeper.com/b/A3IL") else { return }
                
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, err in
            if let err_check = err {
                print(err_check.localizedDescription)
                return
            }
            
            guard let EachCatData = data else { return }
            
            let DecodedEachCatData1 = try? JSONDecoder().decode(Cat.self, from: EachCatData)
            
            if let DecodedEachCatData = DecodedEachCatData1 {
                completionHandler(true, DecodedEachCatData.cat)
            }
        }
        .resume()
    }
}
