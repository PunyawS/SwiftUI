//
//  CatTableViewCell.swift
//  Week4
//
//  Created by Train3 on 28/1/2565 BE.
//

import UIKit
import SDWebImage

class CatTableViewCell: UITableViewCell {

    @IBOutlet weak var CatName: UILabel!
    @IBOutlet weak var CatImg: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func loadData(catData: EachCat) {
        CatImg.sd_setImage(with: URL(string: catData.image))
        self.CatImg.contentMode = UIImageView.ContentMode.scaleAspectFill
        
        CatName.text = catData.name
    }
    
    
}
