//
//  NewTableViewCell.swift
//  CTxib
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class NewTableViewCell: UITableViewCell {

    
    //Image
    @IBOutlet weak var imgv: UIImageView!
    @IBOutlet weak var imgsmall: UIImageView!
    
    //Lable
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbDetail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

        imgv.layer.borderWidth = 1
        imgv.layer.masksToBounds = false
        imgv.layer.borderColor = UIColor.black.cgColor
        imgv.layer.cornerRadius = imgv.frame.height/2
        imgv.clipsToBounds = true
        
        imgsmall.layer.borderWidth = 1
        imgsmall.layer.masksToBounds = false
        imgsmall.layer.borderColor = UIColor.black.cgColor
        imgsmall.layer.cornerRadius = imgsmall.frame.height/2
        imgsmall.clipsToBounds = true
        
//        imgv.backgroundColor = .cyan
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setUICell(model:[String:Any]){
        
        lbTitle.text = "\(model["title"] ?? "")"
        lbDetail.text = "\(model["detail"] ?? "")"
    }
    
}
