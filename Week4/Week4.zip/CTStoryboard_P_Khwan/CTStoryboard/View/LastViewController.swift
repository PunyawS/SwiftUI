//
//  LastViewController.swift
//  CTStoryboard
//
//  Created by Train4 on 24/1/2565 BE.
//

import UIKit

class LastViewController: UIViewController {

    @IBOutlet weak var btn: UIButton!
    
    var rowSelected:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Last viewDidLoad")
        
        self.title = "หน้า 3 - \(rowSelected)"
        
        btn.setTitleColor(.green, for: .normal)
        btn.setTitleColor(.red, for: .highlighted)
    }
    @IBAction func actionBackToRoot(_ sender: Any) {
        
        self.navigationController?.popToRootViewController(animated: true) // กลับหน้า root
    }
    
    @IBAction func actionBack2(_ sender: Any) {
        self.navigationController?.popViewController(animated: true) // กลับหน้าก่อนหน้า
    }
    
    @IBAction func actionGetArray(_ sender: Any) {
        if let navCon = self.navigationController {
            let arr = navCon.viewControllers
            print("arr : \(arr)")
//            navCon.popToViewController(arr[1], animated: true) // กลับไปหน้าที่ต้องการ
            
            // กรณีต้องการเซ็ตค่าให้หน้าอื่นด้วย
            if let nexView:NextViewController = arr[1] as? NextViewController {
                nexView.str_test_set = "Hello"
                navCon.popToViewController(nexView, animated: true) // กลับไปหน้าที่ต้องการ
            }
        }
    }
    
    
    @IBAction func actionTestDismiss(_ sender: Any) {
//        dismiss(animated: true, completion: nil)
        dismiss(animated: true)
//        self.dismiss(animated: true, completion: nil)
        
    }
}
