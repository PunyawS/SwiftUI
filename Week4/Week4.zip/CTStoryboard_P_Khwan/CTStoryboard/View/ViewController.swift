//
//  ViewController.swift
//  CTStoryboard
//
//  Created by Train4 on 24/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "หน้าแรก"
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    @IBAction func actionShowAlert(_ sender: Any) {
        let alert = UIAlertController.init(title: "Hello!!",
                                           message: "12345",
                                           preferredStyle: .alert)
//                                           preferredStyle: .actionSheet)
        let action1 = UIAlertAction.init(title: "ปุ่ม 1", style: .default, handler: { action in
            print("ปุ่ม 1")
            
        })
        let action2 = UIAlertAction.init(title: "ปุ่ม 2", style: .cancel, handler: { action in
            print("ปุ่ม 2")
            
        })
        let action3 = UIAlertAction.init(title: "ปุ่ม 3", style: .destructive, handler: { action in
            print("ปุ่ม 3")
            
        })
        alert.addAction(action1)
        alert.addAction(action2)
        alert.addAction(action3)
        self.present(alert, animated: true, completion: nil)
    }
    
}

