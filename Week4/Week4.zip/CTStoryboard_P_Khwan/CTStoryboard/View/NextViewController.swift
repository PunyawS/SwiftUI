//
//  NextViewController.swift
//  CTStoryboard
//
//  Created by Train4 on 24/1/2565 BE.
//

import UIKit

class NextViewController: UIViewController {
    

    @IBOutlet weak var tbv: UITableView!
    
    private let inden:String = "cell"
    private let inden_2:String = "cellNext"
    
    
//    private let arr:[[String]] = [["Hi","Hello"],
//                                  ["Morning","Afternoon","Evening","Night"],
//                                  ["White","Black","Red"]]
    
    private let arr_2:[String] = ["Hi","Hello","Morning","Afternoon","Evening","Night","White","Black","Red"]
    
    var str_test_set:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Next viewDidLoad")
        
        self.title = "หน้า 2"
        
        tbv.dataSource = self
        tbv.delegate = self
        
        tbv.register(UITableViewCell.self, forCellReuseIdentifier: inden)
        tbv.register(UINib.init(nibName: "NextCell", bundle: nil), forCellReuseIdentifier: inden_2)
        
    }
    
    

    @IBAction func actionReloadTable(_ sender: Any) {
        tbv.reloadData() // reload ทั้งหมด
//        tbv.reloadSections(IndexSet.init(integer: 1), with: .fade) //.automatic) // reload ทั้ง section
//        tbv.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .fade) // reload แค่ row ที่กำหนด
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Next viewWillAppear")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("Next viewDidAppear - str_test_set : \(str_test_set)")
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("Next viewWillDisappear")
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("Next viewDidDisappear")
    }
    
    
    
    //MARK: - Test Comment
    //MARK: -
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "openLast" {
            if let lastController:LastViewController = segue.destination as? LastViewController {
                if let sender_tmp = sender as? String {
                    lastController.rowSelected = sender_tmp
                }
            }
        }
    }
    
}

extension NextViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
//        return arr[section].count
        
        /*
        let arr_secion = arr[section]
        print("numberOfRowsInSection : section - \(section), \(arr_secion.count)")
        return arr_secion.count
        */
        
        return arr_2.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: inden)! as UITableViewCell
        let cell :UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: inden)
        
        
//        let str = arr[indexPath.section][indexPath.row]
        
//        let arr_section = arr[indexPath.section]
//        let str = arr_section[indexPath.row]
        
        
        let str = arr_2[indexPath.row]
        
        print("cellForRowAt : section - \(indexPath.section), row - \(indexPath.row)")
        
        cell.textLabel?.text = "row : \(indexPath.row) - \(str)"
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        cell.textLabel?.textColor = .black
        
        cell.detailTextLabel?.text = "detail : \(indexPath.row)"
        cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 14)
        cell.detailTextLabel?.textColor = .lightGray
        
//        cell.imageView?.image = UIImage.init(named: ".....")
//        cell.accessoryType = .checkmark
//        cell.accessoryType = .detailButton
        
        cell.backgroundColor = .yellow
        
        let row = indexPath.row
        if row%3==0 {
            cell.backgroundColor = .green
        }else if row%3==1 {
            cell.backgroundColor = .cyan
        }else if row%3==2 {
            cell.backgroundColor = .orange
        }
  
        return cell
        
        /*
        let cell:NextCell = tableView.dequeueReusableCell(withIdentifier: inden_2) as! NextCell
        cell.imgv.backgroundColor = .red
        return cell
        */
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        print("selected : \(indexPath.row)")
        
        /*
        // ------------- แบบ 1 --------------
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let lastViewController:LastViewController = storyboard.instantiateViewController(withIdentifier: "PageLast") as! LastViewController
//        let lastViewController2 = storyboard.instantiateViewController(withIdentifier: "PageLast") // ใช้ได้แค่กรณีที่ไม่ต้องการส่งค่าอะไรไป
        lastViewController.rowSelected = "\(indexPath.row)"
        
         // ------------- แบบ 1.1 push --------------
        // ถ้าใช้ navigationController push ไป, ตอนกลับต้องใช้ pop
//        self.navigationController?.pushViewController(lastViewController, animated: true)
        
         // ------------- แบบ 1.2 present --------------
        // ถ้าใช้ present ไป, ตอนกลับต้อง dismiss
//        lastViewController.modalPresentationStyle = .overFullScreen // เต็มจอ
        lastViewController.modalPresentationStyle = .formSheet // sheet // default อยู่แล้ว
        self.present(lastViewController, animated: true)
        */
        
        
         // ------------- แบบ 2 --------------
//        self.performSegue(withIdentifier: "openLast", sender: nil) // กรณีไม่ส่งค่าเพิ่มไป
//        self.performSegue(withIdentifier: "openLast", sender: "\(indexPath.row)") // กรณีส่งค่าไป
        self.performSegue(withIdentifier: "openLast", sender: arr_2[indexPath.row])
        
    }
    
    //MARK: เพิ่มเติม
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func numberOfSections(in tableView: UITableView) -> Int { // ถ้ามี section เดียวไม่ต้องใช้ฟังก์ชันนี้ เพราะ default เป็น 1 อยู่แล้ว
//        print("numberOfSections : \(arr.count)")
//        return 3
//        return arr.count
        
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        cell?.textLabel?.textColor = .red
    }
    
    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        cell?.textLabel?.textColor = .black
    }
}
