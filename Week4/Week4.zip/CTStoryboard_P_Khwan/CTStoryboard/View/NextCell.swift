//
//  NextCell.swift
//  CTStoryboard
//
//  Created by Train4 on 24/1/2565 BE.
//

import UIKit

class NextCell: UITableViewCell {
    
    @IBOutlet weak var imgv: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
