//
//  ViewController.swift
//  Basic_Delegation
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myTextField: UITextField!
    @IBAction func OKButton(_ sender: Any) {
        textFieldShouldReturn(myTextField.self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

//MARK: 1. Create Protocol
// Link delegate between myTextField and View Controller
extension ViewController: UITextViewDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let myAlert = UIAlertController(title: "Title is :", message: myTextField.text, preferredStyle: .alert)
        let myOKButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(myOKButton)
        self.present(myAlert, animated: true)
        return true
    }
}

