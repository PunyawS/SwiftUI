//
//  ViewController.swift
//  WebKit_View
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if let url = URL(string: "https://www.youtube.com/") {
            let urlRequest = URLRequest(url: url)
            myWebView?.load(urlRequest)
        }
    }

    @IBOutlet weak var myWebView: WKWebView!
    
    @IBAction func goNext(_ sender: Any) {
        myWebView.goForward()
    }
    
    @IBAction func goBack(_ sender: Any) {
        myWebView.goBack()
    }
}

