//
//  ViewController.swift
//  XO Game
//
//  Created by Train2 on 24/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    @IBOutlet weak var button7: UIButton!
    @IBOutlet weak var button8: UIButton!
    @IBOutlet weak var button9: UIButton!
    
    var buttons = [UIButton]()
    var currentPlayer = "O" //สลับกันระหว่าง O and X
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //เพิ่มปุ่มลง array
        buttons += [button1]
        buttons += [button2]
        buttons += [button3]
        buttons += [button4]
        buttons += [button5]
        buttons += [button6]
        buttons += [button7]
        buttons += [button8]
        buttons += [button9]
        
        //ปรับแต่งลักษณะของแต่ละปุ่ม
        for i in 0..<buttons.count{
            buttons[i].setTitle("", for: .normal)
            buttons[i].backgroundColor = UIColor.black
            buttons[i].tintColor = UIColor.white
            buttons[i].titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
            buttons[i].layer.cornerRadius = 10
        }
    }
    
    @IBAction func buttonDidTap(_ sender: UIButton) {
        if !sender.currentTitle!.isEmpty {
            return
        }else{
            if currentPlayer == "O" {
                sender.setTitle(self.currentPlayer, for: .normal)
                self.currentPlayer = "X"
            }else{
                sender.setTitle(self.currentPlayer, for: .normal)
                self.currentPlayer = "O"
            }
        }
    }
}

