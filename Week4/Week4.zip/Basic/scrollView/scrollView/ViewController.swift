//
//  ViewController.swift
//  scrollView
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
        myScrollView.contentSize = (myImg.image?.size)!
        
    }

    @IBOutlet weak var myScrollView: UIScrollView!
    @IBOutlet weak var myImg: UIImageView!
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        //Zoom
    }
}

