//
//  ViewController.swift
//  imgView
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImg: UIImageView!
    @IBAction func pressedOnOff(_ sender: UISwitch) {
        if sender.isOn{
            myImg.isHidden = false
        } else {
            myImg.isHidden = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
        // true = Hidden img
        //false = Show img
        myImg.isHidden = false
    }


}

