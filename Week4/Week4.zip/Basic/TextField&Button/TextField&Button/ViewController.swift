//
//  ViewController.swift
//  TextField&Button
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myInputText: UITextField!
    @IBOutlet weak var myOutputLable: UILabel!
    @IBAction func myButtonSend(_ sender: Any) {
        myOutputLable.text = "Name :" + myInputText.text!
        myInputText.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myOutputLable.text = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

