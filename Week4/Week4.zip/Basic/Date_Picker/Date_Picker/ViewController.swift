//
//  ViewController.swift
//  Date_Picker
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var selectDate: UIDatePicker!
    @IBOutlet weak var showResultLable: UILabel!
    
    
    @IBAction func showButtonPressed(_ sender: Any) {
        
        let currentDate = selectDate.date
        let myFormatter = DateFormatter()
        //วันจันทร์ อังคาร พุธ ฯลฯ
        myFormatter.dateFormat = "EEEE"
        let thaiLocale = NSLocale(localeIdentifier: "TH-th")
        myFormatter.locale = thaiLocale as Locale?
        let currentDateText = myFormatter.string(from: currentDate)
        showResultLable.text = currentDateText
    }
    
    @IBAction func resetButton(_ sender: Any) {
        showResultLable.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        showResultLable.text = ""
    }


}

