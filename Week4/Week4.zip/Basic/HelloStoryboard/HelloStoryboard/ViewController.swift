//
//  ViewController.swift
//  HelloStoryboard
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var sayHello: UILabel!
    @IBAction func ClickButton(_ sender: Any) {
        sayHello.text = "Hello Storyboard"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        sayHello.text = ""
    }


}

