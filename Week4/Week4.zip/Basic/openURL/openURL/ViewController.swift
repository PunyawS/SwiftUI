//
//  ViewController.swift
//  openURL
//
//  Created by Train2 on 28/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func openURL(_ sender: Any) {
        let destinationURL = URL(string: "https://google.com")
        if let openurl = destinationURL {
            UIApplication.shared.open(openurl, completionHandler: nil)
        }
    }
    
}

