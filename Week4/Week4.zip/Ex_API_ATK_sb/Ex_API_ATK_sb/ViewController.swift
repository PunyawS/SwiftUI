//
//  ViewController.swift
//  Ex_API_ATK_sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    
    }
    @IBAction func Button1(_ sender: Any) {
        let newCon = Button1ViewController.init()
        newCon.modalPresentationStyle = .overFullScreen
        self.present(newCon, animated: true, completion: nil)
    }
    
    @IBAction func Button2(_ sender: Any) {
        let newCon = Button2ViewController.init()
        newCon.modalPresentationStyle = .overFullScreen
        self.present(newCon, animated: true, completion: nil)
    }
    @IBAction func Button3(_ sender: Any) {
        let newCon = Button3ViewController.init()
        newCon.modalPresentationStyle = .overFullScreen
        self.present(newCon, animated: true, completion: nil)
    }
}


