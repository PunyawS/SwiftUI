//
//  Button2ViewController.swift
//  Ex_API_ATK_sb
//
//  Created by Train2 on 27/1/2565 BE.
//

import UIKit

class Button2ViewController: UIViewController {

    @IBOutlet weak var tbv: UITableView!
    
    //MARK: USE API Delegate
//    Use API delegate
    private var loader_APIDelegate:Loader_Delegate = Loader_Delegate.init()
    private var arr:[Mymodel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //MARK: Register TableView
        tbv.register(UINib.init(nibName: "button1TbvTableViewCell", bundle: nil), forCellReuseIdentifier: "button1TbvTableViewCell")
        
        //MARK: Delegate
        //API Load delegate
        loader_APIDelegate.delegate = self
        loader_APIDelegate.loadData_delegate()
    }
    
    @IBAction func CloseFullScreen(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//MARK: Create TableView
extension Button2ViewController : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //เรียกใช้ Row ตามข้อมูลใน API
        return arr.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //สร้างแบบใช้ xib TableView
        let cell:button1TbvTableViewCell =  tableView.dequeueReusableCell(withIdentifier: "button1TbvTableViewCell") as! button1TbvTableViewCell
        
        let model:Mymodel = arr[indexPath.row]
        
        cell.setUICell(model: model)
        
        cell.backgroundColor = .blue
        
        return cell
    }
}


//MARK: Protocol Delegate
//protocol LoaderDelegate
extension Button2ViewController : LoaderFinish{
    func loadFinished(success: Bool, dataRow:[Mymodel]) {
        if success{
            DispatchQueue.main.async {
                self.arr = dataRow
                 
            }
        }
    }
}


