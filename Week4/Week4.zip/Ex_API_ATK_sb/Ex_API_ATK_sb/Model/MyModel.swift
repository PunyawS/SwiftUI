//
//  MyModel.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

//Codable
struct ResponseModel: Codable {
    var Status : String
    var Message : String
    var Datarow : [Mymodel]
}

struct Mymodel: Codable{
    var id : String
    var title : String
    var image : String
    var total_view : Int
}
