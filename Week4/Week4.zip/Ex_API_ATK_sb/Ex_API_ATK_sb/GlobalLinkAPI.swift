//
//  GlobalLinkAPI.swift
//  Ex_API_ATK_sb
//
//  Created by Train2 on 27/1/2565 BE.
//

import Foundation


let path_Global:String = "https://jsonkeeper.com/b/0VLL"


extension NSNotification {
    static let loadFinished = Notification.Name.init("loadFinished")
}
