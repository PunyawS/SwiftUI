//
//  Loaderdelegate.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

//Load Complete
protocol LoaderFinish {
    //Check download Complete
    func loadFinished(success: Bool, dataRow:[Mymodel])
}

class Loader_Delegate : ObservableObject {
    
    //use protocol delegate
    
    var delegate : LoaderFinish?
    var loadFinished:Bool = false
    private let path:String = path_Global
    
    func loadData_delegate(){
        guard let url = URL(string: path) else {return}
        
        URLSession.shared.dataTask(with: url) { data, response, err in
            //check error
            if err != nil {
                return
            }
            //check data is nil if nil return it
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse{
                if decodeResponse_tmp.Status == "True" {
                    if decodeResponse_tmp.Message == "Success" {
                        self.delegate?.loadFinished(success: true, dataRow: decodeResponse_tmp.Datarow)
                    }
                    print("self.Datarow : \(decodeResponse_tmp.Datarow)")
                }
            }
        }.resume()
    }
}
