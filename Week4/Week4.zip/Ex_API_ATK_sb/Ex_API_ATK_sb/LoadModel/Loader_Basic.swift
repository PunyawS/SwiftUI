//
//  Loader.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

class Loader_Basic : ObservableObject {
    var rowData:[Mymodel] = []
    var loadFinished:Bool = false
    private let path:String = path_Global
    
    func loadData_basic(){
        self.loadFinished = true
        guard let url = URL(string: path) else {return}
        
        URLSession.shared.dataTask(with: url) { data, response, err in
            //check error
            if err != nil {
                return
            }
            //check data is nil if nil return it
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse{
                if decodeResponse_tmp.Status == "True" {
                    if decodeResponse_tmp.Message == "Success" {
                        self.rowData = decodeResponse_tmp.Datarow
                self.loadFinished = true
                        NotificationCenter.default.post(name: NSNotification.loadFinished, object: decodeResponse_tmp.Datarow)
                    }
                    print("rowData : \(self.rowData)")
                }
            }
        }.resume()
    }
}
