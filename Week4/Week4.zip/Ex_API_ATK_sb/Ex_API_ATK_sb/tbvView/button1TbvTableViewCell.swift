//
//  button1TbvTableViewCell.swift
//  Ex_API_ATK_sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit
import SDWebImage

class button1TbvTableViewCell: UITableViewCell {

    @IBOutlet weak var IDLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var totalViewLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.imgView.contentMode = UIImageView.ContentMode.scaleAspectFill
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setUICell(model:Mymodel){
        
        IDLabel.text = "ID : \(model.id)"
        titleLabel.text = "Name : \(model.title)"
        totalViewLabel.text = "Totalview : \(model.total_view)"
        
        let imageURL = NSURL(string: "\(model.image)")
        
        if let url = imageURL {
            imgView.sd_setImage(with: url as URL, placeholderImage: UIImage(named: "apple.png"))
            self.imgView.contentMode = UIImageView.ContentMode.scaleAspectFill
        }
    }
    
}
