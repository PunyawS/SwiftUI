//
//  Button1ViewController.swift
//  Ex_API_ATK_sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit
import SDWebImage


class Button1ViewController: UIViewController {

    //MARK: Use API Basic
    //APIBasic
    private var arr:[Mymodel] = []
    private var loader:Loader_Basic = Loader_Basic.init()
    
    @IBOutlet weak var tbv: UITableView!
    
    
    //Create #selector to use in NSNotification to Reload TableView
    @objc private func loader_basic_loadFinished(notification: NSNotification){
        
        if let obj = notification.object{
            DispatchQueue.main.async {
                self.arr = obj as! [Mymodel]
                self.tbv.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //MARK: Register TableView
        tbv.register(UINib.init(nibName: "button1TbvTableViewCell", bundle: nil), forCellReuseIdentifier: "button1TbvTableViewCell")
        
        //Load API
        //Reload TableView
        NotificationCenter.default.addObserver(self, selector: #selector(loader_basic_loadFinished(notification:)), name: NSNotification.loadFinished, object: nil)
        loader.loadData_basic()
        
 
    }

    @IBAction func Resetbutton(_ sender: Any) {
        self.tbv.reloadData()
    }
    
    
    @IBAction func closeFullScreen(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//MARK: Create TableView
extension Button1ViewController : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //เรียกใช้ Row ตามข้อมูลใน API
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //สร้างแบบใช้ xib TableView
        let cell:button1TbvTableViewCell =  tableView.dequeueReusableCell(withIdentifier: "button1TbvTableViewCell") as! button1TbvTableViewCell
        
        let model:Mymodel = arr[indexPath.row]
        
        cell.setUICell(model: model)
        
        cell.backgroundColor = .blue
        
        return cell
    }
}
