//
//  DatarowLoader.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import Foundation

class DatarowLoader: ObservableObject {
    var datarows = [Datarow]()
    var loaderDelegate: LoaderDelegate?
    
    //var basicfinish: Bool = false
    
    func loadDataBasic() {
        guard let url = URL(string: ApiPath) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, err in
            if let err_check = err {
                print(err_check.localizedDescription)
                return
            }
            
            guard let DatarowData = data else { return }
            
            let DecodedDatarowData1 = try? JSONDecoder().decode(Model.self, from: DatarowData)
            
            if let DecodedDatarowData = DecodedDatarowData1 {
                //self.datarows = DecodedDatarowData.Datarow
                NotificationCenter.default.post(name: NSNotification.loadFinished, object: DecodedDatarowData.Datarow)
                //print(self.datarows)
            }
        }
        .resume()
    }
}

protocol LoaderDelegate {
    func loadFinished(success: Bool)
}

extension DatarowLoader {
    
    func loadDataDelegate() {
        guard let url = URL(string: ApiPath) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, err in
            if let err_check = err {
                print(err_check.localizedDescription)
                return
            }
            
            guard let DatarowData = data else { return }
            
            let DecodedDatarowData1 = try? JSONDecoder().decode(Model.self, from: DatarowData)
            
            if let DecodedDatarowData = DecodedDatarowData1 {
                self.datarows = DecodedDatarowData.Datarow
                self.loaderDelegate?.loadFinished(success: true)
            }
        }
        .resume()
    }
}


extension DatarowLoader {
    func loadDataBlock(completionHandler: @escaping (Bool, [Datarow]?) -> Void) {
        guard let url = URL(string: ApiPath) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, err in
            if let err_check = err {
                print(err_check.localizedDescription)
                return
            }
            
            guard let DatarowData = data else { return }
            
            let DecodedDatarowData1 = try? JSONDecoder().decode(Model.self, from: DatarowData)
            
            if let DecodedDatarowData = DecodedDatarowData1 {
                completionHandler(true, DecodedDatarowData.Datarow)
            }
        }
        .resume()
    }
}
