//
//  Model.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import Foundation

struct Model: Codable {
    var Status: String
    var Message: String
    var Datarow: [Datarow]
}

struct Datarow: Codable {
    var id: String
    var title: String
    var image: String
    var total_view: Int
    var pdf: Bool?
    var can_click: Bool?
}
