//
//  Global.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import Foundation

let ApiPath = "https://jsonkeeper.com/b/RLYD"

extension NSNotification {
    static let loadFinished = Notification.Name.init(rawValue: "loadFinished")
}
