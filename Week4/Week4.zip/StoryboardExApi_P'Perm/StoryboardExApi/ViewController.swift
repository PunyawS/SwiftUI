//
//  ViewController.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func toBaicPage(_ sender: Any) {
        let basicpage = BasicViewController.init()
        basicpage.modalPresentationStyle = .overFullScreen
        self.present(basicpage, animated: true, completion: nil)
    }
    
    @IBAction func toDelegatePage(_ sender: Any) {
        let delegatepage = DelegateViewController.init()
        delegatepage.modalPresentationStyle = .overFullScreen
        self.present(delegatepage, animated: true, completion: nil)
    }
    @IBAction func toBlockPage(_ sender: Any) {
        let blockPage = BlockViewController.init()
        blockPage.modalPresentationStyle = .overFullScreen
        self.present(blockPage, animated: true, completion: nil)
    }
}

