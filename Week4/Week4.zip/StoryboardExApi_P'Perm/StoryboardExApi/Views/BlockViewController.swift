//
//  BlockViewController.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import UIKit

class BlockViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var BlockTbv: UITableView!
    
    private var blockdatarow = [Datarow]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        BlockTbv.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell1")
        
        DatarowLoader().loadDataBlock { success, datarow in
            DispatchQueue.main.async {
                if success == true {
                    self.blockdatarow = datarow ?? []
                    self.BlockTbv.reloadData()
                }
            }
            
        }
    }

    @IBAction func GOBACKKK(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        blockdatarow.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell1") as! TableViewCell
        cell.backgroundColor = .blue
        cell.loadCellData(data: blockdatarow[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
