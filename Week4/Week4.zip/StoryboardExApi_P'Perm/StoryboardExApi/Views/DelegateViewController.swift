//
//  DelegateViewController.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import UIKit

class DelegateViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, LoaderDelegate {
    
    
    var loader = DatarowLoader()
    
    @IBOutlet weak var DelegateTbv: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DelegateTbv.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell1")
        
        loader.loaderDelegate = self
        loader.loadDataDelegate()
    }

    @IBAction func goBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return loader.datarows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell1") as! TableViewCell
        cell.backgroundColor = .green
        cell.loadCellData(data: loader.datarows[indexPath.row])
        return cell
    }
    
    func loadFinished(success: Bool) {
        if success == true {
            DispatchQueue.main.async {
                self.DelegateTbv.reloadData()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
