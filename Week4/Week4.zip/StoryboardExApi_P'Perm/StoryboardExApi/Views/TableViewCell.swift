//
//  TableViewCell.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import UIKit
import SDWebImage

class TableViewCell: UITableViewCell {

    @IBOutlet weak var Img: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var totalview: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func loadCellData(data: Datarow) {
        Img!.sd_setImage(with: URL(string: data.image), placeholderImage: UIImage(named: "apple"))
        self.Img.contentMode = UIImageView.ContentMode.scaleAspectFill
        
        title.text = data.title
        id.text = data.id
        totalview.text = String(data.total_view)
    }
    
}
