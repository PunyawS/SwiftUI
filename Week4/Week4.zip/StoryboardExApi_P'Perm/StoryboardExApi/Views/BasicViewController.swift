//
//  BasicViewController.swift
//  StoryboardExApi
//
//  Created by Train3 on 26/1/2565 BE.
//

import UIKit

class BasicViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    private var loader = DatarowLoader()
    @IBOutlet weak var BasicTbv: UITableView!
    
    private var datarows = [Datarow]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        BasicTbv.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell1")
        
        NotificationCenter.default.addObserver(self, selector: #selector(loader_basic_loadFinished(notifiacation:)), name: NSNotification.loadFinished, object: nil)
        loader.loadDataBasic()
    }
    
    @objc private func loader_basic_loadFinished(notifiacation: NSNotification) {
        DispatchQueue.main.async {
            if let obj = notifiacation.object {
                self.datarows = obj as! [Datarow]
                self.BasicTbv.reloadData()
            }
        }
    }

    @IBAction func goBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datarows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell1") as! TableViewCell
        cell.backgroundColor = .yellow
        cell.loadCellData(data: datarows[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
