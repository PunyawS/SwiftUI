//
//  ViewController.swift
//  Segmented_Control
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func mySegmentedInput(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.view.backgroundColor = UIColor.red
        case 1:
            self.view.backgroundColor = UIColor.green
        case 2:
            self.view.backgroundColor = UIColor.blue
        case 3:
            self.view.backgroundColor = UIColor.green
        default:
            self.view.backgroundColor = UIColor.black
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.red
    }


}

