//
//  Global.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import Foundation

let path_ex:String = "https://jsonkeeper.com/b/3M1G"
let msg_err_default:String = "ไม่มีข้อมูลในขณะนี้"

/*
extension Notification {
    static let loadFinished = Notification.Name.init("loadFinished")
}
*/

extension NSNotification {
    static let loadFinished = NSNotification.Name.init("loadFinished")
}

