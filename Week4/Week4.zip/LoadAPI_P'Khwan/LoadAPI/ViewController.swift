//
//  ViewController.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tbv: UITableView!
    
    private var loader_basic:Loader_Basic       = Loader_Basic.init()
    private var loader_delegate:Loader_Delegate = Loader_Delegate.init()
    private var loader_block:Loader_Block       = Loader_Block.init()
    
    private var arr_text:[MyModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(loader_basic_loadFinished(notification:)),
                                               name: NSNotification.loadFinished,
                                               object: nil)
        
        loader_basic.loadData()
        
//        loader_delegate.delegate = self
//        loader_delegate.loadData()
        
        /*
        // อาจจะสั่ง start indicator ให้ loading เริ่มหมุน
        loader_block.loadData { success, arrText, arrBg, msgErr in
            DispatchQueue.main.async {
                // อาจจะสั่งหยุด indicator loading
                if success {
                    self.arr_text = arrText ?? []
                    self.tbv.reloadData()
                }else{
                    // อาจจะเอา msgErr มาโชว์ ฯลฯ หรือรีเฟรช ui อื่นๆ
                }
            }
        }
        */
    }
    
    @objc private func loader_basic_loadFinished(notification:NSNotification) {
        DispatchQueue.main.async {
            if let obj = notification.object {
                self.arr_text = obj as! [MyModel]
                self.tbv.reloadData()
            }
        }
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_text.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
        
        cell.textLabel?.text = "\(arr_text[indexPath.row].code)"
        
        return cell
    }
}

extension ViewController : Loader_DelegateDelegate {
    func loadFinished(success: Bool, arrText:[MyModel], arrBg:[MyModel], msgErr:String?) {
        DispatchQueue.main.async {
            if success {
                self.arr_text = arrText
                self.tbv.reloadData()
            }else{
                // อาจจะเอา msgErr มาโชว์ ฯลฯ หรือรีเฟรช ui อื่นๆ
            }
        }
    }
}
