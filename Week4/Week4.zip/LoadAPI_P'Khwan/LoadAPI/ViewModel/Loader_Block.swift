//
//  Loader_Block.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import Foundation

class Loader_Block : ObservableObject {
//    var arr_bg:[MyModel] = []
//    var arr_text:[MyModel] = []
    
    func loadData(completionHandler: @escaping (Bool, [MyModel]?, [MyModel]?, String?) -> Void) {
        guard let url = URL(string: path_ex) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let err = error {
                completionHandler(false, nil, nil, err.localizedDescription)
                return
            }
            
            guard let data_tmp = data else {
                completionHandler(false, nil, nil, msg_err_default)
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse {
//                self.arr_bg = decodeResponse_tmp.color_bg
//                self.arr_text = decodeResponse_tmp.color_text
                completionHandler(true, decodeResponse_tmp.color_text, decodeResponse_tmp.color_bg, "")
            }else{
                completionHandler(false, nil, nil, msg_err_default)
            }

        }.resume()
    }
}

