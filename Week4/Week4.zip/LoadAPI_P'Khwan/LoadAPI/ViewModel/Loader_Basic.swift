//
//  Loader_Basic.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import Foundation

class Loader_Basic : ObservableObject {
    var arr_bg:[MyModel] = []
    var arr_text:[MyModel] = []
//    var loadFinished:Bool = false
    
    func loadData() {
//        self.loadFinished = false
        guard let url = URL(string: path_ex) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if error != nil {
                return
            }
            
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse {
                self.arr_bg = decodeResponse_tmp.color_bg
                self.arr_text = decodeResponse_tmp.color_text
//                self.loadFinished = true
                
                NotificationCenter.default.post(name: NSNotification.loadFinished, object: decodeResponse_tmp.color_text)
            }
        }.resume()
    }
}

