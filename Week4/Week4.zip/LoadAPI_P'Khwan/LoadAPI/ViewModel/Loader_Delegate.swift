//
//  Loader_Delegate.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import Foundation

protocol Loader_DelegateDelegate {
//    func loadFinished(success: Bool)
    func loadFinished(success: Bool, arrText:[MyModel], arrBg:[MyModel], msgErr:String?)
}

class Loader_Delegate : ObservableObject {
//    var arr_bg:[MyModel] = []
//    var arr_text:[MyModel] = []
    
    var delegate: Loader_DelegateDelegate?
    
    func loadData() {
        guard let url = URL(string: path_ex) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let err = error {
                self.delegate?.loadFinished(success: false, arrText: [], arrBg: [], msgErr: err.localizedDescription)
                return
            }
            
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse {
//                self.arr_bg = decodeResponse_tmp.color_bg
//                self.arr_text = decodeResponse_tmp.color_text
                self.delegate?.loadFinished(success: true, arrText: decodeResponse_tmp.color_text, arrBg: decodeResponse_tmp.color_bg, msgErr: "")
            }

        }.resume()
    }
}

