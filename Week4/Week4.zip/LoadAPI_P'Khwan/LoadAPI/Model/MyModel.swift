//
//  MyModel.swift
//  LoadAPI
//
//  Created by Macbook16 on 26/1/2565 BE.
//

import Foundation

struct ResponseModel: Decodable {
    var color_text: [MyModel]
    var color_bg: [MyModel]
}

struct MyModel: Decodable {
    var id:Int
    var code:String
}


/*
struct ResponseModel: Codable {
    var color_text: [MyModel]
    var color_bg: [MyModel]
}

struct MyModel: Codable {
    var id:Int
    var code:String
}
*/
