//
//  PushNotification_SwiftUIApp.swift
//  PushNotification_SwiftUI
//
//  Created by Train2 on 26/1/2565 BE.
//

import SwiftUI

@main
struct PushNotification_SwiftUIApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
