//
//  AppDelegate.swift
//  PushNotification
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        // ขอ permission push
        
        //MARK: สำหรับ Test Local push App
        /*
        UNUserNotificationCenter.current().delegate = self
        //permissOption ขอให้โชว์ข้อความเตือน, ขึ้นจำนวนข้อความที่เตือน, มีเสียง
        let permissOption:UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(options: permissOption) { _, _ in
         
        }
        */
        
        //MARK: สำหรับใช้จริง
        UNUserNotificationCenter.current().delegate = self
        //permissOption ขอให้โชว์ข้อความเตือน, ขึ้นจำนวนข้อความที่เตือน, มีเสียง
        let permissOption:UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(options: permissOption) { granted, error in
            
            if error != nil {
                return
            }
            DispatchQueue.main.sync {
                application.registerForRemoteNotifications()
            }
        }
        
        return true
    }
    
    
    //MARK: อนุญาต push, เอา deviceToken ไปใช้ ในการยิง push
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data){
     
        print("deviceToken : \(deviceToken.hexString)")
    }

    //MARK: ไม่อนุญาต push หรือ เจน DeviceToken ไม่ได้
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error){
        
        print("error : \(error.localizedDescription)")
    }
    

    /*
     //Form SwiftUI
    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
     */

}

//MARK: Custome UNUserNotificationCenterDelegate
extension AppDelegate : UNUserNotificationCenterDelegate{
    
    //เข้าเมื่อแอพเปิดอยู่ แล้ว Push เข้า
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void){
        
        print("will : \(notification.request.content.userInfo)")
        
        completionHandler([.banner, .badge, .sound])
    }
    
    //กดเข้าจากหน้าต่างแจ้งเตือน
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void){
        
        printContent("did : \(response.notification.request.content.userInfo)")
        
        completionHandler()
    }
}


//MARK: Convert DeviceToken to String and then send to Backend.
extension Data {
    var hexString: String{
        let hexString = map { String(format: "%02.2hhx", $0)}.joined()
        return hexString
    }
}
