//
//  ViewController.swift
//  CTStoryboard
//
//  Created by Train2 on 24/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "หน้าแรก"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }


    @IBAction func buttonAlert(_ sender: Any) {
        //MARK: สร้าง Alert
        //ถ้าต้องการทำ actionsheet ให้เปลี่ยน preferredStyle: .actionsheet
        let alert = UIAlertController.init(title: "Hello World", message: "1234", preferredStyle: .alert)
        let action1 = UIAlertAction.init(title: "ตกลง", style: .default, handler: { action in
            //action Button1
            print("Button 1 Bruhhhhh")
        })
        let action2 = UIAlertAction.init(title: "Delete", style: .destructive, handler: { action in
            //action Button2
            print("Button 2 Bruhhhhh")
        })
        let action3 = UIAlertAction.init(title: "Cancel", style: .cancel, handler: { action in
            //action Button3
            print("Button 3 Bruhhhhh")
        })
        alert.addAction(action1)
        alert.addAction(action2)
        alert.addAction(action3)
        self.present(alert, animated: true, completion: nil)
    }
}

