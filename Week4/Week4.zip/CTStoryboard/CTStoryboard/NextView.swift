//
//  NextView.swift
//  CTStoryboard
//
//  Created by Train2 on 24/1/2565 BE.
//

import UIKit

class NextView: UIViewController {
    
    //Button
    @IBOutlet weak var buttonpage2: UIButton!
    
    //Create Data to TableView
    @IBOutlet weak var tbv: UITableView!
    private let inden:String = "cell"
    
    private let arr:[[String]] = [["Hi","Hello"],["Morning","Afternoon","Evening","Night"],["White","Black","Red"]]
    //[[section 1],[section 2],[section 3]]
    
    
    //เตรียมข้อมูล แต่ยังไม่โชว์หน้า
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Next viewDidLoad")
        
        self.title = "Next View, Page 2"
        
        tbv.dataSource = self
        tbv.delegate = self
        
        //ทำให้ UITableView รู้จักค่า
        tbv.register(UITableViewCell.self, forCellReuseIdentifier: inden)
        
    }
   
    //Reload Button
    @IBAction func actionReloadTable(_ sender: Any) {
        tbv.reloadData() //reload all sction and rows
//        tbv.reloadSections(IndexSet.init(integer: 1), with: .fade) //.automatic reload only (sections index 1)
//        tbv.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .fade) //reload only (row index 0 sections 0)
    }
    
    
    
//   //กำลังจะโชว์ App
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//
//        print("Next viewWillAppear")
//    }
//    //โชว์ App แล้ว
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//
//        print("Next viewDidAppear")
//    }
//    //กำลังจะปิด APP
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//
//        print("Next viewWillDisappear")
//    }
//    //ปิด APP
//    override func viewDidDisappear(_ animated: Bool) {
//        super.viewDidDisappear(animated)
//
//        print("Next viewDidDisappear")
//    }
    
    //ระบุปลายทางเพื่อรับค่าที่เราต้องการส่งไป ถ้าไม่ต้องการก็ไม่ต้องใช้ func นี้ และใช้ได้เมื่อใช้เส้นเท่านั้น
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "LastPage"{
//            if let lastController :LastView = segue.destination as? LastView {
//                if let sender_tmp = sender as? String{
//                    lastController.rowSelected = sender_tmp
////                    lastController.row
//                }
//            }
//        }
//    }
}

extension NextView : UITableViewDelegate, UITableViewDataSource{
    
    //MARK: สร้างRow และ ตกแต่ง
    //Create DataSource Row
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Row
//        return 10
        
        
        return arr[section].count
        //ถ้ามี section  เดียวให้ return arr.count ไปเลย
    }
    
    //แต่ง Row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: inden)! as UITableViewCell
        
        let cell : UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: inden)
        
        
        //เขียน ดึง arr ซ้อน arr ได้ 2 แบบ
        //แบบ 1
//        let str = arr[indexPath.section][indexPath.row]
        //แบบ 2
        let arr_section = arr[indexPath.section]
        let str = arr_section[indexPath.row]
        
        // ถ้ามี section เดียวให้้ let str = arr_section[indexPath.row] ไปเลบ
        
        cell.textLabel?.text = "row : \(indexPath.row+1) - \(str)"
//        cell.textLabel?.text = "row : \(indexPath.row+1)" //indexPath.row+1 จะเริ่มต้นจากเลข 1 เรียก Row
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        cell.textLabel?.textColor = .black
        
        cell.detailTextLabel?.text = "detail : \(indexPath.row+1)" //indexPath.row+1 จะเริ่มต้นจากเลข 1
        cell.detailTextLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        
        
//        if indexPath.row == 1{
//            cell.backgroundColor = .blue
//        }
        
        if indexPath.row % 3==0 {
            cell.backgroundColor = .green
        }else if indexPath.row % 3==1 {
            cell.backgroundColor = .blue
        }else if indexPath.row % 3==2 {
            cell.backgroundColor = .cyan
        }
        return cell
    }
   
    //MARK: สร้าง Delegate
    //Create Delegate, Delegate is action to do something
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        print("Selected : \(indexPath.row+1)") //indexPath.row+1 จะเริ่มต้นจากเลข 1
        
        /*
        //MARK: สร้าง Alert
        //ถ้าต้องการทำ actionsheet ให้เปลี่ยน preferredStyle: .actionsheet
        let alert = UIAlertController.init(title: "Hello World", message: "Hold Row \(indexPath.row+1) - section\(indexPath.section)", preferredStyle: .alert)
        let action1 = UIAlertAction.init(title: "ตกลง", style: .default, handler: { action in
            //action Button1
            print("Button 1 Bruhhhhh")
        })
        let action2 = UIAlertAction.init(title: "Delete", style: .destructive, handler: { action in
            //action Button2
            print("Button 2 Bruhhhhh")
        })
        let action3 = UIAlertAction.init(title: "Cancel", style: .cancel, handler: { action in
            //action Button3
            print("Button 3 Bruhhhhh")
        })
        alert.addAction(action1)
        alert.addAction(action2)
        alert.addAction(action3)
        self.present(alert, animated: true, completion: nil)
     */
        
//-------------- แบบ 1 ------------------
         //ดึง UI storyborad ID = "LastPage3"
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        
        /*
         //ใช้กรณีที่ไม่ได้ส่งค่าอะไรไป
//        let lastViewController = storyBoard.instantiateViewController(withIdentifier: "LastPage3")
         */
        
        //ดึง UI storyborad ID = "LastPage3"
        let lastViewController: LastView = storyBoard.instantiateViewController(withIdentifier: "LastPage3") as! LastView
      
        //ส่งค่าไปยังอีกหน้า ผ่านตัวแปร rowSelected
        lastViewController.rowSelected = "\(indexPath.row+1)" //indexPath.row+1 จะเริ่มต้นจากเลข 1 แสดงหน้าตาม Row ที่เลือก
        
        //MARK: การแสดงผล ต้องการให้เป็นอะไร Navigation, FullScreen, Sheet
        //-------------- แบบ 1.1 ------------------ Push
        //สั่งระบุว่าเป็น navigation
        //push คล้ายกับ NavigationLink ตอนกดกลับต้องใช้ pop
        //ส่งค่า rowSelected ไปยัง storyborad ID = "LastPage3"
        self.navigationController?.pushViewController(lastViewController, animated: true)
        
        //UI DemoViewController
//        let demoViewController:DemoViewController = DemoViewController.init()
//        self.navigationController?.pushViewController(demoViewController, animated: true)
        
        
        //-------------- แบบ 1.2 ------------------ Present
        //สั่งเต็มจอ ถ้าไม่สั่งจะเป็น Defualt = .formsheet
//        lastViewController.modalPresentationStyle = .overFullScreen
//        lastViewController.modalPresentationStyle = .formSheet
//        self.present(lastViewController, animated: true)
//         */
        
        
        //-------------- แบบ 2 ------------------
        
        //ส่งข้อมูลข้ามหน้าอ้างอิงเส้นก็ส่งข้อมูลได้ โดยใช้ Identifier
         //ส่งหรือไม่ส่งค่าให้ดู sender ว่ามีค่าเป็นอะไร
        //กรณีไม่ส่งค่าเพิ่มไป
//        self.performSegue(withIdentifier: "LastPage", sender: nil)
        //กรณีส่งค่าไป
//        self.performSegue(withIdentifier: "LastPage", sender: "\(indexPath.row+1)")
       
        
    }
    
    //MARK: - เพิ่มเติม
    //ทำ Highlight ตอนกดที่ Table แต่ละ Row
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //ตอนกด
    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        cell?.textLabel?.textColor = .yellow
    }
    //ตอนปล่อย
    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        cell?.textLabel?.textColor = .black
    }
    
    //สร้าง Group กำหนดให้มีกี่กลุ่ม กี่ section
    func numberOfSections(in tableView: UITableView) -> Int {
//        return 3
        
        return arr.count
    }
    
    //Set ความสูง Row
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}
