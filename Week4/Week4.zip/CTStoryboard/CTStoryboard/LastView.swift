//
//  LastView.swift
//  CTStoryboard
//
//  Created by Train2 on 24/1/2565 BE.
//

import UIKit

class LastView: UIViewController {
//เตรียมข้อมูล แต่ยังไม่โชว์หน้า
    
    @IBOutlet weak var btn: UIButton!
    
    var rowSelected:String = ""
//    public var rowSelected1:String = ""
//    private var rowSelected2:String = ""
//    static var rowSelected3:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Last viewDidLoad")
        
        self.title = "หน้า 3 -  \(rowSelected)"
        
        btn.setTitleColor(.green, for: .normal)
        btn.setTitleColor(.red, for: .highlighted)
        
    }
    @IBAction func actionBackToHomepage(_ sender: Any) {
        
        self.navigationController?
            .popToRootViewController(animated: true)//กลับหน้าแรก
//            .popViewController(animated: true)//กลับหน้าก่อนหน้า
    }
    
    
    @IBAction func goToPage2(_ sender: Any) {
        self.navigationController?
            .popViewController(animated: true)//กลับหน้าก่อนหน้า
    }
    
    
    @IBAction func GetArray(_ sender: Any) {
        if let navCon = self.navigationController{
            let arr = navCon.viewControllers
            print("arr : \(arr)")
            navCon.popToViewController(arr[1], animated: true)
        }
    }
    
    //กำลังจะโชว์ App
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("Last viewWillAppear")
    }
    //โชว์ App แล้ว
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("Last viewDidAppear")
    }
    //กำลังจะปิด APP
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("Last viewWillDisappear")
    }
    //ปิด APP
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        print("Last viewDidDisappear")
    }

    
    //ปุ่มสั่งปิด sheet or Fullscreen
    @IBAction func actionTestDismiss(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

