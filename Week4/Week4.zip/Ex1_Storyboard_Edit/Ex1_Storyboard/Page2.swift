//
//  Page2.swift
//  Ex1_Storyboard
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class Page2: UIViewController {

    private let str_title = "Hello"
    private let arr = ["White","Yellow","Blue","Red","Green","Black","Brown","Azure","Ivory","Teal"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        self.title = "Page 2"
    }
    
    //ปุ่มสั่งปิด sheet or Fullscreen
    @IBAction func closeFull(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //Close Push and Line
    @IBAction func closePagePush(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func openPage3(_ sender: Any) {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let Page3View: Page3 = storyBoard.instantiateViewController(withIdentifier: "IDPage3") as! Page3
        Page3View.Page3_title = str_title
        Page3View.Page3_arr = arr
        self.navigationController?.pushViewController(Page3View, animated: true)
    }
}
