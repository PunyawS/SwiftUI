//
//  Page3.swift
//  Ex1_Storyboard
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class Page3: UIViewController {

    var Page3_title = ""
    var Page3_arr = [String]()
    
    @IBOutlet weak var tbv: UITableView!
    @IBOutlet weak var btnRoot: UIButton!
    @IBOutlet weak var btnpopView: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Set Title
        self.title = "\(Page3_title)"
        
        //TableView
        tbv.dataSource = self
        tbv.delegate = self
        
        btnRoot.setTitleColor(.red, for: .highlighted)
        btnRoot.backgroundColor = .yellow
        
        btnpopView.setTitleColor(.red, for: .highlighted)
        btnpopView.backgroundColor = .yellow
    }
    //button back page
    //back homepage
    @IBAction func actionBackToRoot(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    //back 1 step

    @IBAction func actionBack1Step(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

extension Page3 : UITableViewDelegate, UITableViewDataSource{
    
    //Create Row
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Page3_arr.count
    }
    
    //UI Row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let str = Page3_arr[indexPath.row]
        let cell: UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "cell")
        
        print("Check Array : \(Page3_arr)")
        
        cell.textLabel?.text = "\(str)"
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        cell.detailTextLabel?.textColor = .lightGray
        cell.backgroundColor = .blue
        return cell
    }
    
    
    //MARK: Alert & Check select
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //Alert select
        tableView.deselectRow(at: indexPath, animated: true)
        
        let alert = UIAlertController.init(title: Page3_arr[indexPath.row], message: "", preferredStyle: .alert)
        
        let action1 = UIAlertAction.init(title: "Close", style: .default, handler: { action in
            })
        alert.addAction(action1)
        
        self.present(alert, animated: true, completion: nil)
        
        //check select
        tableView.deselectRow(at: indexPath, animated: true)
        
        print("Selected : \(indexPath.row+1)")
    }
    
    //ความสูง row
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
