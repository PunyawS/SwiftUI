//
//  ViewController.swift
//  Ex1_Storyboard
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Page 1"
    }
    
    //MARK: Line
    //Open Next Page by line
    @IBAction func openNextPagebyLine(_ sender: Any) {
        self.performSegue(withIdentifier: "OpenNextPageButton2", sender: nil)
//        modalTransitionStyle = .flipHorizontal
    }
    
    //MARK: ID Storyboard
    //Open Next Page one Step by ID Storyboard = IDPage2
    @IBAction func openNextPagebyIDs(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let Page2View = storyBoard.instantiateViewController(withIdentifier: "IDPage2")
        Page2View.modalPresentationStyle = .overFullScreen
        self.present(Page2View, animated: true, completion: nil)
    }
    
    //Open Next Page one Step by ID Storyboard = IDPage2 type Push
    @IBAction func openNextPagebyIDsPush(_ sender: Any) {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let Page2Viewpush = storyBoard.instantiateViewController(withIdentifier: "IDPage2")
        self.navigationController?.pushViewController(Page2Viewpush, animated: true)
    }
    
}




