//
//  NewViewController.swift
//  CTXib
//
//  Created by Train4 on 25/1/2565 BE.
//

import UIKit

class NewViewController: UIViewController {
    
    var str1:String = ""
    public var str2:String = ""
    
    private var str3:String = ""
    static var str4:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
