//
//  ViewController.swift
//  CTXib
//
//  Created by Train4 on 25/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tbv: UITableView!
    
    private var colorLoader:ColorLoader = ColorLoader.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        tbv.register(UINib.init(nibName: "NewCell", bundle: nil), forCellReuseIdentifier: "cellNew")
    }

    @IBAction func actionReloadTbv(_ sender: Any) {
        self.tbv.reloadData()
    }
    @IBAction func actionShowNewCon(_ sender: Any) {
        let newCon:NewViewController = NewViewController.init()
        self.present(newCon, animated: true, completion: nil)
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
        return colorLoader.arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell1")
        cell.backgroundColor = .yellow
        return cell
        */
        
        let cell:NewCell = tableView.dequeueReusableCell(withIdentifier: "cellNew") as! NewCell
//        cell.imgv.backgroundColor = .orange
//        cell.setUICell(model: ["title":"Row - \(indexPath.row)"])
        
        let model:SubColor = colorLoader.arr[indexPath.row]
        cell.setUICell(model: ["title":"Row - \(indexPath.row) - \(model.code)"])
        
        return cell
    }
    
    
}

