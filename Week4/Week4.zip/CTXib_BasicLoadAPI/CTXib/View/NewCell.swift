//
//  NewCell.swift
//  CTXib
//
//  Created by Train4 on 25/1/2565 BE.
//

import UIKit

class NewCell: UITableViewCell {

    @IBOutlet weak var imgv: UIImageView!
    
    @IBOutlet weak var lbTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        imgv.backgroundColor = .cyan
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setUICell(model:[String:Any]) {
        lbTitle.text = "\(model["title"] ?? "")"
        
    }
}
