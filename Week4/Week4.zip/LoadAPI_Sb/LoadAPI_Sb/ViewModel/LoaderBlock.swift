//
//  LoaderBlock.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

class ClassLoaderBlock : ObservableObject {
    
    //ใช้หรือไม่ใช้ก็ได้ เรียกผ่าน protocol LoaderComplete แทนได้
//    var arr_bg:[Mymodel] = []
//    var arr_text:[Mymodel] = []
    private let path:String = "https://jsonkeeper.com/b/3M1G"
    
    func loadData_block(completeionHandler: @escaping (Bool, [Mymodel]?) -> Void){
        guard let url = URL(string: path) else {return}
        
        URLSession.shared.dataTask(with: url) { data, response, err in
            //check error
            if err != nil {
                return
            }
            //check data is nil if nil return it
            guard let data_tmp = data else {
                return
            }
            
            let decodeResponse = try? JSONDecoder().decode(ResponseModel.self, from: data_tmp)
            if let decodeResponse_tmp = decodeResponse{
                //ใช้หรือไม่ใช้ก็ได้ เรียกผ่าน protocol LoaderComplete แทนได้
//                self.arr_bg = decodeResponse_tmp.color_bg
//                self.arr_text = decodeResponse_tmp.color_text
                completeionHandler(true, decodeResponse_tmp.color_text)
            }
            
        }.resume()
    }
}


