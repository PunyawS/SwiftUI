//
//  ViewController.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tbv: UITableView!
    
    //MARK: Use API Basic
    //APIBasic
    private var arr_text:[Mymodel] = []
    private var loader:Loader_Basic = Loader_Basic.init()
    //Create #selector to use in NSNotification
    @objc private func loader_basic_loadFinished(notification: NSNotification){
        
        if let obj = notification.object{
            DispatchQueue.main.async {
                self.arr_text = obj as! [Mymodel]
                self.tbv.reloadData()
            }
        }
    }
    
    //MARK: USE API Delegate
    //Use API delegate
//    private var loaderdelegate:ClassLoaderDelegate = ClassLoaderDelegate.init()
    
    //MARK: User API load Block
//    private var arr_text:[Mymodel] = []
//    private var loaderdelBloack: ClassLoaderBlock = ClassLoaderBlock.init()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //MARK: Basic
        
        //NSNotification รับข้อมูล คล้ายกับ OnResive
        NotificationCenter.default.addObserver(self, selector: #selector(loader_basic_loadFinished(notification:)), name: NSNotification.loadFinished, object: nil)
        
        loader.loadData_basic()
        
        //MARK: Delegate
        //API Load delegate
//        loaderdelegate.delegate = self
//        loaderdelegate.loadData_delegate()
        
        
        //MARK: Block
        //API Load Block
//        loaderdelBloack.loadData_block { success, arrText in
//            if success{
//                DispatchQueue.main.async {
//                    self.arr_text = arrText ?? []
//                    self.tbv.reloadData()
//                }
//            }
//        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //MARK: Basic & Delegate
        return loader.arr_text.count
        
        //MARK: Block
//        return arr_text.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //MARK: Basic & Delegate
        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
        
        cell.textLabel?.text = "\(loader.arr_text[indexPath.row].code)"
        
        //MARK: Block
//        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
//        cell.textLabel?.text = "\(arr_text[indexPath.row].code)"
        
        return cell
    }
    
    
}

//MARK: Protocol Delegate
////protocol LoaderDelegate
//extension ViewController : LoaderDelegate{
//    func loadFinished(success: Bool, arrText:[Mymodel]) {
//        if success{
//            DispatchQueue.main.async {
//                self.tbv.reloadData()
//            }
//        }
//    }
//}




