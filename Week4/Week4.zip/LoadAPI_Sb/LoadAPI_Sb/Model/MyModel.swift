//
//  MyModel.swift
//  LoadAPI_Sb
//
//  Created by Train2 on 26/1/2565 BE.
//

import Foundation

//Codable
struct ResponseModel: Codable {
    var color_text : [Mymodel]
    var color_bg : [Mymodel]
}

struct Mymodel: Codable{
    var id:Int
    var code:String
}

//Decodable
/*
struct ResponseModel: Decodable{
    var color_text : [Mymodel]
    var color_bg : [Mymodel]
}

struct MyModel: Decodable{
    var id :Int
    var Code:String
}
*/
