//
//  Page2ViewController.swift
//  Storyboard1Ex
//
//  Created by Train3 on 25/1/2565 BE.
//

import Foundation
import UIKit

class Page2ViewController: UIViewController {

    @IBOutlet weak var PresentCloseBtn: UIButton!
    @IBOutlet weak var PushCloseBtn: UIButton!
    @IBOutlet weak var toPage3Btn: UIButton!
    
    let str_title = "Hello"
    let arr = ["White","Yellow","Blue","Red","Green","Black","Brown","Azure","Ivory","Teal"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func PresentClose(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func PushClose(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func toPage3(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let page3: Page3ViewController = storyboard.instantiateViewController(withIdentifier: "page3") as! Page3ViewController
        page3.page3_title = str_title
        page3.page3_arr = arr
        self.navigationController?.pushViewController(page3, animated: true)
    }
    
}

