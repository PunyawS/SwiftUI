//
//  ViewController.swift
//  Storyboard1Ex
//
//  Created by Train3 on 25/1/2565 BE.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var SegueBtn: UIButton!
    @IBOutlet weak var StoryboardBtn1: UIButton!
    @IBOutlet weak var StoryboardBtn2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //using segue id
    @IBAction func toPage2(_ sender: Any) {
        self.performSegue(withIdentifier: "link1_2", sender: nil)
    }
    
    
    //using storyboard id: fullscreen
    @IBAction func toPage2FS(_ sender: Any) {
        let page2 = storyboard?.instantiateViewController(withIdentifier: "page2")
        page2?.modalPresentationStyle = .overFullScreen
        self.present(page2!, animated: true, completion: nil)
    }
    
    //using storyboard id: push
    @IBAction func toPage2Push(_ sender: Any) {
        let page2 = storyboard?.instantiateViewController(withIdentifier: "page2")
        page2?.modalPresentationStyle = .formSheet
        self.navigationController?.pushViewController(page2!, animated: true)
    }
}

