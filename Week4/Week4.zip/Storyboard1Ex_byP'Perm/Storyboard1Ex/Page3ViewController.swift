//
//  Page3ViewController.swift
//  Storyboard1Ex
//
//  Created by Train3 on 25/1/2565 BE.
//

import Foundation
import UIKit

class Page3ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var BackBtn: UIButton!
    @IBOutlet weak var ToFirstPageBtn: UIButton!
    
    @IBOutlet weak var tbv: UITableView!
    
    var page3_title = ""
    var page3_arr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "\(page3_title)"
        
        BackBtn.setTitleColor(.red, for: .highlighted)
        ToFirstPageBtn.setTitleColor(.red, for: .highlighted)
        
        BackBtn.backgroundColor = .yellow
        ToFirstPageBtn.backgroundColor = .yellow
        
    }

    @IBAction func Back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ToFirstPage(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return page3_arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let str = page3_arr[indexPath.row]
        let cell: UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "cell")
        
        print(page3_arr)
        
        cell.textLabel?.text = "\(str)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let alert = UIAlertController.init(title: page3_arr[indexPath.row], message: "", preferredStyle: .alert)
        
        let action1 = UIAlertAction.init(title: "Close", style: .default, handler: { action in
            
            })
                                         
        alert.addAction(action1)
        
        self.present(alert, animated: true, completion: nil)
    }
}
