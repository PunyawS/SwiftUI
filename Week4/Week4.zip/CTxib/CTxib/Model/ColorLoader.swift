//
//  ColorLoader.swift
//  CTXib
//
//  Created by Train4 on 25/1/2565 BE.
//

import Foundation

class ColorLoader: ObservableObject {
    @Published var arr = [SubColor]()
    
    init() {
        loadData(path: "https://jsonkeeper.com/b/3M1G")
    }
    
    func loadData(path: String) {
        guard let url = URL(string: path) else { return }
        
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
            if let err_check = error {
                print(err_check.localizedDescription)
                return
            }
            
            guard let ColorData = data else { return }
            
            let DecodedColorData_default = try? JSONDecoder().decode(Color1.self, from: ColorData)
            
            //DispatchQueue.main.async {
                if let DecodedColorData = DecodedColorData_default {
                    self.arr = DecodedColorData.color_bg
                }
            //}
            print((self.arr))
        }.resume()
    }
}
