//
//  ViewController.swift
//  CTxib
//
//  Created by Train2 on 25/1/2565 BE.
//

import UIKit

class CtViewController: UIViewController {

    
    @IBOutlet weak var tbv: UITableView!
    
    //Init API
    private var colorLoader:ColorLoader = ColorLoader.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //nibName = namefile, forCellReuseIdentifier = Identifier
        tbv.register(UINib.init(nibName: "NewTableViewCell", bundle: nil), forCellReuseIdentifier: "NewTableViewCell")
//        tbv.register(<#T##nib: UINib?##UINib?#>, forCellReuseIdentifier: <#T##String#>)
    }

    //reload UI when API load complete
    
    @IBAction func reLoadAPI(_ sender: Any) {
        self.tbv.reloadData()
    }
    
    //Show Page NewViewController
    @IBAction func actionShowNewCon(_ sender: Any) {
        let newCon = NewViewController.init()
        self.present(newCon, animated: true, completion: nil)
    }
}


//MARK: Create TableView
extension CtViewController : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
        //เรียกใช้ Row ตามข้อมูลใน API
        return colorLoader.arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
         //สร้างแบบปกติ
        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell1")
        cell.backgroundColor = .yellow
        return cell
         */
        
        //สร้างแบบใช้ NewTableViewCell
        //let cell:class
        let cell:NewTableViewCell =  tableView.dequeueReusableCell(withIdentifier: "NewTableViewCell") as! NewTableViewCell
        
        let model:SubColor = colorLoader.arr[indexPath.row]
        cell.setUICell(model: ["title":"Row - \(indexPath.row) - \(model.code)"])
        
        return cell
    }
}



